<?php
// MediCareX - Logout Script
// Developed by Romit Kumar

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';

logoutUser();

$baseUrl = get_base_url();
setFlash('info', "You have been logged out successfully.");
header("Location: {$baseUrl}/login.php");
exit();
