# MediCareX – Smart Hospital Management System

**Project Title:** MediCareX – Smart Hospital Management System  
**Developer:** Developed by Romit Kumar  
**Major Major Project / Full-Stack Healthcare SaaS Solution**

MediCareX is a full-stack, enterprise-grade Hospital Management System built using PHP 8+, MySQL/MariaDB, HTML5, CSS3, JavaScript, Bootstrap 5, Bootstrap Icons, and Chart.js. The platform is designed to run seamlessly on XAMPP (Apache + MySQL/phpMyAdmin) and provides role-based access control across 7 user types: Admin, Doctor, Nurse, Receptionist, Pharmacist, Lab Technician, and Patient.

---

## 1. DEFAULT DEMO LOGIN CREDENTIALS

All demo accounts have been pre-configured with password: `password123`

| User Role | Email Address | Password | Code | Description |
| :--- | :--- | :--- | :--- | :--- |
| **Admin** | `admin@medicarex.local` | `password123` | `ADM-1001` | Full System Control & Analytics |
| **Doctor** | `doctor@medicarex.local` | `password123` | `DOC-2001` | OPD Consultation & Prescriptions |
| **Nurse** | `nurse@medicarex.local` | `password123` | `NUR-3001` | Nursing Station & Vital Logger |
| **Receptionist** | `reception@medicarex.local` | `password123` | `REC-4001` | Check-in Desk & Patient Admission |
| **Pharmacist** | `pharmacy@medicarex.local` | `password123` | `PHA-5001` | Medicine Inventory & Alerts |
| **Lab Tech** | `lab@medicarex.local` | `password123` | `LAB-6001` | Lab Diagnostics & Test Release |
| **Patient** | `patient@medicarex.local` | `password123` | `PAT-7001` | Appointment Booking & Records |

*Note: On the login page (`login.php`), click any of the "Quick Fill Demo Logins" buttons for one-click testing.*

---

## 2. XAMPP SETUP & PHPMYADMIN IMPORT INSTRUCTIONS

### Step 1: Clone / Copy Project Folder
Copy the `MediCareX` directory into your XAMPP `htdocs` directory:
```
C:\xampp\htdocs\MediCareX
```

### Step 2: Start Apache and MySQL
1. Open **XAMPP Control Panel**.
2. Click **Start** for **Apache**.
3. Click **Start** for **MySQL**.

### Step 3: Database Import in phpMyAdmin
1. Open your browser and navigate to: `http://localhost/phpmyadmin`
2. Click on the **Databases** tab and create a new database named: `medicarex`
3. Select the `medicarex` database.
4. Click on the **Import** tab at the top.
5. Click **Choose File** and select `database/medicarex.sql` located inside the `MediCareX` project folder.
6. Scroll down and click **Import**.

### Step 4: Access the Application
Open your web browser and visit:
`http://localhost/MediCareX`

---

## 3. PROJECT ARCHITECTURE & DIRECTORY STRUCTURE

```
MediCareX/
│
├── index.php                 # Public Hospital Landing Page
├── login.php                 # Unified Authentication Portal (Quick fill buttons)
├── register.php              # Patient Self-Registration
├── logout.php                # Session Destruction & Audit Log
├── forgot_password.php       # Password Reset UI Simulation
├── print_prescription.php    # Printable Prescription View (PDF format)
├── print_invoice.php         # Printable Itemized Financial Invoice View
├── print_discharge.php       # Printable Inpatient Discharge Summary View
│
├── config/
│   └── database.php          # PDO MySQL Connection & Auto-Creation Handler
│
├── includes/
│   ├── auth.php              # Login, Logout, Session & Role Security
│   ├── functions.php         # Input Sanitization, Audit Logger, Notifications
│   ├── csrf.php              # CSRF Token Protection
│   └── permissions.php       # Fine-Grained Role Access Matrix
│
├── layout/
│   ├── header.php            # HTML Head, Bootstrap 5 CDN, Bootstrap Icons
│   ├── navbar.php            # Top Header, Unread Notifications, Dark Mode Toggle
│   ├── sidebar.php           # Role-Aware Navigation Sidebar (Offcanvas on Mobile)
│   └── footer.php            # Footer with "Developed by Romit Kumar"
│
├── admin/                    # Admin Management Dashboard & Charts
├── doctor/                   # Doctor OPD Workspace & Consultation Room
├── patient/                  # Patient Portal & Booking Engine
├── reception/                # Reception Desk & Patient Check-in
├── nurse/                    # Nursing Station & Vital Signs Logger
├── pharmacy/                 # Medicine Inventory & Stock Alerts
├── laboratory/               # Diagnostic Lab Workbench & Report Release
│
├── assets/
│   ├── css/
│   │   └── style.css         # Modern SaaS Healthcare CSS, Dark Mode, Print Rules
│   └── js/
│       └── app.js            # Client-side Search Filter, Theme Persist
│
├── database/
│   └── medicarex.sql         # Database Schema & Seed Data Script
│
└── README.md                 # Project Documentation & Guide
```

---

## 4. REAL-WORLD HOSPITAL PROBLEM SOLVING

1. **Patient Queue Congestion**: Solved via live OPD Token Tracking (`Token A-023`). Receptionists check in arriving patients, instantly updating the doctor's active waiting room display.
2. **Double Booking Conflicts**: Solved via automated server-side slot verification. The system prevents two patients from booking the same doctor at the same date and time slot.
3. **Lost Medical Records**: Solved via Centralized Medical Records Timeline, keeping a historical stream of consultations, vitals, prescriptions, and lab reports.
4. **Medicine Waste & Safety Risks**: Solved via real-time Pharmacy Stock Alerts (`LOW STOCK` badge when quantity $\le$ alert threshold, `EXPIRED` badge for past dates).
5. **Billing Errors**: Solved via automated invoice aggregation combining OPD consultation fees, lab charges, pharmacy items, and room charges.

---

## 5. FEATURE TESTING CHECKLIST

- [x] **Patient Registration & Login**: Self-registration generates Patient ID `PAT-XXXX` and hashes password with `password_hash()`.
- [x] **Appointment Booking**: Validates double-booking and assigns OPD Token.
- [x] **Patient Check-In**: Receptionist check-in moves patient to Doctor's live queue.
- [x] **Doctor Consultation**: Doctor enters symptoms, diagnosis, prescribes medicines, orders lab test, and generates invoice.
- [x] **Printable Documents**: Instant browser print view for Prescriptions, Invoices, and Discharge Summaries.
- [x] **Demo Payment Gateway**: Simulated checkout via UPI, Card, and Net Banking with instant transaction generation.
- [x] **Inpatient Room/Bed Management**: Beds cannot be assigned if already occupied.
- [x] **Dark Mode Toggle**: Persistent dark theme saved in `localStorage`.
- [x] **Audit Trail**: Action logging across logins, consultations, admissions, and payments.

---

**Developed by Romit Kumar**
