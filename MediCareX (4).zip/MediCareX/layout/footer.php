<?php
// MediCareX - Footer Component
// Developed by Romit Kumar

$baseUrl = get_base_url();
?>
<footer class="mt-auto py-3 bg-body border-top text-center text-muted fs-7 no-print">
    <div class="container-fluid">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-center">
            <div>
                &copy; <?= date('Y') ?> <strong><?= APP_NAME ?></strong>. All rights reserved.
            </div>
            <div class="fw-semibold text-primary mt-2 mt-md-0">
                <i class="bi bi-code-slash me-1"></i> <?= DEVELOPER_NAME ?>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap 5 JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<!-- Chart.js CDN -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<!-- Custom Client JS -->
<script src="<?= $baseUrl ?>/assets/js/app.js"></script>
</body>
</html>
