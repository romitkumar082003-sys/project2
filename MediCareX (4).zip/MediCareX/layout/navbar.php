<?php
// MediCareX - Top Navigation Bar
// Developed by Romit Kumar

$baseUrl = get_base_url();
$currentUser = getCurrentUser();

$unreadNotifications = [];
$unreadCount = 0;
if ($currentUser) {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
    $stmt->execute([$currentUser['id']]);
    $unreadNotifications = $stmt->fetchAll();
    
    $cntStmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
    $cntStmt->execute([$currentUser['id']]);
    $unreadCount = $cntStmt->fetchColumn();
}
?>
<nav class="navbar navbar-expand-lg navbar-custom sticky-top px-3 py-2">
    <div class="container-fluid">
        <!-- Sidebar Toggle Button (Mobile) -->
        <button class="btn btn-light d-lg-none me-2" id="sidebarToggleBtn" type="button">
            <i class="bi bi-list fs-4"></i>
        </button>

        <!-- Brand Name -->
        <a class="navbar-brand d-flex align-items-center fw-bold text-primary me-auto" href="<?= $baseUrl ?>/index.php">
            <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-2" style="width: 36px; height: 36px;">
                <i class="bi bi-cross-circle-fill fs-5"></i>
            </div>
            <span>Medi<span class="text-secondary">CareX</span></span>
        </a>

        <!-- Right Side Nav Items -->
        <div class="d-flex align-items-center gap-3">
            <!-- Dark Mode Toggle Button -->
            <button class="btn btn-outline-secondary border-0 rounded-circle" id="themeToggleBtn" type="button" title="Toggle Light/Dark Mode">
                <i class="bi bi-moon-stars-fill text-primary fs-5"></i>
            </button>

            <?php if ($currentUser): ?>
                <!-- Notifications Dropdown -->
                <div class="dropdown">
                    <button class="btn btn-outline-secondary border-0 rounded-circle position-relative" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-bell-fill fs-5"></i>
                        <?php if ($unreadCount > 0): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                <?= $unreadCount ?>
                            </span>
                        <?php endif; ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 rounded-3 p-2" style="width: 320px;">
                        <li class="dropdown-header fw-bold text-uppercase fs-7 text-muted border-bottom pb-2 mb-2 d-flex justify-content-between align-items-center">
                            <span>Notifications</span>
                            <span class="badge bg-primary rounded-pill"><?= $unreadCount ?> New</span>
                        </li>
                        <?php if (empty($unreadNotifications)): ?>
                            <li class="text-center py-3 text-muted fs-7">No new notifications</li>
                        <?php else: ?>
                            <?php foreach ($unreadNotifications as $notif): ?>
                                <li>
                                    <a class="dropdown-item rounded-2 py-2 px-3 mb-1" href="<?= htmlspecialchars($notif['link']) ?>">
                                        <div class="fw-semibold fs-7"><?= htmlspecialchars($notif['title']) ?></div>
                                        <div class="text-muted fs-8 text-truncate"><?= htmlspecialchars($notif['message']) ?></div>
                                        <div class="text-end fs-8 text-primary mt-1"><?= formatDate($notif['created_at'], 'h:i A') ?></div>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ul>
                </div>

                <!-- Quick Role Switcher for Demo / Presentations -->
                <div class="dropdown">
                    <button class="btn btn-sm btn-outline-primary rounded-pill dropdown-toggle px-2 py-1 fs-8 fw-semibold" type="button" data-bs-toggle="dropdown" aria-expanded="false" title="Switch portal immediately for presentation">
                        <i class="bi bi-shuffle me-1"></i> <span class="d-none d-sm-inline">Switch Portal</span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 rounded-3 p-2 fs-7" style="min-width: 210px;">
                        <li class="dropdown-header text-uppercase fs-8 fw-bold text-muted pb-1">⚡ Instant Demo Switcher</li>
                        <li><a class="dropdown-item rounded-2 py-1 <?= $currentUser['role_name'] === 'Admin' ? 'active fw-bold' : '' ?>" href="<?= $baseUrl ?>/login.php?demo_role=admin"><i class="bi bi-shield-lock-fill text-primary me-2"></i> Admin Portal</a></li>
                        <li><a class="dropdown-item rounded-2 py-1 <?= $currentUser['role_name'] === 'Doctor' ? 'active fw-bold' : '' ?>" href="<?= $baseUrl ?>/login.php?demo_role=doctor"><i class="bi bi-heart-pulse-fill text-danger me-2"></i> Doctor Portal</a></li>
                        <li><a class="dropdown-item rounded-2 py-1 <?= $currentUser['role_name'] === 'Patient' ? 'active fw-bold' : '' ?>" href="<?= $baseUrl ?>/login.php?demo_role=patient"><i class="bi bi-person-fill text-success me-2"></i> Patient Portal</a></li>
                        <li><a class="dropdown-item rounded-2 py-1 <?= $currentUser['role_name'] === 'Receptionist' ? 'active fw-bold' : '' ?>" href="<?= $baseUrl ?>/login.php?demo_role=reception"><i class="bi bi-calendar-check text-info me-2"></i> Reception Portal</a></li>
                        <li><a class="dropdown-item rounded-2 py-1 <?= $currentUser['role_name'] === 'Nurse' ? 'active fw-bold' : '' ?>" href="<?= $baseUrl ?>/login.php?demo_role=nurse"><i class="bi bi-activity text-warning me-2"></i> Nurse Portal</a></li>
                        <li><a class="dropdown-item rounded-2 py-1 <?= $currentUser['role_name'] === 'Pharmacist' ? 'active fw-bold' : '' ?>" href="<?= $baseUrl ?>/login.php?demo_role=pharmacy"><i class="bi bi-capsule text-secondary me-2"></i> Pharmacy Portal</a></li>
                        <li><a class="dropdown-item rounded-2 py-1 <?= $currentUser['role_name'] === 'Lab Technician' ? 'active fw-bold' : '' ?>" href="<?= $baseUrl ?>/login.php?demo_role=lab"><i class="bi bi-eyedropper text-purple me-2"></i> Laboratory Portal</a></li>
                    </ul>
                </div>

                <!-- User Profile Dropdown -->
                <div class="dropdown">
                    <a class="d-flex align-items-center text-decoration-none dropdown-toggle me-2" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-2 fw-bold" style="width: 38px; height: 38px;">
                            <?= strtoupper(substr($currentUser['name'], 0, 1)) ?>
                        </div>
                        <div class="d-none d-md-block text-start me-1">
                            <div class="fw-bold fs-7 mb-0 text-body"><?= htmlspecialchars($currentUser['name']) ?></div>
                            <div class="fs-8 text-muted"><?= htmlspecialchars($currentUser['role_name']) ?></div>
                        </div>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 rounded-3">
                        <li class="px-3 py-2 border-bottom">
                            <div class="fw-bold"><?= htmlspecialchars($currentUser['name']) ?></div>
                            <div class="fs-7 text-muted"><?= htmlspecialchars($currentUser['email']) ?></div>
                        </li>
                        <li><a class="dropdown-item py-2" href="<?= $baseUrl ?>/logout.php"><i class="bi bi-box-arrow-right text-danger me-2"></i> Log Out</a></li>
                    </ul>
                </div>
            <?php else: ?>
                <a href="<?= $baseUrl ?>/login.php" class="btn btn-outline-primary rounded-pill px-3">Sign In</a>
                <a href="<?= $baseUrl ?>/register.php" class="btn btn-primary rounded-pill px-3">Register</a>
            <?php endif; ?>
        </div>
    </div>
</nav>
