<?php
// MediCareX - Role-Based Sidebar Navigation
// Developed by Romit Kumar

$baseUrl = get_base_url();
$currentUser = getCurrentUser();
$role = $currentUser['role_name'] ?? 'Guest';
$currentScript = basename($_SERVER['SCRIPT_NAME']);
?>
<div id="sidebar">
    <div class="sidebar-heading d-flex align-items-center justify-content-between">
        <span class="fs-6 text-uppercase tracking-wider fw-bold text-muted"><?= htmlspecialchars($role) ?> Portal</span>
    </div>
    
    <div class="sidebar-nav py-3">
        <?php if ($role === 'Admin'): ?>
            <a href="<?= $baseUrl ?>/admin/index.php" class="nav-link <?= ($currentScript === 'index.php') ? 'active' : '' ?>">
                <i class="bi bi-grid-1x2-fill"></i> Dashboard
            </a>
            <a href="<?= $baseUrl ?>/admin/doctors.php" class="nav-link <?= ($currentScript === 'doctors.php') ? 'active' : '' ?>">
                <i class="bi bi-person-badge-fill"></i> Doctors
            </a>
            <a href="<?= $baseUrl ?>/admin/patients.php" class="nav-link <?= ($currentScript === 'patients.php') ? 'active' : '' ?>">
                <i class="bi bi-people-fill"></i> Patients
            </a>
            <a href="<?= $baseUrl ?>/admin/appointments.php" class="nav-link <?= ($currentScript === 'appointments.php') ? 'active' : '' ?>">
                <i class="bi bi-calendar-check-fill"></i> Appointments
            </a>
            <a href="<?= $baseUrl ?>/admin/departments.php" class="nav-link <?= ($currentScript === 'departments.php') ? 'active' : '' ?>">
                <i class="bi bi-building-fill"></i> Departments
            </a>
            <a href="<?= $baseUrl ?>/admin/rooms_beds.php" class="nav-link <?= ($currentScript === 'rooms_beds.php') ? 'active' : '' ?>">
                <i class="bi bi-door-open-fill"></i> Rooms & Beds
            </a>
            <a href="<?= $baseUrl ?>/admin/pharmacy.php" class="nav-link <?= ($currentScript === 'pharmacy.php') ? 'active' : '' ?>">
                <i class="bi bi-capsule"></i> Pharmacy Stock
            </a>
            <a href="<?= $baseUrl ?>/admin/laboratory.php" class="nav-link <?= ($currentScript === 'laboratory.php') ? 'active' : '' ?>">
                <i class="bi bi-journal-medical"></i> Laboratory
            </a>
            <a href="<?= $baseUrl ?>/admin/billing.php" class="nav-link <?= ($currentScript === 'billing.php') ? 'active' : '' ?>">
                <i class="bi bi-receipt"></i> Billing & Financials
            </a>
            <a href="<?= $baseUrl ?>/admin/blood_bank.php" class="nav-link <?= ($currentScript === 'blood_bank.php') ? 'active' : '' ?>">
                <i class="bi bi-droplet-fill"></i> Blood Bank
            </a>
            <a href="<?= $baseUrl ?>/admin/reports.php" class="nav-link <?= ($currentScript === 'reports.php') ? 'active' : '' ?>">
                <i class="bi bi-bar-chart-line-fill"></i> Reports
            </a>
            <a href="<?= $baseUrl ?>/admin/audit_logs.php" class="nav-link <?= ($currentScript === 'audit_logs.php') ? 'active' : '' ?>">
                <i class="bi bi-shield-lock-fill"></i> Audit Logs
            </a>

        <?php elseif ($role === 'Doctor'): ?>
            <a href="<?= $baseUrl ?>/doctor/index.php" class="nav-link <?= ($currentScript === 'index.php') ? 'active' : '' ?>">
                <i class="bi bi-speedometer2"></i> OPD Today
            </a>
            <a href="<?= $baseUrl ?>/doctor/appointments.php" class="nav-link <?= ($currentScript === 'appointments.php') ? 'active' : '' ?>">
                <i class="bi bi-calendar3"></i> Appointments
            </a>
            <a href="<?= $baseUrl ?>/doctor/patients.php" class="nav-link <?= ($currentScript === 'patients.php') ? 'active' : '' ?>">
                <i class="bi bi-person-lines-fill"></i> Patients
            </a>
            <a href="<?= $baseUrl ?>/doctor/prescriptions.php" class="nav-link <?= ($currentScript === 'prescriptions.php') ? 'active' : '' ?>">
                <i class="bi bi-file-earmark-medical-fill"></i> Prescriptions
            </a>
            <a href="<?= $baseUrl ?>/doctor/lab_requests.php" class="nav-link <?= ($currentScript === 'lab_requests.php') ? 'active' : '' ?>">
                <i class="bi bi-card-checklist"></i> Lab Requests
            </a>

        <?php elseif ($role === 'Patient'): ?>
            <a href="<?= $baseUrl ?>/patient/index.php" class="nav-link <?= ($currentScript === 'index.php') ? 'active' : '' ?>">
                <i class="bi bi-house-door-fill"></i> Patient Dashboard
            </a>
            <a href="<?= $baseUrl ?>/patient/book_appointment.php" class="nav-link <?= ($currentScript === 'book_appointment.php') ? 'active' : '' ?>">
                <i class="bi bi-calendar-plus-fill"></i> Book Appointment
            </a>
            <a href="<?= $baseUrl ?>/patient/my_appointments.php" class="nav-link <?= ($currentScript === 'my_appointments.php') ? 'active' : '' ?>">
                <i class="bi bi-clock-history"></i> My Appointments
            </a>
            <a href="<?= $baseUrl ?>/patient/records.php" class="nav-link <?= ($currentScript === 'records.php') ? 'active' : '' ?>">
                <i class="bi bi-folder-symlink-fill"></i> Medical Records
            </a>
            <a href="<?= $baseUrl ?>/patient/prescriptions.php" class="nav-link <?= ($currentScript === 'prescriptions.php') ? 'active' : '' ?>">
                <i class="bi bi-capsule-pill"></i> Prescriptions
            </a>
            <a href="<?= $baseUrl ?>/patient/lab_reports.php" class="nav-link <?= ($currentScript === 'lab_reports.php') ? 'active' : '' ?>">
                <i class="bi bi-file-earmark-pdf-fill"></i> Lab Reports
            </a>
            <a href="<?= $baseUrl ?>/patient/bills.php" class="nav-link <?= ($currentScript === 'bills.php') ? 'active' : '' ?>">
                <i class="bi bi-credit-card-fill"></i> Bills & Payments
            </a>

        <?php elseif ($role === 'Receptionist'): ?>
            <a href="<?= $baseUrl ?>/reception/index.php" class="nav-link <?= ($currentScript === 'index.php') ? 'active' : '' ?>">
                <i class="bi bi-card-heading"></i> Reception Desk
            </a>
            <a href="<?= $baseUrl ?>/reception/register_patient.php" class="nav-link <?= ($currentScript === 'register_patient.php') ? 'active' : '' ?>">
                <i class="bi bi-person-plus-fill"></i> Register Patient
            </a>
            <a href="<?= $baseUrl ?>/reception/book_appointment.php" class="nav-link <?= ($currentScript === 'book_appointment.php') ? 'active' : '' ?>">
                <i class="bi bi-calendar-check"></i> Book Appointment
            </a>
            <a href="<?= $baseUrl ?>/reception/checkin.php" class="nav-link <?= ($currentScript === 'checkin.php') ? 'active' : '' ?>">
                <i class="bi bi-box-arrow-in-right"></i> Patient Check-In
            </a>
            <a href="<?= $baseUrl ?>/reception/admit_patient.php" class="nav-link <?= ($currentScript === 'admit_patient.php') ? 'active' : '' ?>">
                <i class="bi bi-hospital"></i> Admit Patient
            </a>
            <a href="<?= $baseUrl ?>/reception/billing.php" class="nav-link <?= ($currentScript === 'billing.php') ? 'active' : '' ?>">
                <i class="bi bi-receipt-cutoff"></i> Billing Desk
            </a>

        <?php elseif ($role === 'Nurse'): ?>
            <a href="<?= $baseUrl ?>/nurse/index.php" class="nav-link <?= ($currentScript === 'index.php') ? 'active' : '' ?>">
                <i class="bi bi-heart-pulse"></i> Nursing Desk
            </a>
            <a href="<?= $baseUrl ?>/nurse/vitals.php" class="nav-link <?= ($currentScript === 'vitals.php') ? 'active' : '' ?>">
                <i class="bi bi-activity"></i> Log Vital Signs
            </a>
            <a href="<?= $baseUrl ?>/nurse/wards.php" class="nav-link <?= ($currentScript === 'wards.php') ? 'active' : '' ?>">
                <i class="bi bi-door-open"></i> Ward Status
            </a>

        <?php elseif ($role === 'Pharmacist'): ?>
            <a href="<?= $baseUrl ?>/pharmacy/index.php" class="nav-link <?= ($currentScript === 'index.php') ? 'active' : '' ?>">
                <i class="bi bi-capsule"></i> Pharmacy Desk
            </a>
            <a href="<?= $baseUrl ?>/pharmacy/medicines.php" class="nav-link <?= ($currentScript === 'medicines.php') ? 'active' : '' ?>">
                <i class="bi bi-box-seam"></i> Medicine Inventory
            </a>
            <a href="<?= $baseUrl ?>/pharmacy/low_stock.php" class="nav-link <?= ($currentScript === 'low_stock.php') ? 'active' : '' ?>">
                <i class="bi bi-exclamation-triangle-fill"></i> Stock & Expiry Alerts
            </a>
            <a href="<?= $baseUrl ?>/pharmacy/dispense.php" class="nav-link <?= ($currentScript === 'dispense.php') ? 'active' : '' ?>">
                <i class="bi bi-cart-check"></i> Dispense Medicines
            </a>

        <?php elseif ($role === 'Lab Technician'): ?>
            <a href="<?= $baseUrl ?>/laboratory/index.php" class="nav-link <?= ($currentScript === 'index.php') ? 'active' : '' ?>">
                <i class="bi bi-journal-medical"></i> Lab Workbench
            </a>
            <a href="<?= $baseUrl ?>/laboratory/test_requests.php" class="nav-link <?= ($currentScript === 'test_requests.php') ? 'active' : '' ?>">
                <i class="bi bi-hourglass-split"></i> Pending Test Requests
            </a>
        <?php endif; ?>

        <hr class="mx-3 my-3">
        <a href="<?= $baseUrl ?>/logout.php" class="nav-link text-danger">
            <i class="bi bi-box-arrow-right"></i> Log Out
        </a>
    </div>
</div>
