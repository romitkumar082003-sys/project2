<?php
// MediCareX - Printable Billing Invoice Generator
// Developed by Romit Kumar

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();

$id = intval($_GET['id'] ?? 0);
$pdo = getDBConnection();

$stmt = $pdo->prepare("
    SELECT inv.*, p.patient_code, u.name as patient_name, u.phone as patient_phone, u.email as patient_email, p.address
    FROM invoices inv
    JOIN patients p ON inv.patient_id = p.id
    JOIN users u ON p.user_id = u.id
    WHERE inv.id = ?
");
$stmt->execute([$id]);
$inv = $stmt->fetch();

if (!$inv) {
    die("Invoice record not found.");
}

$pmtStmt = $pdo->prepare("SELECT * FROM payments WHERE invoice_id = ? ORDER BY payment_date DESC");
$pmtStmt->execute([$id]);
$payments = $pmtStmt->fetchAll();

$baseUrl = get_base_url();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Invoice #<?= $inv['invoice_code'] ?> - MediCareX</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>/assets/css/style.css">
    <style>
        body { background: #fff; color: #000; font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="p-4 p-md-5">

    <div class="container bg-white p-4 border rounded-3 shadow-sm" style="max-width: 850px;">
        <div class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-4">
            <div>
                <h2 class="fw-bold text-primary mb-0"><i class="bi bi-cross-circle-fill me-2"></i> MediCareX Hospital</h2>
                <small class="text-muted">Medical Billing & Accounts Desk &bull; Contact: billing@medicarex.local</small>
            </div>
            <div class="text-end">
                <h4 class="fw-bold mb-0">INVOICE</h4>
                <div class="fw-bold text-primary"><?= htmlspecialchars($inv['invoice_code']) ?></div>
                <div class="fs-8 text-muted">Date: <?= formatDate($inv['created_at'], 'd M Y') ?></div>
            </div>
        </div>

        <div class="row g-3 mb-4 fs-7">
            <div class="col-6">
                <h6 class="fw-bold text-uppercase fs-8 text-muted mb-1">Billed To</h6>
                <div class="fw-bold fs-6"><?= htmlspecialchars($inv['patient_name']) ?></div>
                <div>Patient ID: <strong><?= htmlspecialchars($inv['patient_code']) ?></strong></div>
                <div>Phone: <?= htmlspecialchars($inv['patient_phone']) ?></div>
                <div class="text-muted"><?= htmlspecialchars($inv['address']) ?></div>
            </div>
            <div class="col-6 text-end">
                <h6 class="fw-bold text-uppercase fs-8 text-muted mb-1">Payment Status</h6>
                <div><?= renderStatusBadge($inv['payment_status']) ?></div>
            </div>
        </div>

        <table class="table table-bordered fs-7 align-middle mb-4">
            <thead class="table-light">
                <tr>
                    <th>Service / Item Description</th>
                    <th class="text-end" style="width: 150px;">Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($inv['consultation_fee'] > 0): ?>
                    <tr>
                        <td>Doctor OPD Consultation Fee</td>
                        <td class="text-end"><?= formatCurrency($inv['consultation_fee']) ?></td>
                    </tr>
                <?php endif; ?>
                <?php if ($inv['lab_charges'] > 0): ?>
                    <tr>
                        <td>Laboratory Diagnostic Charges</td>
                        <td class="text-end"><?= formatCurrency($inv['lab_charges']) ?></td>
                    </tr>
                <?php endif; ?>
                <?php if ($inv['medicine_charges'] > 0): ?>
                    <tr>
                        <td>Pharmacy Medication Charges</td>
                        <td class="text-end"><?= formatCurrency($inv['medicine_charges']) ?></td>
                    </tr>
                <?php endif; ?>
                <?php if ($inv['room_charges'] > 0): ?>
                    <tr>
                        <td>Inpatient Room & Bed Accommodation Charges</td>
                        <td class="text-end"><?= formatCurrency($inv['room_charges']) ?></td>
                    </tr>
                <?php endif; ?>
                <?php if ($inv['other_charges'] > 0): ?>
                    <tr>
                        <td>Other Clinical Services & Nursing Charges</td>
                        <td class="text-end"><?= formatCurrency($inv['other_charges']) ?></td>
                    </tr>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td class="text-end fw-bold">Subtotal:</td>
                    <td class="text-end fw-bold"><?= formatCurrency($inv['subtotal']) ?></td>
                </tr>
                <?php if ($inv['discount'] > 0): ?>
                    <tr>
                        <td class="text-end text-success">Discount:</td>
                        <td class="text-end text-success">- <?= formatCurrency($inv['discount']) ?></td>
                    </tr>
                <?php endif; ?>
                <tr>
                    <td class="text-end text-muted">Taxes (GST 5%):</td>
                    <td class="text-end text-muted"><?= formatCurrency($inv['tax']) ?></td>
                </tr>
                <tr class="table-primary fs-6">
                    <td class="text-end fw-extrabold">Grand Total:</td>
                    <td class="text-end fw-extrabold text-primary"><?= formatCurrency($inv['grand_total']) ?></td>
                </tr>
            </tfoot>
        </table>

        <?php if (!empty($payments)): ?>
            <h6 class="fw-bold text-uppercase fs-8 text-muted mb-2">Payment Transaction History</h6>
            <table class="table table-sm table-striped fs-8 mb-4 border">
                <thead>
                    <tr>
                        <th>Transaction Code</th>
                        <th>Gateway Reference</th>
                        <th>Method</th>
                        <th>Amount</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($payments as $pmt): ?>
                        <tr>
                            <td><?= htmlspecialchars($pmt['payment_code']) ?></td>
                            <td><code><?= htmlspecialchars($pmt['transaction_id']) ?></code></td>
                            <td><?= htmlspecialchars($pmt['payment_method']) ?></td>
                            <td><?= formatCurrency($pmt['amount']) ?></td>
                            <td><?= formatDate($pmt['payment_date']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <div class="d-flex justify-content-between align-items-end mt-5 pt-3 border-top fs-7">
            <div>
                <small class="text-muted d-block">Thank you for choosing MediCareX Hospital.</small>
                <small class="fw-bold text-primary"><?= DEVELOPER_NAME ?></small>
            </div>
            <div class="text-center" style="width: 200px;">
                <div class="border-bottom pb-4 mb-1"></div>
                <small class="fw-bold">Accounts Officer Signature</small>
            </div>
        </div>

        <div class="text-center mt-4 no-print">
            <button onclick="window.print()" class="btn btn-primary btn-lg rounded-pill px-4 shadow">
                <i class="bi bi-printer-fill me-2"></i> Print Invoice / Save PDF
            </button>
        </div>
    </div>

</body>
</html>
