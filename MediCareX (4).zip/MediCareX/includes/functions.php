<?php
// MediCareX - Core Helper Functions
// Developed by Romit Kumar

require_once __DIR__ . '/../config/database.php';

function cleanInput($data) {
    if (is_array($data)) {
        return array_map('cleanInput', $data);
    }
    $data = trim($data ?? '');
    $data = stripslashes($data);
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

function setFlash($type, $message) {
    $_SESSION['flash_' . $type] = $message;
}

function displayFlash() {
    $types = ['success', 'error', 'info', 'warning'];
    foreach ($types as $type) {
        if (isset($_SESSION['flash_' . $type])) {
            $msg = $_SESSION['flash_' . $type];
            unset($_SESSION['flash_' . $type]);
            $bg = ($type === 'error') ? 'danger' : $type;
            echo "<div class='alert alert-{$bg} alert-dismissible fade show shadow-sm border-0 mb-4' role='alert'>
                    <i class='bi " . ($type === 'success' ? 'bi-check-circle-fill' : ($type === 'error' ? 'bi-exclamation-triangle-fill' : 'bi-info-circle-fill')) . " me-2'></i>
                    " . htmlspecialchars($msg) . "
                    <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                  </div>";
        }
    }
}

function logAudit($user_id, $user_name, $role, $action, $description) {
    try {
        $pdo = getDBConnection();
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $stmt = $pdo->prepare("
            INSERT INTO audit_logs (user_id, user_name, role, action, description, ip_address) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$user_id, $user_name, $role, $action, $description, $ip]);
    } catch (Exception $e) {
        // Silently log or ignore audit table error
    }
}

function addNotification($user_id, $title, $message, $link = '#') {
    try {
        $pdo = getDBConnection();
        $stmt = $pdo->prepare("
            INSERT INTO notifications (user_id, title, message, link) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$user_id, $title, $message, $link]);
    } catch (Exception $e) {
        // Ignore notification table error
    }
}

function generateCode($prefix, $table, $column) {
    $pdo = getDBConnection();
    $rand = rand(1000, 9999);
    $code = $prefix . '-' . $rand;
    
    // Ensure unique
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM `{$table}` WHERE `{$column}` = ?");
    $stmt->execute([$code]);
    if ($stmt->fetchColumn() > 0) {
        return generateCode($prefix, $table, $column);
    }
    return $code;
}

function renderStatusBadge($status) {
    $badgeClass = 'bg-secondary';
    $statusLower = strtolower($status);
    
    if (in_array($statusLower, ['active', 'confirmed', 'completed', 'paid', 'success', 'available', 'discharged'])) {
        $badgeClass = 'bg-success';
    } elseif (in_array($statusLower, ['pending', 'in consultation', 'under treatment', 'in progress', 'partial', 'urgent'])) {
        $badgeClass = 'bg-warning text-dark';
    } elseif (in_array($statusLower, ['checked in', 'admitted'])) {
        $badgeClass = 'bg-info text-dark';
    } elseif (in_array($statusLower, ['cancelled', 'inactive', 'failed', 'suspended', 'expired', 'occupied'])) {
        $badgeClass = 'bg-danger';
    } elseif (in_array($statusLower, ['emergency', 'low stock'])) {
        $badgeClass = 'bg-danger text-white fw-bold animate-pulse';
    }

    return "<span class='badge {$badgeClass} rounded-pill px-3 py-2 fs-7'>" . htmlspecialchars($status) . "</span>";
}

function formatCurrency($amount) {
    return '₹' . number_format((float)$amount, 2);
}

function formatDate($date, $format = 'd M Y, h:i A') {
    if (!$date) return 'N/A';
    return date($format, strtotime($date));
}
