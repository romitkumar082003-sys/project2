<?php
// MediCareX - Role & Permission Matrix
// Developed by Romit Kumar

define('ROLE_ADMIN', 'Admin');
define('ROLE_DOCTOR', 'Doctor');
define('ROLE_NURSE', 'Nurse');
define('ROLE_RECEPTIONIST', 'Receptionist');
define('ROLE_PHARMACIST', 'Pharmacist');
define('ROLE_LAB_TECH', 'Lab Technician');
define('ROLE_PATIENT', 'Patient');

function canManageUsers($role) {
    return $role === ROLE_ADMIN;
}

function canConsultPatients($role) {
    return in_array($role, [ROLE_ADMIN, ROLE_DOCTOR]);
}

function canRecordVitals($role) {
    return in_array($role, [ROLE_ADMIN, ROLE_DOCTOR, ROLE_NURSE]);
}

function canCheckInPatients($role) {
    return in_array($role, [ROLE_ADMIN, ROLE_RECEPTIONIST]);
}

function canManageInventory($role) {
    return in_array($role, [ROLE_ADMIN, ROLE_PHARMACIST]);
}

function canProcessLab($role) {
    return in_array($role, [ROLE_ADMIN, ROLE_LAB_TECH]);
}

function canViewMedicalRecords($role) {
    return in_array($role, [ROLE_ADMIN, ROLE_DOCTOR, ROLE_NURSE, ROLE_PATIENT, ROLE_RECEPTIONIST]);
}
