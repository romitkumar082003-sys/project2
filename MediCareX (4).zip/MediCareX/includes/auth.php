<?php
// MediCareX - Authentication & Session Helper
// Developed by Romit Kumar

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function getCurrentUser() {
    if (!isLoggedIn()) return null;
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("
        SELECT u.*, r.role_name 
        FROM users u 
        JOIN roles r ON u.role_id = r.id 
        WHERE u.id = ? AND u.status = 'Active'
    ");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch();
}

function requireLogin() {
    if (!isLoggedIn()) {
        $_SESSION['flash_error'] = "Please log in to access this page.";
        $baseUrl = get_base_url();
        header("Location: {$baseUrl}/login.php");
        exit();
    }
}

function requireRole($roles) {
    requireLogin();
    $user = getCurrentUser();
    if (!$user) {
        session_destroy();
        $baseUrl = get_base_url();
        header("Location: {$baseUrl}/login.php");
        exit();
    }

    if (is_string($roles)) {
        $roles = [$roles];
    }

    if (!in_array($user['role_name'], $roles)) {
        $_SESSION['flash_error'] = "Unauthorized access attempt for your role ({$user['role_name']}).";
        redirectByRole($user['role_name']);
        exit();
    }
}

function loginUser($email, $password) {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("
        SELECT u.*, r.role_name 
        FROM users u 
        JOIN roles r ON u.role_id = r.id 
        WHERE u.email = ?
    ");
    $stmt->execute([trim($email)]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        if ($user['status'] !== 'Active') {
            return ['success' => false, 'message' => 'Your account is ' . strtolower($user['status']) . '. Please contact administration.'];
        }
        
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_role'] = $user['role_name'];
        $_SESSION['user_email'] = $user['email'];

        logAudit($user['id'], $user['name'], $user['role_name'], 'USER_LOGIN', 'Logged into MediCareX dashboard.');
        
        return ['success' => true, 'user' => $user];
    }

    logAudit(null, $email, 'Guest', 'LOGIN_FAILED', 'Failed login attempt for email: ' . $email);
    return ['success' => false, 'message' => 'Invalid email address or password.'];
}

function logoutUser() {
    if (isLoggedIn()) {
        $user = getCurrentUser();
        if ($user) {
            logAudit($user['id'], $user['name'], $user['role_name'], 'USER_LOGOUT', 'Logged out of system.');
        }
    }
    $_SESSION = array();
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
}

function redirectByRole($role_name) {
    $baseUrl = get_base_url();
    switch (strtolower($role_name)) {
        case 'admin':
            header("Location: {$baseUrl}/admin/index.php");
            break;
        case 'doctor':
            header("Location: {$baseUrl}/doctor/index.php");
            break;
        case 'nurse':
            header("Location: {$baseUrl}/nurse/index.php");
            break;
        case 'receptionist':
            header("Location: {$baseUrl}/reception/index.php");
            break;
        case 'pharmacist':
            header("Location: {$baseUrl}/pharmacy/index.php");
            break;
        case 'lab technician':
            header("Location: {$baseUrl}/laboratory/index.php");
            break;
        case 'patient':
            header("Location: {$baseUrl}/patient/index.php");
            break;
        default:
            header("Location: {$baseUrl}/index.php");
            break;
    }
    exit();
}
