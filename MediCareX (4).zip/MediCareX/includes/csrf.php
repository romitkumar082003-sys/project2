<?php
// MediCareX - CSRF Security Protection
// Developed by Romit Kumar

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function renderCSRFField() {
    $token = generateCSRFToken();
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($token) . '">';
}

function verifyCSRFToken($token) {
    if (isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token)) {
        return true;
    }
    return false;
}

function validateCSRFOrDie() {
    $token = $_POST['csrf_token'] ?? '';
    if (!verifyCSRFToken($token)) {
        die("<div style='max-width:500px; margin:50px auto; padding:20px; background:#fee2e2; border-radius:8px; color:#991b1b; font-family:sans-serif;'>
            <h3>Security Violation</h3>
            <p>Invalid or expired CSRF security token. Please refresh the page and try submitting again.</p>
        </div>");
    }
}
