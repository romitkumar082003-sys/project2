<?php
// MediCareX - Doctor Patient List
// Developed by Romit Kumar

$pageTitle = 'My Patients';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole('Doctor');

$user = getCurrentUser();
$pdo = getDBConnection();

$docStmt = $pdo->prepare("SELECT id FROM doctors WHERE user_id = ?");
$docStmt->execute([$user['id']]);
$doctor_id = $docStmt->fetchColumn();

$patients = $pdo->prepare("
    SELECT DISTINCT p.*, u.name, u.email, u.phone 
    FROM patients p
    JOIN users u ON p.user_id = u.id
    JOIN appointments a ON a.patient_id = p.id
    WHERE a.doctor_id = ?
    ORDER BY p.id DESC
");
$patients->execute([$doctor_id]);
$patientList = $patients->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold mb-0">Assigned Patients</h3>
            </div>

            <div class="card card-custom border-0 shadow-sm">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light fs-7 text-uppercase">
                                <tr>
                                    <th>Patient Code</th>
                                    <th>Name</th>
                                    <th>Contact</th>
                                    <th>Gender / DOB</th>
                                    <th>Blood Group</th>
                                    <th>Medical History</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($patientList)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-5 text-muted">
                                            <i class="bi bi-people fs-1 d-block mb-2"></i>
                                            No patients recorded in your consultation roster.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($patientList as $pat): ?>
                                        <tr>
                                            <td class="fw-bold text-primary"><?= htmlspecialchars($pat['patient_code']) ?></td>
                                            <td class="fw-bold"><?= htmlspecialchars($pat['name']) ?></td>
                                            <td>
                                                <div><?= htmlspecialchars($pat['phone']) ?></div>
                                                <small class="text-muted"><?= htmlspecialchars($pat['email']) ?></small>
                                            </td>
                                            <td><?= htmlspecialchars($pat['gender']) ?> (<?= formatDate($pat['dob'], 'd M Y') ?>)</td>
                                            <td><span class="badge bg-danger fs-7"><?= htmlspecialchars($pat['blood_group']) ?></span></td>
                                            <td class="fs-7 text-muted"><?= htmlspecialchars($pat['medical_history'] ?? 'None recorded') ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
