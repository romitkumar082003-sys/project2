<?php
// MediCareX - Doctor Prescriptions Archive
// Developed by Romit Kumar

$pageTitle = 'Issued Prescriptions';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole('Doctor');

$user = getCurrentUser();
$pdo = getDBConnection();

$docStmt = $pdo->prepare("SELECT id FROM doctors WHERE user_id = ?");
$docStmt->execute([$user['id']]);
$doctor_id = $docStmt->fetchColumn();

$rxs = $pdo->prepare("
    SELECT rx.*, c.diagnosis, p.patient_code, u_p.name as patient_name
    FROM prescriptions rx
    LEFT JOIN consultations c ON rx.consultation_id = c.id
    JOIN patients p ON rx.patient_id = p.id
    JOIN users u_p ON p.user_id = u_p.id
    WHERE rx.doctor_id = ?
    ORDER BY rx.created_at DESC
");
$rxs->execute([$doctor_id]);
$prescriptionList = $rxs->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold mb-0">Issued Prescriptions</h3>
            </div>

            <div class="card card-custom border-0 shadow-sm">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light fs-7 text-uppercase">
                                <tr>
                                    <th>Rx ID</th>
                                    <th>Patient</th>
                                    <th>Patient Code</th>
                                    <th>Diagnosis</th>
                                    <th>Date</th>
                                    <th class="text-end">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($prescriptionList)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-5 text-muted">
                                            <i class="bi bi-capsule fs-1 d-block mb-2"></i>
                                            No prescriptions issued yet.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($prescriptionList as $rx): ?>
                                        <tr>
                                            <td class="fw-bold text-primary">Rx #<?= $rx['id'] ?></td>
                                            <td class="fw-bold"><?= htmlspecialchars($rx['patient_name']) ?></td>
                                            <td><?= htmlspecialchars($rx['patient_code']) ?></td>
                                            <td class="fs-7 text-dark"><?= htmlspecialchars($rx['diagnosis'] ?? 'N/A') ?></td>
                                            <td><?= formatDate($rx['created_at']) ?></td>
                                            <td class="text-end">
                                                <a href="<?= get_base_url() ?>/print_prescription.php?id=<?= $rx['id'] ?>" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill">
                                                    <i class="bi bi-printer me-1"></i> Print / PDF
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
