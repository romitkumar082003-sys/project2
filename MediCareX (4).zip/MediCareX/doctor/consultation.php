<?php
// MediCareX - Live Doctor Consultation Portal
// Developed by Romit Kumar

$pageTitle = 'OPD Consultation Room';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

requireRole('Doctor');

$user = getCurrentUser();
$pdo = getDBConnection();

$docStmt = $pdo->prepare("SELECT * FROM doctors WHERE user_id = ?");
$docStmt->execute([$user['id']]);
$doctor = $docStmt->fetch();
$doctor_id = $doctor['id'];

$apt_id = intval($_GET['apt_id'] ?? 0);

$aptStmt = $pdo->prepare("
    SELECT a.*, p.patient_code, u_p.name as patient_name, p.dob, p.gender, p.blood_group, p.medical_history, p.id as patient_id
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    JOIN users u_p ON p.user_id = u_p.id
    WHERE a.id = ? AND a.doctor_id = ?
");
$aptStmt->execute([$apt_id, $doctor_id]);
$apt = $aptStmt->fetch();

if (!$apt) {
    setFlash('error', "Invalid or unassigned appointment ID.");
    header("Location: index.php");
    exit();
}

$medicinesList = $pdo->query("SELECT * FROM medicines WHERE quantity > 0 ORDER BY name ASC")->fetchAll();
$labTestsList = $pdo->query("SELECT * FROM lab_tests ORDER BY test_name ASC")->fetchAll();

// Fetch recent vitals if logged by nurse
$vitStmt = $pdo->prepare("SELECT * FROM vitals WHERE patient_id = ? ORDER BY recorded_at DESC LIMIT 1");
$vitStmt->execute([$apt['patient_id']]);
$latestVitals = $vitStmt->fetch();

$errorMsg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validateCSRFOrDie();

    $symptoms = cleanInput($_POST['symptoms'] ?? '');
    $diagnosis = cleanInput($_POST['diagnosis'] ?? '');
    $bp = cleanInput($_POST['bp'] ?? '120/80');
    $temp = cleanInput($_POST['temp'] ?? '98.6 F');
    $pulse = cleanInput($_POST['pulse'] ?? '72 bpm');
    $weight = cleanInput($_POST['weight'] ?? '70 kg');
    $notes = cleanInput($_POST['notes'] ?? '');
    $follow_up_date = cleanInput($_POST['follow_up_date'] ?? '');

    $med_names = $_POST['med_name'] ?? [];
    $dosages = $_POST['dosage'] ?? [];
    $frequencies = $_POST['frequency'] ?? [];
    $durations = $_POST['duration'] ?? [];
    $instructions = $_POST['instructions'] ?? [];

    $lab_test_id = intval($_POST['lab_test_id'] ?? 0);
    $lab_priority = cleanInput($_POST['lab_priority'] ?? 'Normal');

    if (empty($symptoms) || empty($diagnosis)) {
        $errorMsg = "Please fill in symptoms and diagnosis.";
    } else {
        try {
            $pdo->beginTransaction();

            // 1. Insert Consultation
            $insC = $pdo->prepare("
                INSERT INTO consultations (appointment_id, patient_id, doctor_id, symptoms, diagnosis, bp, temp, weight, pulse, notes, follow_up_date) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $insC->execute([
                $apt_id, $apt['patient_id'], $doctor_id, $symptoms, $diagnosis,
                $bp, $temp, $weight, $pulse, $notes, !empty($follow_up_date) ? $follow_up_date : null
            ]);
            $consultation_id = $pdo->lastInsertId();

            // 2. Insert Prescription & Items
            if (!empty($med_names)) {
                $insRx = $pdo->prepare("INSERT INTO prescriptions (consultation_id, patient_id, doctor_id) VALUES (?, ?, ?)");
                $insRx->execute([$consultation_id, $apt['patient_id'], $doctor_id]);
                $rx_id = $pdo->lastInsertId();

                $insItem = $pdo->prepare("
                    INSERT INTO prescription_items (prescription_id, medicine_name, dosage, frequency, duration, instructions) 
                    VALUES (?, ?, ?, ?, ?, ?)
                ");
                for ($i = 0; $i < count($med_names); $i++) {
                    if (!empty(trim($med_names[$i]))) {
                        $insItem->execute([
                            $rx_id,
                            cleanInput($med_names[$i]),
                            cleanInput($dosages[$i] ?? '1 tablet'),
                            cleanInput($frequencies[$i] ?? 'Twice daily'),
                            cleanInput($durations[$i] ?? '5 days'),
                            cleanInput($instructions[$i] ?? 'Take after food')
                        ]);
                    }
                }
            }

            // 3. Insert Lab Request if selected
            $labCost = 0.00;
            if ($lab_test_id > 0) {
                $lCode = generateCode('LREQ', 'lab_requests', 'request_code');
                $insLab = $pdo->prepare("
                    INSERT INTO lab_requests (request_code, patient_id, doctor_id, consultation_id, test_id, priority, notes, status) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')
                ");
                $insLab->execute([$lCode, $apt['patient_id'], $doctor_id, $consultation_id, $lab_test_id, $lab_priority, $notes]);

                $cStmt = $pdo->prepare("SELECT cost FROM lab_tests WHERE id = ?");
                $cStmt->execute([$lab_test_id]);
                $labCost = floatval($cStmt->fetchColumn());
            }

            // 4. Update Appointment Status to Completed
            $updApt = $pdo->prepare("UPDATE appointments SET status = 'Completed' WHERE id = ?");
            $updApt->execute([$apt_id]);

            // 5. Generate Invoice
            $invCode = generateCode('INV', 'invoices', 'invoice_code');
            $consultFee = floatval($doctor['consultation_fee']);
            $subtotal = $consultFee + $labCost;
            $tax = $subtotal * 0.05;
            $grand_total = $subtotal + $tax;

            $insInv = $pdo->prepare("
                INSERT INTO invoices (invoice_code, patient_id, appointment_id, consultation_fee, lab_charges, subtotal, tax, grand_total, payment_status) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending')
            ");
            $insInv->execute([$invCode, $apt['patient_id'], $apt_id, $consultFee, $labCost, $subtotal, $tax, $grand_total]);

            $pdo->commit();

            logAudit($user['id'], $user['name'], 'Doctor', 'CONSULTATION_COMPLETE', "Completed OPD consultation for Patient {$apt['patient_code']} (Apt: {$apt['appointment_code']}).");
            
            // Get patient user id
            $pUserStmt = $pdo->prepare("SELECT user_id FROM patients WHERE id = ?");
            $pUserStmt->execute([$apt['patient_id']]);
            $pUserId = $pUserStmt->fetchColumn();
            if ($pUserId) {
                addNotification($pUserId, 'Consultation Completed', "Dr. {$user['name']} has completed your consultation and issued your prescription.", 'patient/prescriptions.php');
            }

            setFlash('success', "Consultation completed successfully for Patient {$apt['patient_name']}! Invoice {$invCode} generated.");
            header("Location: index.php");
            exit();
        } catch (Exception $e) {
            $pdo->rollBack();
            $errorMsg = "Database error while completing consultation: " . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1">Live OPD Consultation</h3>
                    <p class="text-muted mb-0">Token: <span class="badge bg-primary fs-6"><?= htmlspecialchars($apt['token_number']) ?></span> | Appointment: <strong><?= htmlspecialchars($apt['appointment_code']) ?></strong></p>
                </div>
                <a href="index.php" class="btn btn-outline-secondary rounded-pill">Back to OPD Queue</a>
            </div>

            <?php if ($errorMsg): ?>
                <div class="alert alert-danger border-0 shadow-sm mb-4">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= htmlspecialchars($errorMsg) ?>
                </div>
            <?php endif; ?>

            <!-- Patient Info Summary Banner -->
            <div class="card card-custom p-3 bg-light border-0 mb-4 shadow-sm">
                <div class="row align-items-center fs-7">
                    <div class="col-md-3">
                        <small class="text-muted d-block">PATIENT NAME</small>
                        <h6 class="fw-bold mb-0 text-primary"><?= htmlspecialchars($apt['patient_name']) ?></h6>
                    </div>
                    <div class="col-md-2">
                        <small class="text-muted d-block">PATIENT ID</small>
                        <span class="fw-bold"><?= htmlspecialchars($apt['patient_code']) ?></span>
                    </div>
                    <div class="col-md-2">
                        <small class="text-muted d-block">GENDER / BLOOD</small>
                        <span class="fw-bold"><?= htmlspecialchars($apt['gender']) ?> (<?= htmlspecialchars($apt['blood_group']) ?>)</span>
                    </div>
                    <div class="col-md-5">
                        <small class="text-muted d-block">PREVIOUS MEDICAL HISTORY</small>
                        <span class="text-dark fw-semibold"><?= htmlspecialchars($apt['medical_history'] ?? 'No prior chronic conditions recorded') ?></span>
                    </div>
                </div>
            </div>

            <form method="POST" action="">
                <?= renderCSRFField() ?>

                <div class="row g-4">
                    <!-- Left Panel: Vitals, Symptoms, Diagnosis -->
                    <div class="col-lg-6">
                        <div class="card card-custom p-4 h-100">
                            <h5 class="fw-bold text-primary mb-3"><i class="bi bi-heart-pulse-fill me-2"></i> 1. Clinical Examination</h5>
                            
                            <div class="row g-2 mb-3 bg-body-tertiary p-3 rounded border">
                                <div class="col-6 col-md-3">
                                    <label class="form-label fs-8 fw-bold">BP</label>
                                    <input type="text" name="bp" class="form-control form-control-sm" value="<?= htmlspecialchars($latestVitals['bp'] ?? '120/80') ?>">
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label fs-8 fw-bold">TEMP</label>
                                    <input type="text" name="temp" class="form-control form-control-sm" value="<?= htmlspecialchars($latestVitals['temperature'] ?? '98.6 F') ?>">
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label fs-8 fw-bold">PULSE</label>
                                    <input type="text" name="pulse" class="form-control form-control-sm" value="<?= htmlspecialchars($latestVitals['pulse'] ?? '72 bpm') ?>">
                                </div>
                                <div class="col-6 col-md-3">
                                    <label class="form-label fs-8 fw-bold">WEIGHT</label>
                                    <input type="text" name="weight" class="form-control form-control-sm" value="<?= htmlspecialchars($latestVitals['weight'] ?? '70 kg') ?>">
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Patient Symptoms *</label>
                                <textarea name="symptoms" class="form-control" rows="3" placeholder="e.g. High fever, dry cough, chest tightness..." required><?= htmlspecialchars($apt['reason'] ?? '') ?></textarea>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Medical Diagnosis *</label>
                                <textarea name="diagnosis" class="form-control" rows="3" placeholder="e.g. Upper Respiratory Tract Infection (URTI)..." required></textarea>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Clinical Advice / Notes</label>
                                <textarea name="notes" class="form-control" rows="2" placeholder="Rest, hydration, follow-up if symptoms persist..."></textarea>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Follow-Up Date</label>
                                <input type="date" name="follow_up_date" class="form-control" min="<?= date('Y-m-d') ?>">
                            </div>
                        </div>
                    </div>

                    <!-- Right Panel: Rx & Lab Test Order -->
                    <div class="col-lg-6">
                        <div class="card card-custom p-4 mb-4">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h5 class="fw-bold text-success mb-0"><i class="bi bi-capsule me-2"></i> 2. Prescribe Medications</h5>
                                <button type="button" class="btn btn-sm btn-outline-success rounded-pill" onclick="addMedRow()"><i class="bi bi-plus-lg"></i> Add Medicine</button>
                            </div>

                            <div id="medicineRows">
                                <div class="row g-2 mb-2 med-row">
                                    <div class="col-md-5">
                                        <input type="text" name="med_name[]" class="form-control form-control-sm" placeholder="Medicine Name (e.g. Paracetamol 650mg)" list="medsOptions">
                                    </div>
                                    <div class="col-md-2">
                                        <input type="text" name="dosage[]" class="form-control form-control-sm" placeholder="Dosage (1 tab)">
                                    </div>
                                    <div class="col-md-2">
                                        <input type="text" name="frequency[]" class="form-control form-control-sm" placeholder="Freq (1-0-1)">
                                    </div>
                                    <div class="col-md-3">
                                        <input type="text" name="duration[]" class="form-control form-control-sm" placeholder="Duration (5 days)">
                                    </div>
                                </div>
                            </div>

                            <datalist id="medsOptions">
                                <?php foreach ($medicinesList as $med): ?>
                                    <option value="<?= htmlspecialchars($med['name']) ?>">
                                <?php endforeach; ?>
                            </datalist>
                        </div>

                        <div class="card card-custom p-4 mb-4">
                            <h5 class="fw-bold text-info mb-3"><i class="bi bi-journal-medical me-2"></i> 3. Order Laboratory Tests</h5>
                            <div class="row g-3">
                                <div class="col-md-8">
                                    <label class="form-label fw-semibold">Select Test</label>
                                    <select name="lab_test_id" class="form-select">
                                        <option value="0">-- No Lab Test Required --</option>
                                        <?php foreach ($labTestsList as $lt): ?>
                                            <option value="<?= $lt['id'] ?>"><?= htmlspecialchars($lt['test_name']) ?> (₹<?= $lt['cost'] ?>)</option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold">Priority</label>
                                    <select name="lab_priority" class="form-select">
                                        <option value="Normal">Normal</option>
                                        <option value="Urgent">Urgent</option>
                                        <option value="Emergency">Emergency</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="card card-custom p-4 text-center">
                            <button type="submit" class="btn btn-primary btn-lg rounded-pill px-5 shadow">
                                <i class="bi bi-check-circle-fill me-2"></i> Complete Consultation & Generate Rx
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>

<script>
function addMedRow() {
    const container = document.getElementById('medicineRows');
    const div = document.createElement('div');
    div.className = 'row g-2 mb-2 med-row';
    div.innerHTML = `
        <div class="col-md-5">
            <input type="text" name="med_name[]" class="form-control form-control-sm" placeholder="Medicine Name" list="medsOptions">
        </div>
        <div class="col-md-2">
            <input type="text" name="dosage[]" class="form-control form-control-sm" placeholder="Dosage">
        </div>
        <div class="col-md-2">
            <input type="text" name="frequency[]" class="form-control form-control-sm" placeholder="Freq">
        </div>
        <div class="col-md-3">
            <input type="text" name="duration[]" class="form-control form-control-sm" placeholder="Duration">
        </div>
    `;
    container.appendChild(div);
}
</script>
