<?php
// MediCareX - Doctor Lab Request Tracker
// Developed by Romit Kumar

$pageTitle = 'Lab Test Orders';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole('Doctor');

$user = getCurrentUser();
$pdo = getDBConnection();

$docStmt = $pdo->prepare("SELECT id FROM doctors WHERE user_id = ?");
$docStmt->execute([$user['id']]);
$doctor_id = $docStmt->fetchColumn();

$requests = $pdo->prepare("
    SELECT req.*, lt.test_name, lt.category, p.patient_code, u_p.name as patient_name
    FROM lab_requests req
    JOIN lab_tests lt ON req.test_id = lt.id
    JOIN patients p ON req.patient_id = p.id
    JOIN users u_p ON p.user_id = u_p.id
    WHERE req.doctor_id = ?
    ORDER BY req.created_at DESC
");
$requests->execute([$doctor_id]);
$requestList = $requests->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold mb-0">Laboratory Orders Status</h3>
            </div>

            <div class="card card-custom border-0 shadow-sm">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light fs-7 text-uppercase">
                                <tr>
                                    <th>Request Code</th>
                                    <th>Patient</th>
                                    <th>Test Name</th>
                                    <th>Priority</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($requestList)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-5 text-muted">
                                            <i class="bi bi-journal-medical fs-1 d-block mb-2"></i>
                                            No laboratory test requests created yet.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($requestList as $req): ?>
                                        <tr>
                                            <td class="fw-bold text-primary"><?= htmlspecialchars($req['request_code']) ?></td>
                                            <td>
                                                <div class="fw-bold"><?= htmlspecialchars($req['patient_name']) ?></div>
                                                <small class="text-muted"><?= htmlspecialchars($req['patient_code']) ?></small>
                                            </td>
                                            <td class="fw-bold"><?= htmlspecialchars($req['test_name']) ?></td>
                                            <td><span class="badge bg-secondary"><?= htmlspecialchars($req['priority']) ?></span></td>
                                            <td><?= formatDate($req['created_at']) ?></td>
                                            <td><?= renderStatusBadge($req['status']) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
