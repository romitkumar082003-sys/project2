<?php
// MediCareX - Doctor Dashboard & Live Queue Workspace
// Developed by Romit Kumar

$pageTitle = 'Doctor OPD Dashboard';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole('Doctor');

$user = getCurrentUser();
$pdo = getDBConnection();

$docStmt = $pdo->prepare("SELECT * FROM doctors WHERE user_id = ?");
$docStmt->execute([$user['id']]);
$doctor = $docStmt->fetch();

if (!$doctor) {
    die("Doctor record missing.");
}

$doctor_id = $doctor['id'];
$today = date('Y-m-d');

// Stats
$cntToday = $pdo->prepare("SELECT COUNT(*) FROM appointments WHERE doctor_id = ? AND appointment_date = ?");
$cntToday->execute([$doctor_id, $today]);
$todayCount = $cntToday->fetchColumn();

$cntCheckedIn = $pdo->prepare("SELECT COUNT(*) FROM appointments WHERE doctor_id = ? AND appointment_date = ? AND status = 'Checked In'");
$cntCheckedIn->execute([$doctor_id, $today]);
$checkedInCount = $cntCheckedIn->fetchColumn();

$cntCompleted = $pdo->prepare("SELECT COUNT(*) FROM appointments WHERE doctor_id = ? AND appointment_date = ? AND status = 'Completed'");
$cntCompleted->execute([$doctor_id, $today]);
$completedCount = $cntCompleted->fetchColumn();

// Currently Serving / Checked In Queue
$queueStmt = $pdo->prepare("
    SELECT a.*, p.patient_code, u_p.name as patient_name, u_p.phone as patient_phone, p.gender, p.blood_group
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    JOIN users u_p ON p.user_id = u_p.id
    WHERE a.doctor_id = ? AND a.appointment_date = ? AND a.status IN ('Checked In', 'In Consultation')
    ORDER BY a.id ASC
");
$queueStmt->execute([$doctor_id, $today]);
$queueList = $queueStmt->fetchAll();

$servingToken = !empty($queueList) ? $queueList[0]['token_number'] : 'None';

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <?php displayFlash(); ?>

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1">Dr. <?= htmlspecialchars($user['name']) ?>'s OPD Workspace</h3>
                    <p class="text-muted mb-0">Specialization: <?= htmlspecialchars($doctor['specialization']) ?> | Consultation Fee: <?= formatCurrency($doctor['consultation_fee']) ?></p>
                </div>
            </div>

            <!-- Queue Token Hero Widget -->
            <div class="card card-custom bg-primary text-white p-4 mb-4 shadow-lg border-0">
                <div class="row align-items-center">
                    <div class="col-md-4 border-end border-white-50 text-center text-md-start mb-3 mb-md-0">
                        <small class="text-white-50 text-uppercase fw-bold fs-8">Current Active Token</small>
                        <h1 class="display-3 fw-extrabold mb-0 text-white"><?= htmlspecialchars($servingToken) ?></h1>
                        <span class="badge bg-success mt-2">Serving Now</span>
                    </div>
                    <div class="col-md-8 ps-md-4">
                        <div class="row text-center">
                            <div class="col-4">
                                <h3 class="fw-bold text-white mb-0"><?= $todayCount ?></h3>
                                <small class="text-white-50">Today's Total</small>
                            </div>
                            <div class="col-4">
                                <h3 class="fw-bold text-warning mb-0"><?= $checkedInCount ?></h3>
                                <small class="text-white-50">Checked In Queue</small>
                            </div>
                            <div class="col-4">
                                <h3 class="fw-bold text-success mb-0"><?= $completedCount ?></h3>
                                <small class="text-white-50">Completed OPD</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Checked-in Queue List -->
            <div class="card card-custom border-0 shadow-sm mb-4">
                <div class="card-header bg-body border-0 py-3 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0"><i class="bi bi-people-fill me-2 text-primary"></i> Patients Waiting for Consultation</h5>
                    <span class="badge bg-warning text-dark px-3 py-2"><?= count($queueList) ?> Patients Waiting</span>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light fs-7 text-uppercase">
                            <tr>
                                <th>Token</th>
                                <th>Patient Name</th>
                                <th>Code</th>
                                <th>Gender / Blood</th>
                                <th>Reason for Visit</th>
                                <th>Status</th>
                                <th class="text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($queueList)): ?>
                                <tr>
                                    <td colspan="7" class="text-center py-4 text-muted">
                                        <i class="bi bi-check-circle-fill fs-1 d-block mb-2 text-success"></i>
                                        No patients waiting in queue right now.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($queueList as $q): ?>
                                    <tr>
                                        <td><span class="badge bg-primary px-3 py-2 fs-6"><?= htmlspecialchars($q['token_number']) ?></span></td>
                                        <td class="fw-bold"><?= htmlspecialchars($q['patient_name']) ?></td>
                                        <td class="text-primary fw-semibold"><?= htmlspecialchars($q['patient_code']) ?></td>
                                        <td><?= htmlspecialchars($q['gender']) ?> (<?= htmlspecialchars($q['blood_group']) ?>)</td>
                                        <td class="fs-7 text-muted"><?= htmlspecialchars($q['reason'] ?? 'General Checkup') ?></td>
                                        <td><?= renderStatusBadge($q['status']) ?></td>
                                        <td class="text-end">
                                            <a href="consultation.php?apt_id=<?= $q['id'] ?>" class="btn btn-sm btn-primary rounded-pill px-3 shadow-sm">
                                                <i class="bi bi-stethoscope me-1"></i> Start Consultation
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
