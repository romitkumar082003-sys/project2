<?php
// MediCareX - Doctor Appointment Roster
// Developed by Romit Kumar

$pageTitle = 'Doctor Appointments';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole('Doctor');

$user = getCurrentUser();
$pdo = getDBConnection();

$docStmt = $pdo->prepare("SELECT id FROM doctors WHERE user_id = ?");
$docStmt->execute([$user['id']]);
$doctor_id = $docStmt->fetchColumn();

$statusFilter = cleanInput($_GET['status'] ?? 'All');
$query = "
    SELECT a.*, p.patient_code, u_p.name as patient_name, u_p.phone as patient_phone, p.gender, p.blood_group
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    JOIN users u_p ON p.user_id = u_p.id
    WHERE a.doctor_id = ?
";
$params = [$doctor_id];

if ($statusFilter !== 'All') {
    $query .= " AND a.status = ?";
    $params[] = $statusFilter;
}

$query .= " ORDER BY a.appointment_date DESC, a.id DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$appointments = $stmt->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1">Appointment Roster</h3>
                    <p class="text-muted mb-0">Manage scheduled patient consultations</p>
                </div>
            </div>

            <!-- Status Filters -->
            <div class="d-flex gap-2 mb-4 overflow-auto">
                <a href="appointments.php?status=All" class="btn btn-sm <?= ($statusFilter === 'All') ? 'btn-primary' : 'btn-outline-secondary' ?> rounded-pill">All Appointments</a>
                <a href="appointments.php?status=Checked In" class="btn btn-sm <?= ($statusFilter === 'Checked In') ? 'btn-primary' : 'btn-outline-secondary' ?> rounded-pill">Checked In</a>
                <a href="appointments.php?status=Confirmed" class="btn btn-sm <?= ($statusFilter === 'Confirmed') ? 'btn-primary' : 'btn-outline-secondary' ?> rounded-pill">Confirmed</a>
                <a href="appointments.php?status=Completed" class="btn btn-sm <?= ($statusFilter === 'Completed') ? 'btn-primary' : 'btn-outline-secondary' ?> rounded-pill">Completed</a>
                <a href="appointments.php?status=Cancelled" class="btn btn-sm <?= ($statusFilter === 'Cancelled') ? 'btn-primary' : 'btn-outline-secondary' ?> rounded-pill">Cancelled</a>
            </div>

            <div class="card card-custom border-0 shadow-sm">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light fs-7 text-uppercase">
                                <tr>
                                    <th>Token</th>
                                    <th>Code</th>
                                    <th>Patient</th>
                                    <th>Date & Slot</th>
                                    <th>Reason</th>
                                    <th>Status</th>
                                    <th class="text-end">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($appointments)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center py-5 text-muted">
                                            <i class="bi bi-calendar-x fs-1 d-block mb-2"></i>
                                            No appointments found.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($appointments as $apt): ?>
                                        <tr>
                                            <td><span class="badge bg-primary px-3 py-2 fs-7"><?= htmlspecialchars($apt['token_number']) ?></span></td>
                                            <td class="fw-bold text-primary"><?= htmlspecialchars($apt['appointment_code']) ?></td>
                                            <td>
                                                <div class="fw-bold"><?= htmlspecialchars($apt['patient_name']) ?></div>
                                                <small class="text-muted"><?= htmlspecialchars($apt['patient_code']) ?> (<?= htmlspecialchars($apt['gender']) ?>)</small>
                                            </td>
                                            <td>
                                                <div class="fw-semibold"><?= formatDate($apt['appointment_date'], 'd M Y') ?></div>
                                                <small class="text-muted"><?= htmlspecialchars($apt['time_slot']) ?></small>
                                            </td>
                                            <td class="fs-7 text-muted"><?= htmlspecialchars($apt['reason'] ?? 'N/A') ?></td>
                                            <td><?= renderStatusBadge($apt['status']) ?></td>
                                            <td class="text-end">
                                                <?php if (in_array($apt['status'], ['Checked In', 'Confirmed'])): ?>
                                                    <a href="consultation.php?apt_id=<?= $apt['id'] ?>" class="btn btn-sm btn-primary rounded-pill px-3">
                                                        <i class="bi bi-stethoscope me-1"></i> Consult
                                                    </a>
                                                <?php else: ?>
                                                    <span class="text-muted fs-7">Completed</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
