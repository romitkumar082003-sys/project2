<?php
// MediCareX - Unified Login Portal
// Developed by Romit Kumar

$pageTitle = 'Portal Login';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/csrf.php';

$baseUrl = get_base_url();

// ⚡ 1-Click Instant Demo Login for Presentation / Demos
$demoLogins = [
    'admin' => 'admin@medicarex.local',
    'doctor' => 'doctor@medicarex.local',
    'nurse' => 'nurse@medicarex.local',
    'reception' => 'reception@medicarex.local',
    'pharmacy' => 'pharmacy@medicarex.local',
    'lab' => 'lab@medicarex.local',
    'patient' => 'patient@medicarex.local',
];

$quickRole = $_GET['demo_role'] ?? '';
if (!empty($quickRole) && isset($demoLogins[$quickRole])) {
    $res = loginUser($demoLogins[$quickRole], 'password123');
    if ($res['success']) {
        redirectByRole($res['user']['role_name']);
        exit();
    }
}

if (isLoggedIn()) {
    $user = getCurrentUser();
    redirectByRole($user['role_name']);
    exit();
}

$errorMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validateCSRFOrDie();
    $email = cleanInput($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $res = loginUser($email, $password);
    if ($res['success']) {
        redirectByRole($res['user']['role_name']);
        exit();
    } else {
        $errorMsg = $res['message'];
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal Login - MediCareX</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>/assets/css/style.css">
</head>
<body class="bg-body-tertiary d-flex align-items-center justify-content-center min-vh-100 py-4">

    <div class="container" style="max-width: 900px;">
        <div class="row g-0 card card-custom flex-md-row overflow-hidden border-0 shadow-lg">
            
            <!-- Left Info Panel -->
            <div class="col-md-5 bg-primary text-white p-4 p-lg-5 d-flex flex-column justify-content-between">
                <div>
                    <div class="d-flex align-items-center mb-4">
                        <div class="rounded-circle bg-white text-primary p-2 me-2 d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;">
                            <i class="bi bi-cross-circle-fill fs-5"></i>
                        </div>
                        <h4 class="fw-bold mb-0">MediCareX</h4>
                    </div>
                    <h3 class="fw-bold mb-3">Smart Hospital Management</h3>
                    <p class="fs-7 text-white-50">
                        Unified healthcare SaaS platform for Patients, Doctors, Nurses, Reception, Pharmacy, Laboratory, and Administration.
                    </p>
                </div>

                <!-- Demo Credentials Quick Fill Panel -->
                <div class="mt-4 pt-3 border-top border-white-50">
                    <span class="fs-8 text-uppercase fw-bold text-white d-block mb-2">⚡ 1-Click Instant Demo Login (Zero Setup)</span>
                    <div class="d-flex flex-wrap gap-1">
                        <a href="?demo_role=admin" class="btn btn-sm btn-light fw-bold fs-8 py-1 px-2 text-decoration-none shadow-sm"><i class="bi bi-shield-lock text-primary me-1"></i>Admin</a>
                        <a href="?demo_role=doctor" class="btn btn-sm btn-light fw-bold fs-8 py-1 px-2 text-decoration-none shadow-sm"><i class="bi bi-heart-pulse text-danger me-1"></i>Doctor</a>
                        <a href="?demo_role=nurse" class="btn btn-sm btn-light fw-bold fs-8 py-1 px-2 text-decoration-none shadow-sm"><i class="bi bi-activity text-warning me-1"></i>Nurse</a>
                        <a href="?demo_role=reception" class="btn btn-sm btn-light fw-bold fs-8 py-1 px-2 text-decoration-none shadow-sm"><i class="bi bi-calendar-check text-info me-1"></i>Reception</a>
                        <a href="?demo_role=pharmacy" class="btn btn-sm btn-light fw-bold fs-8 py-1 px-2 text-decoration-none shadow-sm"><i class="bi bi-capsule text-success me-1"></i>Pharmacy</a>
                        <a href="?demo_role=lab" class="btn btn-sm btn-light fw-bold fs-8 py-1 px-2 text-decoration-none shadow-sm"><i class="bi bi-eyedropper text-secondary me-1"></i>Lab Tech</a>
                        <a href="?demo_role=patient" class="btn btn-sm btn-light fw-bold fs-8 py-1 px-2 text-decoration-none shadow-sm"><i class="bi bi-person text-dark me-1"></i>Patient</a>
                    </div>
                    <small class="fs-8 text-white-50 d-block mt-2">💡 <em>Click any button above to instantly open that role's dashboard. No database setup or password typing needed!</em></small>
                </div>

                <div class="fs-8 text-white-50 mt-4">
                    <i class="bi bi-code-slash"></i> Developed by Romit Kumar
                </div>
            </div>

            <!-- Right Login Form -->
            <div class="col-md-7 p-4 p-lg-5 bg-body">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h4 class="fw-bold mb-0">Sign In</h4>
                    <button class="btn btn-outline-secondary border-0 rounded-circle" id="themeToggleBtn" type="button">
                        <i class="bi bi-moon-stars-fill text-primary"></i>
                    </button>
                </div>

                <?php displayFlash(); ?>

                <?php if ($errorMsg): ?>
                    <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm" role="alert">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= htmlspecialchars($errorMsg) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <?= renderCSRFField() ?>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Email Address</label>
                        <div class="input-group">
                            <span class="input-group-text bg-body-tertiary border-end-0"><i class="bi bi-envelope text-muted"></i></span>
                            <input type="email" name="email" id="emailInput" class="form-control border-start-0" placeholder="e.g. admin@medicarex.local" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <label class="form-label fw-semibold">Password</label>
                            <a href="<?= $baseUrl ?>/forgot_password.php" class="fs-7 text-decoration-none">Forgot?</a>
                        </div>
                        <div class="input-group">
                            <span class="input-group-text bg-body-tertiary border-end-0"><i class="bi bi-lock text-muted"></i></span>
                            <input type="password" name="password" id="passwordInput" class="form-control border-start-0" placeholder="••••••••" required>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary btn-lg w-100 rounded-pill shadow-sm mb-3">
                        <i class="bi bi-box-arrow-in-right me-2"></i> Secure Sign In
                    </button>

                    <div class="text-center fs-7 text-muted">
                        Don't have a patient account? <a href="<?= $baseUrl ?>/register.php" class="fw-bold text-decoration-none">Register Here</a>
                    </div>
                </form>

                <div class="text-center mt-4 pt-3 border-top fs-8 text-muted">
                    <a href="<?= $baseUrl ?>/index.php" class="text-muted text-decoration-none"><i class="bi bi-arrow-left me-1"></i> Back to Hospital Landing Page</a>
                </div>
            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?= $baseUrl ?>/assets/js/app.js"></script>
    <script>
        function quickFill(email) {
            document.getElementById('emailInput').value = email;
            document.getElementById('passwordInput').value = 'password123';
        }
    </script>
</body>
</html>
