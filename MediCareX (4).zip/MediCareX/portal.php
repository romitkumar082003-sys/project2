<?php
// MediCareX - Unified Smart Hospital Portal
// Developed by Romit Kumar
require_once __DIR__ . '/portal.html';
