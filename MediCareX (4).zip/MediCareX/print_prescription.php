<?php
// MediCareX - Printable Prescription Generator
// Developed by Romit Kumar

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();

$id = intval($_GET['id'] ?? 0);
$pdo = getDBConnection();

$stmt = $pdo->prepare("
    SELECT rx.*, 
           c.symptoms, c.diagnosis, c.bp, c.temp, c.weight, c.pulse, c.notes as doctor_notes, c.follow_up_date,
           p.patient_code, u_p.name as patient_name, u_p.phone as patient_phone, p.dob, p.gender, p.blood_group,
           d.doctor_code, u_d.name as doctor_name, d.specialization, d.qualification, dep.dept_name
    FROM prescriptions rx
    LEFT JOIN consultations c ON rx.consultation_id = c.id
    JOIN patients p ON rx.patient_id = p.id
    JOIN users u_p ON p.user_id = u_p.id
    JOIN doctors d ON rx.doctor_id = d.id
    JOIN users u_d ON d.user_id = u_d.id
    JOIN departments dep ON d.department_id = dep.id
    WHERE rx.id = ?
");
$stmt->execute([$id]);
$rx = $stmt->fetch();

if (!$rx) {
    die("Prescription not found.");
}

$itemsStmt = $pdo->prepare("SELECT * FROM prescription_items WHERE prescription_id = ?");
$itemsStmt->execute([$id]);
$items = $itemsStmt->fetchAll();

$baseUrl = get_base_url();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Prescription #RX-<?= $rx['id'] ?> - MediCareX</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>/assets/css/style.css">
    <style>
        body { background: #fff; color: #000; font-family: 'Inter', sans-serif; }
        .rx-header { border-bottom: 2px solid #0d6efd; padding-bottom: 15px; margin-bottom: 20px; }
        .rx-symbol { font-family: serif; font-size: 2.5rem; font-weight: bold; color: #0d6efd; }
    </style>
</head>
<body class="p-4 p-md-5">

    <div class="container bg-white p-4 border rounded-3 shadow-sm" style="max-width: 850px;">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center rx-header">
            <div>
                <h2 class="fw-bold text-primary mb-0"><i class="bi bi-cross-circle-fill me-2"></i> MediCareX Hospital</h2>
                <small class="text-muted">100 Healthcare Way, Tech Park &bull; Emergency 24/7: +91 98765 43210</small>
            </div>
            <div class="text-end">
                <span class="badge bg-primary px-3 py-2 fs-6">Official Medical Rx</span>
                <div class="fs-8 text-muted mt-1">Date: <?= formatDate($rx['created_at'], 'd M Y, h:i A') ?></div>
            </div>
        </div>

        <!-- Doctor & Patient Info -->
        <div class="row g-3 mb-4 pb-3 border-bottom fs-7">
            <div class="col-md-6 border-end">
                <h6 class="fw-bold text-primary text-uppercase fs-8 mb-1">Doctor Information</h6>
                <div class="fw-bold fs-6"><?= htmlspecialchars($rx['doctor_name']) ?></div>
                <div><?= htmlspecialchars($rx['qualification']) ?></div>
                <div class="text-muted"><?= htmlspecialchars($rx['specialization']) ?> (<?= htmlspecialchars($rx['dept_name']) ?>)</div>
                <small class="text-muted">Doctor Code: <?= htmlspecialchars($rx['doctor_code']) ?></small>
            </div>
            <div class="col-md-6 ps-md-4">
                <h6 class="fw-bold text-primary text-uppercase fs-8 mb-1">Patient Details</h6>
                <div class="fw-bold fs-6"><?= htmlspecialchars($rx['patient_name']) ?> (ID: <?= htmlspecialchars($rx['patient_code']) ?>)</div>
                <div>Gender: <strong><?= htmlspecialchars($rx['gender']) ?></strong> | Blood Group: <strong><?= htmlspecialchars($rx['blood_group']) ?></strong></div>
                <div>Phone: <?= htmlspecialchars($rx['patient_phone']) ?></div>
            </div>
        </div>

        <!-- Vitals & Diagnosis -->
        <div class="p-3 bg-light rounded-3 mb-4 fs-7 border">
            <div class="row g-2 text-center mb-2 fw-semibold">
                <div class="col-3">BP: <span class="text-primary"><?= htmlspecialchars($rx['bp'] ?? 'N/A') ?></span></div>
                <div class="col-3">Temp: <span class="text-danger"><?= htmlspecialchars($rx['temp'] ?? 'N/A') ?></span></div>
                <div class="col-3">Pulse: <span class="text-success"><?= htmlspecialchars($rx['pulse'] ?? 'N/A') ?></span></div>
                <div class="col-3">Weight: <span class="text-dark"><?= htmlspecialchars($rx['weight'] ?? 'N/A') ?></span></div>
            </div>
            <hr class="my-2">
            <div><strong>Symptoms:</strong> <?= htmlspecialchars($rx['symptoms'] ?? 'None recorded') ?></div>
            <div><strong>Diagnosis:</strong> <span class="fw-bold text-dark"><?= htmlspecialchars($rx['diagnosis'] ?? 'Under Observation') ?></span></div>
        </div>

        <!-- Rx Prescription Symbol & Table -->
        <div class="d-flex align-items-center gap-2 mb-3">
            <span class="rx-symbol">Rx</span>
            <h5 class="fw-bold mb-0">Prescribed Medications</h5>
        </div>

        <table class="table table-bordered align-middle fs-7 mb-4">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Medicine Name</th>
                    <th>Dosage</th>
                    <th>Frequency</th>
                    <th>Duration</th>
                    <th>Instructions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($items)): ?>
                    <tr><td colspan="6" class="text-center text-muted">No medicines prescribed</td></tr>
                <?php else: ?>
                    <?php foreach ($items as $idx => $item): ?>
                        <tr>
                            <td><?= $idx + 1 ?></td>
                            <td class="fw-bold"><?= htmlspecialchars($item['medicine_name']) ?></td>
                            <td><?= htmlspecialchars($item['dosage']) ?></td>
                            <td><?= htmlspecialchars($item['frequency']) ?></td>
                            <td><?= htmlspecialchars($item['duration']) ?></td>
                            <td class="text-muted"><?= htmlspecialchars($item['instructions']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        <?php if (!empty($rx['doctor_notes'])): ?>
            <div class="mb-4 fs-7">
                <strong class="text-uppercase text-muted">Doctor Advice / Notes:</strong>
                <p class="mb-0 text-dark"><?= nl2br(htmlspecialchars($rx['doctor_notes'])) ?></p>
            </div>
        <?php endif; ?>

        <?php if (!empty($rx['follow_up_date'])): ?>
            <div class="alert alert-info py-2 fs-7 mb-4">
                <i class="bi bi-calendar-event me-2"></i> Recommended Follow-up Date: <strong><?= formatDate($rx['follow_up_date'], 'd M Y') ?></strong>
            </div>
        <?php endif; ?>

        <!-- Footer Signatures & Print Button -->
        <div class="d-flex justify-content-between align-items-end mt-5 pt-4 border-top fs-7">
            <div>
                <small class="text-muted d-block">Generated by MediCareX Digital Health System</small>
                <small class="fw-bold text-primary"><?= DEVELOPER_NAME ?></small>
            </div>
            <div class="text-center" style="width: 200px;">
                <div class="border-bottom pb-4 mb-1"></div>
                <small class="fw-bold"><?= htmlspecialchars($rx['doctor_name']) ?></small><br>
                <small class="text-muted">Authorized Physician Signature</small>
            </div>
        </div>

        <div class="text-center mt-4 no-print">
            <button onclick="window.print()" class="btn btn-primary btn-lg rounded-pill px-4 shadow">
                <i class="bi bi-printer-fill me-2"></i> Print Prescription / Save PDF
            </button>
        </div>
    </div>

</body>
</html>
