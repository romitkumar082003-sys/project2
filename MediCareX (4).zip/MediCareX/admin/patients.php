<?php
// MediCareX - Admin Patient Directory
// Developed by Romit Kumar

$pageTitle = 'Patient Directory';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole('Admin');

$user = getCurrentUser();
$pdo = getDBConnection();

$patients = $pdo->query("
    SELECT p.*, u.name, u.email, u.phone, u.status 
    FROM patients p 
    JOIN users u ON p.user_id = u.id 
    ORDER BY p.id DESC
")->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold mb-0">Global Patient Directory</h3>
            </div>

            <div class="card card-custom border-0 shadow-sm">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0 fs-7">
                            <thead class="table-light text-uppercase">
                                <tr>
                                    <th>Patient ID</th>
                                    <th>Full Name</th>
                                    <th>Contact</th>
                                    <th>Gender / DOB</th>
                                    <th>Blood Group</th>
                                    <th>Emergency Contact</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($patients as $pat): ?>
                                    <tr>
                                        <td class="fw-bold text-primary"><?= htmlspecialchars($pat['patient_code']) ?></td>
                                        <td class="fw-bold"><?= htmlspecialchars($pat['name']) ?></td>
                                        <td>
                                            <div><?= htmlspecialchars($pat['phone']) ?></div>
                                            <small class="text-muted"><?= htmlspecialchars($pat['email']) ?></small>
                                        </td>
                                        <td><?= htmlspecialchars($pat['gender']) ?> (<?= formatDate($pat['dob'], 'd M Y') ?>)</td>
                                        <td><span class="badge bg-danger fs-7"><?= htmlspecialchars($pat['blood_group']) ?></span></td>
                                        <td><?= htmlspecialchars($pat['emergency_contact'] ?? 'N/A') ?></td>
                                        <td><?= renderStatusBadge($pat['status']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
