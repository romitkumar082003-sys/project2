<?php
// MediCareX - Admin Billing, Invoicing & Financial Revenue Center
// Developed by Romit Kumar

$pageTitle = 'Billing & Financials';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

requireRole('Admin');

$user = getCurrentUser();
$pdo = getDBConnection();

// 1. Generate New Hospital Invoice
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_invoice'])) {
    validateCSRFOrDie();

    $patient_id = intval($_POST['patient_id'] ?? 0);
    $consultation_fee = floatval($_POST['consultation_fee'] ?? 0);
    $lab_charges = floatval($_POST['lab_charges'] ?? 0);
    $medicine_charges = floatval($_POST['medicine_charges'] ?? 0);
    $room_charges = floatval($_POST['room_charges'] ?? 0);
    $payment_status = cleanInput($_POST['payment_status'] ?? 'Pending');

    $subtotal = $consultation_fee + $lab_charges + $medicine_charges + $room_charges;
    $tax = round($subtotal * 0.05, 2); // 5% GST
    $grand_total = $subtotal + $tax;

    $inv_code = generateCode('INV', 'invoices', 'invoice_code');

    $ins = $pdo->prepare("
        INSERT INTO invoices (patient_id, invoice_code, consultation_fee, lab_charges, medicine_charges, room_charges, subtotal, tax, grand_total, payment_status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $ins->execute([$patient_id, $inv_code, $consultation_fee, $lab_charges, $medicine_charges, $room_charges, $subtotal, $tax, $grand_total, $payment_status]);
    $invoice_id = $pdo->lastInsertId();

    // If marked Paid immediately, insert payment record
    if ($payment_status === 'Paid') {
        $payment_method = cleanInput($_POST['payment_method'] ?? 'Cash');
        $txn_id = 'TXN_' . strtoupper($payment_method) . '_' . rand(100000000, 999999999);
        $pmt_code = generateCode('PAY', 'payments', 'payment_code');
        $pdo->prepare("INSERT INTO payments (invoice_id, payment_code, transaction_id, amount, payment_method, payment_status) VALUES (?, ?, ?, ?, ?, 'Success')")
            ->execute([$invoice_id, $pmt_code, $txn_id, $grand_total, $payment_method]);
    }

    logAudit($user['id'], $user['name'], 'Admin', 'INVOICE_CREATE', "Generated invoice {$inv_code} of ₹{$grand_total}.");
    setFlash('success', "Invoice {$inv_code} created successfully!");
    header("Location: billing.php");
    exit();
}

// 2. Collect Payment / Mark as Paid
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['collect_payment'])) {
    validateCSRFOrDie();

    $invoice_id = intval($_POST['invoice_id'] ?? 0);
    $payment_method = cleanInput($_POST['payment_method'] ?? 'Cash');
    $amount = floatval($_POST['amount'] ?? 0);

    $invStmt = $pdo->prepare("SELECT * FROM invoices WHERE id = ?");
    $invStmt->execute([$invoice_id]);
    $inv = $invStmt->fetch();

    if ($inv) {
        $txn_id = 'TXN_' . strtoupper($payment_method) . '_' . rand(100000000, 999999999);
        $pmt_code = generateCode('PAY', 'payments', 'payment_code');

        $insPmt = $pdo->prepare("
            INSERT INTO payments (invoice_id, payment_code, transaction_id, amount, payment_method, payment_status) 
            VALUES (?, ?, ?, ?, ?, 'Success')
        ");
        $insPmt->execute([$invoice_id, $pmt_code, $txn_id, $amount, $payment_method]);

        $pdo->prepare("UPDATE invoices SET payment_status = 'Paid' WHERE id = ?")->execute([$invoice_id]);

        logAudit($user['id'], $user['name'], 'Admin', 'PAYMENT_COLLECT', "Collected payment of ₹{$amount} for Invoice {$inv['invoice_code']} via {$payment_method}.");
        setFlash('success', "Payment of ₹{$amount} collected successfully via {$payment_method}! (Txn: {$txn_id})");
    }
    header("Location: billing.php");
    exit();
}

// 3. Quick Toggle Payment Status
if (isset($_GET['action']) && $_GET['action'] === 'set_status') {
    $inv_id = intval($_GET['id'] ?? 0);
    $status = cleanInput($_GET['status'] ?? 'Paid');
    if (in_array($status, ['Paid', 'Pending', 'Cancelled', 'Refunded'])) {
        $pdo->prepare("UPDATE invoices SET payment_status = ? WHERE id = ?")->execute([$status, $inv_id]);
        setFlash('success', "Invoice status updated to '{$status}'.");
    }
    header("Location: billing.php");
    exit();
}

// Query Patients for Invoice Dropdown
$patients = $pdo->query("SELECT p.id, p.patient_code, u.name, u.phone FROM patients p JOIN users u ON p.user_id = u.id ORDER BY u.name ASC")->fetchAll();

// Filter Status
$filterStatus = cleanInput($_GET['status'] ?? 'All');
$where = "";
$params = [];
if ($filterStatus !== 'All') {
    $where = "WHERE inv.payment_status = ?";
    $params[] = $filterStatus;
}

$invoices = $pdo->prepare("
    SELECT inv.*, p.patient_code, u.name as patient_name, u.phone as patient_phone
    FROM invoices inv
    JOIN patients p ON inv.patient_id = p.id
    JOIN users u ON p.user_id = u.id
    {$where}
    ORDER BY inv.id DESC
");
$invoices->execute($params);
$invoiceList = $invoices->fetchAll();

// Financial Totals
$totalBilled = $pdo->query("SELECT SUM(grand_total) FROM invoices")->fetchColumn() ?: 0;
$totalPaid = $pdo->query("SELECT SUM(grand_total) FROM invoices WHERE payment_status = 'Paid'")->fetchColumn() ?: 0;
$totalPending = $pdo->query("SELECT SUM(grand_total) FROM invoices WHERE payment_status = 'Pending'")->fetchColumn() ?: 0;
$paidCount = $pdo->query("SELECT COUNT(*) FROM invoices WHERE payment_status = 'Paid'")->fetchColumn();
$pendingCount = $pdo->query("SELECT COUNT(*) FROM invoices WHERE payment_status = 'Pending'")->fetchColumn();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-3 p-md-4">
            <?php displayFlash(); ?>

            <!-- Page Header -->
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-2 mb-4">
                <div>
                    <h3 class="fw-bold mb-1"><i class="bi bi-receipt-cutoff text-primary me-2"></i>Financial Invoices & Revenue Master</h3>
                    <p class="text-muted mb-0 fs-7">Generate itemized hospital bills, record cash/online collections, and track pending patient dues.</p>
                </div>
                <button type="button" class="btn btn-primary rounded-pill px-4 shadow-sm fs-7" data-bs-toggle="modal" data-bs-target="#createInvModal">
                    <i class="bi bi-plus-lg me-1"></i> Issue New Invoice
                </button>
            </div>

            <!-- Financial Summary Cards -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-4">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-primary">
                        <small class="text-muted text-uppercase fw-bold fs-8">Total Billed Revenue</small>
                        <h2 class="fw-bold mb-0 text-primary"><?= formatCurrency($totalBilled) ?></h2>
                        <small class="text-muted fs-8">Across All Hospital Invoices</small>
                    </div>
                </div>
                <div class="col-6 col-md-4">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-success">
                        <small class="text-muted text-uppercase fw-bold fs-8">Total Collected (Paid)</small>
                        <h2 class="fw-bold mb-0 text-success"><?= formatCurrency($totalPaid) ?></h2>
                        <small class="text-muted fs-8"><?= $paidCount ?> Fully Paid Invoices</small>
                    </div>
                </div>
                <div class="col-6 col-md-4">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-warning">
                        <small class="text-muted text-uppercase fw-bold fs-8">Pending Hospital Dues</small>
                        <h2 class="fw-bold mb-0 text-warning"><?= formatCurrency($totalPending) ?></h2>
                        <small class="text-muted fs-8"><?= $pendingCount ?> Invoices Awaiting Payment</small>
                    </div>
                </div>
            </div>

            <!-- Filter Status Tabs & Table -->
            <div class="card card-custom border-0 shadow-sm">
                <div class="card-header bg-body border-0 py-3 d-flex flex-wrap gap-2 align-items-center">
                    <a href="billing.php?status=All" class="btn btn-sm rounded-pill <?= $filterStatus === 'All' ? 'btn-primary' : 'btn-outline-secondary' ?>">
                        All Invoices (<?= count($invoiceList) ?>)
                    </a>
                    <a href="billing.php?status=Paid" class="btn btn-sm rounded-pill <?= $filterStatus === 'Paid' ? 'btn-success text-white' : 'btn-outline-success' ?>">
                        <i class="bi bi-check-circle me-1"></i> Paid (<?= $paidCount ?>)
                    </a>
                    <a href="billing.php?status=Pending" class="btn btn-sm rounded-pill <?= $filterStatus === 'Pending' ? 'btn-warning text-dark' : 'btn-outline-warning' ?>">
                        <i class="bi bi-hourglass-split me-1"></i> Pending Dues (<?= $pendingCount ?>)
                    </a>
                </div>

                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 fs-7">
                        <thead class="table-light text-uppercase">
                            <tr>
                                <th>Invoice Code</th>
                                <th>Patient Details</th>
                                <th>Consultation</th>
                                <th>Lab</th>
                                <th>Pharmacy/Room</th>
                                <th>Tax (5%)</th>
                                <th>Grand Total</th>
                                <th>Payment Status</th>
                                <th class="text-end">Actions / Collect</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($invoiceList)): ?>
                                <tr>
                                    <td colspan="9" class="text-center py-5 text-muted">
                                        <i class="bi bi-receipt fs-1 d-block mb-2 text-muted"></i>
                                        No invoices found matching selected filter.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($invoiceList as $inv): ?>
                                    <?php $isPaid = ($inv['payment_status'] === 'Paid'); ?>
                                    <tr>
                                        <td class="fw-bold text-primary"><?= htmlspecialchars($inv['invoice_code']) ?></td>
                                        <td>
                                            <div class="fw-bold text-body"><?= htmlspecialchars($inv['patient_name']) ?></div>
                                            <small class="text-muted"><?= htmlspecialchars($inv['patient_code']) ?> • <?= htmlspecialchars($inv['patient_phone'] ?? 'N/A') ?></small>
                                        </td>
                                        <td><?= formatCurrency($inv['consultation_fee']) ?></td>
                                        <td><?= formatCurrency($inv['lab_charges']) ?></td>
                                        <td><?= formatCurrency(($inv['medicine_charges'] ?? 0) + ($inv['room_charges'] ?? 0)) ?></td>
                                        <td><?= formatCurrency($inv['tax']) ?></td>
                                        <td class="fw-bold text-dark fs-6"><?= formatCurrency($inv['grand_total']) ?></td>
                                        <td>
                                            <?php if ($isPaid): ?>
                                                <span class="badge bg-success rounded-pill px-3 py-1"><i class="bi bi-check-circle me-1"></i>Paid</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning text-dark rounded-pill px-3 py-1"><i class="bi bi-hourglass me-1"></i>Pending</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end">
                                            <div class="btn-group btn-group-sm">
                                                <?php if (!$isPaid): ?>
                                                    <!-- Collect Payment Modal Trigger -->
                                                    <button type="button" class="btn btn-sm btn-success rounded-pill px-2 me-1" onclick="openCollectPaymentModal(<?= htmlspecialchars(json_encode($inv)) ?>)">
                                                        <i class="bi bi-cash-coin me-1"></i> Collect
                                                    </button>
                                                <?php else: ?>
                                                    <a href="billing.php?action=set_status&id=<?= $inv['id'] ?>&status=Pending" class="btn btn-sm btn-outline-warning rounded-pill px-2 me-1" onclick="return confirm('Revert to Pending?')" title="Mark Pending">
                                                        <i class="bi bi-arrow-counterclockwise"></i>
                                                    </a>
                                                <?php endif; ?>

                                                <a href="<?= get_base_url() ?>/print_invoice.php?id=<?= $inv['id'] ?>" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill px-3">
                                                    <i class="bi bi-printer me-1"></i> Print
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        <!-- Issue Invoice Modal -->
        <div class="modal fade" id="createInvModal" tabindex="-1">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-receipt-cutoff me-2"></i> Issue New Patient Bill</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST" action="" id="newInvForm">
                        <?= renderCSRFField() ?>
                        <input type="hidden" name="create_invoice" value="1">

                        <div class="modal-body p-4">
                            <div class="row g-3">
                                <div class="col-md-12">
                                    <label class="form-label fw-semibold">Select Patient *</label>
                                    <select name="patient_id" class="form-select" required>
                                        <option value="">-- Choose Registered Patient --</option>
                                        <?php foreach ($patients as $p): ?>
                                            <option value="<?= $p['id'] ?>">
                                                <?= htmlspecialchars($p['name']) ?> (Code: <?= htmlspecialchars($p['patient_code']) ?> • <?= htmlspecialchars($p['phone'] ?? 'N/A') ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Doctor Consultation Fee (₹)</label>
                                    <input type="number" step="0.01" name="consultation_fee" id="fee_cons" class="form-control calc-input" value="600.00">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Diagnostics / Lab Charges (₹)</label>
                                    <input type="number" step="0.01" name="lab_charges" id="fee_lab" class="form-control calc-input" value="450.00">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Pharmacy Medicines Total (₹)</label>
                                    <input type="number" step="0.01" name="medicine_charges" id="fee_pharm" class="form-control calc-input" value="320.00">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Room / Bed Charges (₹)</label>
                                    <input type="number" step="0.01" name="room_charges" id="fee_room" class="form-control calc-input" value="0.00">
                                </div>

                                <!-- Live Total Breakdown -->
                                <div class="col-12">
                                    <div class="p-3 bg-body-tertiary rounded-3 border">
                                        <div class="d-flex justify-content-between fs-7 mb-1">
                                            <span class="text-muted">Subtotal:</span>
                                            <strong id="live_subtotal">₹1,370.00</strong>
                                        </div>
                                        <div class="d-flex justify-content-between fs-7 mb-1">
                                            <span class="text-muted">GST Tax (5%):</span>
                                            <strong id="live_tax">₹68.50</strong>
                                        </div>
                                        <div class="d-flex justify-content-between fs-5 fw-bold border-top pt-2">
                                            <span class="text-primary">Estimated Grand Total:</span>
                                            <span class="text-success" id="live_grand">₹1,438.50</span>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Initial Payment Status *</label>
                                    <select name="payment_status" id="initial_status" class="form-select" required>
                                        <option value="Pending" selected>Pending (Pay Later)</option>
                                        <option value="Paid">Paid (Immediate Collection)</option>
                                    </select>
                                </div>
                                <div class="col-md-6" id="pmt_method_box" style="display:none;">
                                    <label class="form-label fw-semibold">Payment Method *</label>
                                    <select name="payment_method" class="form-select">
                                        <option value="Cash">Cash at Billing Counter</option>
                                        <option value="UPI">UPI / QR Code</option>
                                        <option value="Card">Debit / Credit Card</option>
                                        <option value="NetBanking">Net Banking</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-top-0 pt-0">
                            <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary rounded-pill px-4 shadow">Generate Invoice</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Collect Payment Modal -->
        <div class="modal fade" id="collectModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-success text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-cash-stack me-2"></i> Collect Patient Payment</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST" action="">
                        <?= renderCSRFField() ?>
                        <input type="hidden" name="collect_payment" value="1">
                        <input type="hidden" name="invoice_id" id="collect_inv_id">
                        <input type="hidden" name="amount" id="collect_amount_input">

                        <div class="modal-body p-4">
                            <div class="p-3 bg-body-tertiary rounded-3 mb-3 border text-center">
                                <small class="text-muted d-block" id="collect_inv_code">INV-0000</small>
                                <h2 class="fw-extrabold text-success mb-0" id="collect_amount_display">₹0.00</h2>
                                <span class="fs-7 text-muted" id="collect_pat_name">Patient Name</span>
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Payment Mode *</label>
                                <select name="payment_method" class="form-select" required>
                                    <option value="Cash">💵 Cash Collection (Front Desk)</option>
                                    <option value="UPI">📱 UPI / QR Transfer (GPay / PhonePe / Paytm)</option>
                                    <option value="Card">💳 Credit / Debit Card Terminal</option>
                                    <option value="NetBanking">🌐 Net Banking / RTGS</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer border-top-0 pt-0">
                            <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-success rounded-pill px-4 shadow">Confirm Payment Collection</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>

<script>
// Recalculate totals live
function recalcInv() {
    const cons = parseFloat(document.getElementById('fee_cons').value) || 0;
    const lab = parseFloat(document.getElementById('fee_lab').value) || 0;
    const pharm = parseFloat(document.getElementById('fee_pharm').value) || 0;
    const room = parseFloat(document.getElementById('fee_room').value) || 0;

    const sub = cons + lab + pharm + room;
    const tax = Math.round(sub * 0.05 * 100) / 100;
    const grand = sub + tax;

    document.getElementById('live_subtotal').textContent = '₹' + sub.toFixed(2);
    document.getElementById('live_tax').textContent = '₹' + tax.toFixed(2);
    document.getElementById('live_grand').textContent = '₹' + grand.toFixed(2);
}

document.querySelectorAll('.calc-input').forEach(input => {
    input.addEventListener('input', recalcInv);
});

document.getElementById('initial_status').addEventListener('change', function() {
    document.getElementById('pmt_method_box').style.display = (this.value === 'Paid') ? 'block' : 'none';
});

function openCollectPaymentModal(inv) {
    document.getElementById('collect_inv_id').value = inv.id;
    document.getElementById('collect_inv_code').textContent = `Invoice: ${inv.invoice_code}`;
    document.getElementById('collect_pat_name').textContent = `Patient: ${inv.patient_name} (${inv.patient_code})`;
    document.getElementById('collect_amount_display').textContent = '₹' + parseFloat(inv.grand_total).toFixed(2);
    document.getElementById('collect_amount_input').value = inv.grand_total;

    new bootstrap.Modal(document.getElementById('collectModal')).show();
}
</script>
