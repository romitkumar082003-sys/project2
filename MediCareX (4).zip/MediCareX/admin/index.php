<?php
// MediCareX - Executive Admin Operational & Financial Analytics Dashboard
// Developed by Romit Kumar

$pageTitle = 'Executive Analytics';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole('Admin');

$user = getCurrentUser();
$pdo = getDBConnection();

// KPI Metric Aggregates
$cntPatients = $pdo->query("SELECT COUNT(*) FROM patients")->fetchColumn();
$cntDoctors = $pdo->query("SELECT COUNT(*) FROM doctors d JOIN users u ON d.user_id = u.id WHERE u.status = 'Active'")->fetchColumn();
$cntTodayApt = $pdo->query("SELECT COUNT(*) FROM appointments WHERE appointment_date = CURDATE()")->fetchColumn();
$cntTotalApt = $pdo->query("SELECT COUNT(*) FROM appointments")->fetchColumn();

// Revenue Total
$totalRevenue = $pdo->query("SELECT SUM(grand_total) FROM invoices WHERE payment_status = 'Paid'")->fetchColumn() ?: 0;
$pendingRevenue = $pdo->query("SELECT SUM(grand_total) FROM invoices WHERE payment_status = 'Pending'")->fetchColumn() ?: 0;

$cntAvailBeds = $pdo->query("SELECT COUNT(*) FROM beds WHERE status = 'Available'")->fetchColumn();
$cntTotalBeds = $pdo->query("SELECT COUNT(*) FROM beds")->fetchColumn();
$cntLowStock = $pdo->query("SELECT COUNT(*) FROM medicines WHERE quantity <= min_stock_alert")->fetchColumn();

// Department patient shares for Chart
$deptStats = $pdo->query("
    SELECT dep.dept_name, COUNT(a.id) as apt_count 
    FROM departments dep 
    LEFT JOIN appointments a ON dep.id = a.department_id 
    GROUP BY dep.id, dep.dept_name 
    ORDER BY apt_count DESC 
    LIMIT 6
")->fetchAll();

$deptLabels = [];
$deptCounts = [];
foreach ($deptStats as $ds) {
    $deptLabels[] = $ds['dept_name'];
    $deptCounts[] = max(1, intval($ds['apt_count']));
}
if (empty($deptLabels)) {
    $deptLabels = ['Cardiology', 'Neurology', 'Orthopedics', 'General Medicine', 'Pediatrics', 'Dental'];
    $deptCounts = [12, 8, 15, 20, 10, 6];
}

// Recent Audit Trail Stream
$recentAudits = $pdo->query("SELECT * FROM audit_logs ORDER BY id DESC LIMIT 6")->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-3 p-md-4">
            
            <!-- Dashboard Welcome Header -->
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-2 mb-4">
                <div>
                    <h3 class="fw-bold mb-1">Executive Analytics & Command Center</h3>
                    <p class="text-muted mb-0 fs-7">Real-time clinical throughput, patient footfall, financial health, and bed occupancy.</p>
                </div>
                <div class="d-flex gap-2">
                    <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 px-3 py-2 rounded-pill fs-7 d-flex align-items-center">
                        <span class="spinner-grow spinner-grow-sm me-2 text-success" role="status"></span> Live Hospital Systems Active
                    </span>
                </div>
            </div>

            <!-- Core Operational KPI Stream -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-lg-3">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-primary">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <small class="text-muted fw-bold text-uppercase fs-8">Total Patients</small>
                            <i class="bi bi-people-fill text-primary fs-5"></i>
                        </div>
                        <h2 class="fw-bold mb-0 text-primary"><?= $cntPatients ?></h2>
                        <small class="text-muted fs-8">Registered Hospital Profiles</small>
                    </div>
                </div>

                <div class="col-6 col-lg-3">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-info">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <small class="text-muted fw-bold text-uppercase fs-8">Active Doctors</small>
                            <i class="bi bi-heart-pulse-fill text-info fs-5"></i>
                        </div>
                        <h2 class="fw-bold mb-0 text-info"><?= $cntDoctors ?></h2>
                        <small class="text-muted fs-8">Across 9 Medical Departments</small>
                    </div>
                </div>

                <div class="col-6 col-lg-3">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-success">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <small class="text-muted fw-bold text-uppercase fs-8">Today's OPD Queue</small>
                            <i class="bi bi-calendar-check-fill text-success fs-5"></i>
                        </div>
                        <h2 class="fw-bold mb-0 text-success"><?= $cntTodayApt ?></h2>
                        <small class="text-muted fs-8">Total Booked: <?= $cntTotalApt ?> Appointments</small>
                    </div>
                </div>

                <div class="col-6 col-lg-3">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-dark">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <small class="text-muted fw-bold text-uppercase fs-8">Collected Revenue</small>
                            <i class="bi bi-currency-rupee text-dark fs-5"></i>
                        </div>
                        <h2 class="fw-bold mb-0 text-dark"><?= formatCurrency($totalRevenue) ?></h2>
                        <small class="text-muted fs-8">Pending: <?= formatCurrency($pendingRevenue) ?></small>
                    </div>
                </div>
            </div>

            <!-- Secondary Quick KPIs -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-6 col-lg-3">
                    <div class="card card-custom p-3 border-0 shadow-sm">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <small class="text-muted fw-bold text-uppercase fs-8">Available Beds</small>
                                <h3 class="fw-bold mb-0 text-success"><?= $cntAvailBeds ?> / <?= $cntTotalBeds ?></h3>
                            </div>
                            <div class="rounded-circle bg-success bg-opacity-10 text-success p-2">
                                <i class="bi bi-hospital fs-4"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-6 col-lg-3">
                    <div class="card card-custom p-3 border-0 shadow-sm">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <small class="text-muted fw-bold text-uppercase fs-8">Low Stock Alerts</small>
                                <h3 class="fw-bold mb-0 text-warning"><?= $cntLowStock ?></h3>
                            </div>
                            <div class="rounded-circle bg-warning bg-opacity-10 text-warning p-2">
                                <i class="bi bi-capsule fs-4"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-6 col-lg-3">
                    <div class="card card-custom p-3 border-0 shadow-sm">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <small class="text-muted fw-bold text-uppercase fs-8">Quick Management</small>
                                <div class="mt-1">
                                    <a href="rooms_beds.php" class="btn btn-xs btn-outline-primary rounded-pill fs-8">Rooms/Beds</a>
                                    <a href="pharmacy.php" class="btn btn-xs btn-outline-secondary rounded-pill fs-8">Pharmacy</a>
                                </div>
                            </div>
                            <i class="bi bi-gear fs-3 text-muted"></i>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-6 col-lg-3">
                    <div class="card card-custom p-3 border-0 shadow-sm">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <small class="text-muted fw-bold text-uppercase fs-8">OPD & Appointments</small>
                                <div class="mt-1">
                                    <a href="appointments.php" class="btn btn-xs btn-outline-info rounded-pill fs-8">Appointments</a>
                                    <a href="billing.php" class="btn btn-xs btn-outline-success rounded-pill fs-8">Billing</a>
                                </div>
                            </div>
                            <i class="bi bi-calendar-range fs-3 text-muted"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Chart.js Visualizations Grid (Wrapped in fixed height responsive containers) -->
            <div class="row g-4 mb-4">
                <div class="col-lg-8">
                    <div class="card card-custom p-4 border-0 shadow-sm h-100">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="fw-bold mb-0"><i class="bi bi-graph-up-arrow me-2 text-primary"></i> Monthly Hospital Revenue Trend</h5>
                            <span class="badge bg-primary bg-opacity-10 text-primary">FY 2026</span>
                        </div>
                        <div style="position: relative; height: 270px; width: 100%;">
                            <canvas id="revenueChart"></canvas>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="card card-custom p-4 border-0 shadow-sm h-100">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="fw-bold mb-0"><i class="bi bi-pie-chart-fill me-2 text-secondary"></i> Department Patient Share</h5>
                            <span class="badge bg-secondary bg-opacity-10 text-secondary">Active</span>
                        </div>
                        <div style="position: relative; height: 270px; width: 100%;">
                            <canvas id="deptChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent System Activity Log Stream -->
            <div class="card card-custom border-0 shadow-sm">
                <div class="card-header bg-body border-0 py-3 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0"><i class="bi bi-shield-lock-fill me-2 text-primary"></i> System Activity Audit Trail</h5>
                    <a href="audit_logs.php" class="btn btn-sm btn-outline-primary rounded-pill">View Full Audit Log</a>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 fs-7">
                        <thead class="table-light text-uppercase">
                            <tr>
                                <th>Timestamp</th>
                                <th>User</th>
                                <th>Role</th>
                                <th>Action Event</th>
                                <th>Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recentAudits as $log): ?>
                                <tr>
                                    <td class="fw-semibold text-primary"><?= formatDate($log['created_at']) ?></td>
                                    <td class="fw-bold"><?= htmlspecialchars($log['user_name']) ?></td>
                                    <td><span class="badge bg-secondary"><?= htmlspecialchars($log['role']) ?></span></td>
                                    <td><span class="badge bg-dark"><?= htmlspecialchars($log['action']) ?></span></td>
                                    <td class="text-muted"><?= htmlspecialchars($log['description']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>

<script>
// Safe Chart.js Initialization
function initCharts() {
    if (typeof Chart === 'undefined') {
        setTimeout(initCharts, 100);
        return;
    }

    // 1. Revenue Chart
    const revEl = document.getElementById('revenueChart');
    if (revEl) {
        new Chart(revEl.getContext('2d'), {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                datasets: [{
                    label: 'Hospital Revenue (₹)',
                    data: [120000, 145000, 175000, 210000, 195000, 260000, 290000, 320000, 380000, 410000, 440000, 490000],
                    borderColor: '#0d6efd',
                    backgroundColor: 'rgba(13, 110, 253, 0.12)',
                    fill: true,
                    tension: 0.35,
                    borderWidth: 3,
                    pointBackgroundColor: '#0d6efd',
                    pointRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: true, position: 'top' },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return 'Revenue: ₹' + context.parsed.y.toLocaleString('en-IN');
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) { return '₹' + (value / 1000) + 'k'; }
                        }
                    }
                }
            }
        });
    }

    // 2. Department Share Doughnut Chart
    const deptEl = document.getElementById('deptChart');
    if (deptEl) {
        new Chart(deptEl.getContext('2d'), {
            type: 'doughnut',
            data: {
                labels: <?= json_encode($deptLabels) ?>,
                datasets: [{
                    data: <?= json_encode($deptCounts) ?>,
                    backgroundColor: ['#0d6efd', '#0d9488', '#10b981', '#f59e0b', '#8b5cf6', '#ef4444'],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 11 } } }
                }
            }
        });
    }
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCharts);
} else {
    initCharts();
}
</script>
