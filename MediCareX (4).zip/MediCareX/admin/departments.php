<?php
// MediCareX - Department Management & Operational Status
// Developed by Romit Kumar

$pageTitle = 'Medical Departments';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

requireRole('Admin');

$user = getCurrentUser();
$pdo = getDBConnection();

// 1. Add Department
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_department'])) {
    validateCSRFOrDie();

    $dept_name = cleanInput($_POST['dept_name'] ?? '');
    $description = cleanInput($_POST['description'] ?? '');
    $icon = cleanInput($_POST['icon'] ?? 'bi-hospital');
    $status = cleanInput($_POST['status'] ?? 'Active');

    $ins = $pdo->prepare("INSERT INTO departments (dept_name, description, icon, status) VALUES (?, ?, ?, ?)");
    $ins->execute([$dept_name, $description, $icon, $status]);

    logAudit($user['id'], $user['name'], 'Admin', 'DEPARTMENT_ADD', "Created department {$dept_name}.");
    setFlash('success', "Department '{$dept_name}' created successfully!");
    header("Location: departments.php");
    exit();
}

// 2. Edit Department
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_department'])) {
    validateCSRFOrDie();

    $id = intval($_POST['dept_id'] ?? 0);
    $dept_name = cleanInput($_POST['dept_name'] ?? '');
    $description = cleanInput($_POST['description'] ?? '');
    $icon = cleanInput($_POST['icon'] ?? 'bi-hospital');
    $status = cleanInput($_POST['status'] ?? 'Active');

    $upd = $pdo->prepare("UPDATE departments SET dept_name = ?, description = ?, icon = ?, status = ? WHERE id = ?");
    $upd->execute([$dept_name, $description, $icon, $status, $id]);

    logAudit($user['id'], $user['name'], 'Admin', 'DEPARTMENT_EDIT', "Updated department ID {$id} ({$dept_name}) to status {$status}.");
    setFlash('success', "Department '{$dept_name}' updated successfully!");
    header("Location: departments.php");
    exit();
}

// 3. Quick Toggle Status (Active <-> Inactive)
if (isset($_GET['action']) && $_GET['action'] === 'toggle_status') {
    $id = intval($_GET['id'] ?? 0);
    $deptStmt = $pdo->prepare("SELECT dept_name, status FROM departments WHERE id = ?");
    $deptStmt->execute([$id]);
    $dept = $deptStmt->fetch();

    if ($dept) {
        $newStatus = ($dept['status'] === 'Active') ? 'Inactive' : 'Active';
        $pdo->prepare("UPDATE departments SET status = ? WHERE id = ?")->execute([$newStatus, $id]);
        logAudit($user['id'], $user['name'], 'Admin', 'DEPARTMENT_STATUS_TOGGLE', "Changed status of {$dept['dept_name']} to {$newStatus}.");
        setFlash('success', "Department '{$dept['dept_name']}' is now {$newStatus}!");
    }
    header("Location: departments.php");
    exit();
}

// Filter Status
$filter = cleanInput($_GET['status'] ?? 'All');
$where = "";
$params = [];
if ($filter !== 'All') {
    $where = "WHERE status = ?";
    $params[] = $filter;
}

$deptStmt = $pdo->prepare("SELECT * FROM departments {$where} ORDER BY id ASC");
$deptStmt->execute($params);
$departments = $deptStmt->fetchAll();

$totalCount = $pdo->query("SELECT COUNT(*) FROM departments")->fetchColumn();
$activeCount = $pdo->query("SELECT COUNT(*) FROM departments WHERE status = 'Active'")->fetchColumn();
$inactiveCount = $pdo->query("SELECT COUNT(*) FROM departments WHERE status = 'Inactive'")->fetchColumn();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-3 p-md-4">
            <?php displayFlash(); ?>

            <!-- Page Header -->
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-2 mb-4">
                <div>
                    <h3 class="fw-bold mb-1"><i class="bi bi-diagram-3 text-primary me-2"></i>Medical Departments & Specialties</h3>
                    <p class="text-muted mb-0 fs-7">Manage clinical specialties, edit descriptions, and toggle Active/Inactive status.</p>
                </div>
                <button type="button" class="btn btn-primary rounded-pill px-4 shadow-sm fs-7" data-bs-toggle="modal" data-bs-target="#addDeptModal">
                    <i class="bi bi-plus-lg me-1"></i> Add New Department
                </button>
            </div>

            <!-- KPI Cards -->
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-primary">
                        <small class="text-muted text-uppercase fw-bold fs-8">Total Departments</small>
                        <h2 class="fw-bold mb-0 text-primary"><?= $totalCount ?></h2>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-success">
                        <small class="text-muted text-uppercase fw-bold fs-8">Active Departments</small>
                        <h2 class="fw-bold mb-0 text-success"><?= $activeCount ?></h2>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-secondary">
                        <small class="text-muted text-uppercase fw-bold fs-8">Inactive Departments</small>
                        <h2 class="fw-bold mb-0 text-secondary"><?= $inactiveCount ?></h2>
                    </div>
                </div>
            </div>

            <!-- Filter Status Tabs -->
            <div class="d-flex flex-wrap gap-2 mb-4">
                <a href="departments.php?status=All" class="btn btn-sm rounded-pill <?= $filter === 'All' ? 'btn-primary' : 'btn-outline-secondary' ?>">
                    All Departments (<?= $totalCount ?>)
                </a>
                <a href="departments.php?status=Active" class="btn btn-sm rounded-pill <?= $filter === 'Active' ? 'btn-success text-white' : 'btn-outline-success' ?>">
                    <i class="bi bi-check-circle me-1"></i> Active Only (<?= $activeCount ?>)
                </a>
                <a href="departments.php?status=Inactive" class="btn btn-sm rounded-pill <?= $filter === 'Inactive' ? 'btn-secondary text-white' : 'btn-outline-secondary' ?>">
                    <i class="bi bi-dash-circle me-1"></i> Inactive (<?= $inactiveCount ?>)
                </a>
            </div>

            <!-- Departments Grid -->
            <div class="row g-4">
                <?php if (empty($departments)): ?>
                    <div class="col-12 text-center py-5 text-muted">
                        <i class="bi bi-diagram-3 fs-1 d-block mb-2"></i>
                        No departments found matching "<?= htmlspecialchars($filter) ?>".
                    </div>
                <?php else: ?>
                    <?php foreach ($departments as $dept): ?>
                        <?php
                        $docCount = $pdo->prepare("SELECT COUNT(*) FROM doctors WHERE department_id = ?");
                        $docCount->execute([$dept['id']]);
                        $dCnt = $docCount->fetchColumn();

                        $isActive = ($dept['status'] === 'Active');
                        ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="card card-custom p-4 h-100 border-0 shadow-sm <?= !$isActive ? 'opacity-75 bg-body-tertiary' : '' ?>">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <div class="rounded-circle <?= $isActive ? 'bg-primary bg-opacity-10 text-primary' : 'bg-secondary bg-opacity-10 text-secondary' ?> p-3 d-flex align-items-center justify-content-center" style="width: 56px; height: 56px;">
                                        <i class="bi <?= htmlspecialchars($dept['icon'] ?: 'bi-hospital') ?> fs-2"></i>
                                    </div>
                                    <div class="text-end">
                                        <?php if ($isActive): ?>
                                            <span class="badge bg-success rounded-pill px-3 py-1"><i class="bi bi-check-circle me-1"></i>Active</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary rounded-pill px-3 py-1"><i class="bi bi-dash-circle me-1"></i>Inactive</span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <h5 class="fw-bold mb-1 text-body"><?= htmlspecialchars($dept['dept_name']) ?></h5>
                                <p class="text-muted fs-7 flex-grow-1 mb-3" style="min-height: 40px;">
                                    <?= htmlspecialchars($dept['description'] ?: 'Specialized medical department offering advanced clinical diagnosis and care.') ?>
                                </p>

                                <div class="d-flex justify-content-between align-items-center pt-3 border-top fs-8">
                                    <span class="text-primary fw-semibold">
                                        <i class="bi bi-person-badge me-1"></i><?= $dCnt ?> Doctor<?= $dCnt != 1 ? 's' : '' ?> Assigned
                                    </span>
                                    <div class="btn-group btn-group-sm">
                                        <a href="departments.php?action=toggle_status&id=<?= $dept['id'] ?>" class="btn btn-sm <?= $isActive ? 'btn-outline-warning' : 'btn-outline-success' ?> rounded-pill px-2 me-1" title="Toggle Status">
                                            <i class="bi <?= $isActive ? 'bi-pause-fill' : 'bi-play-fill' ?>"></i> <?= $isActive ? 'Deactivate' : 'Activate' ?>
                                        </a>
                                        <button type="button" class="btn btn-sm btn-outline-primary rounded-pill px-3" onclick="openEditDeptModal(<?= htmlspecialchars(json_encode($dept)) ?>)">
                                            <i class="bi bi-pencil-square me-1"></i> Edit
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

        </div>

        <!-- Add Department Modal -->
        <div class="modal fade" id="addDeptModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-plus-circle me-2"></i> Add Medical Department</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST" action="">
                        <?= renderCSRFField() ?>
                        <input type="hidden" name="add_department" value="1">

                        <div class="modal-body p-4">
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Department Name *</label>
                                <input type="text" name="dept_name" class="form-control" placeholder="e.g. Oncology, Nephrology" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Bootstrap Icon Class</label>
                                <select name="icon" class="form-select">
                                    <option value="bi-heart-pulse-fill">bi-heart-pulse-fill (Heart / Cardio)</option>
                                    <option value="bi-cpu-fill">bi-cpu-fill (Brain / Neuro)</option>
                                    <option value="bi-person-arms-up">bi-person-arms-up (Ortho / Bones)</option>
                                    <option value="bi-emoji-smile-fill">bi-emoji-smile-fill (Pediatrics / Child)</option>
                                    <option value="bi-sun-fill">bi-sun-fill (Dermatology / Skin)</option>
                                    <option value="bi-bandaid-fill">bi-bandaid-fill (General Medicine)</option>
                                    <option value="bi-gender-female">bi-gender-female (Gynecology / Women)</option>
                                    <option value="bi-ear-fill">bi-ear-fill (ENT)</option>
                                    <option value="bi-capsule">bi-capsule (Dental / Pharmacy)</option>
                                    <option value="bi-hospital" selected>bi-hospital (General Hospital)</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Description</label>
                                <textarea name="description" class="form-control" rows="3" placeholder="Overview of specialties and clinical care provided..."></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Initial Status</label>
                                <select name="status" class="form-select">
                                    <option value="Active" selected>Active (Available for Appointments)</option>
                                    <option value="Inactive">Inactive (Disabled)</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer border-top-0 pt-0">
                            <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary rounded-pill px-4 shadow">Create Department</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Edit Department Modal -->
        <div class="modal fade" id="editDeptModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-dark text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-pencil-square me-2"></i> Edit Department Details</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST" action="">
                        <?= renderCSRFField() ?>
                        <input type="hidden" name="edit_department" value="1">
                        <input type="hidden" name="dept_id" id="edit_dept_id">

                        <div class="modal-body p-4">
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Department Name *</label>
                                <input type="text" name="dept_name" id="edit_dept_name" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Icon Class</label>
                                <input type="text" name="icon" id="edit_dept_icon" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Description</label>
                                <textarea name="description" id="edit_dept_desc" class="form-control" rows="3"></textarea>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Operational Status *</label>
                                <select name="status" id="edit_dept_status" class="form-select" required>
                                    <option value="Active">🟢 Active (Open for Booking & Doctor Assignment)</option>
                                    <option value="Inactive">🔴 Inactive (Temporarily Closed / Disabled)</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer border-top-0 pt-0">
                            <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary rounded-pill px-4 shadow">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>

<script>
function openEditDeptModal(dept) {
    document.getElementById('edit_dept_id').value = dept.id;
    document.getElementById('edit_dept_name').value = dept.dept_name;
    document.getElementById('edit_dept_icon').value = dept.icon || 'bi-hospital';
    document.getElementById('edit_dept_desc').value = dept.description || '';
    document.getElementById('edit_dept_status').value = dept.status || 'Active';
    new bootstrap.Modal(document.getElementById('editDeptModal')).show();
}
</script>
