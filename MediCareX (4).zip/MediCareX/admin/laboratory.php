<?php
// MediCareX - Admin Laboratory Overview
// Developed by Romit Kumar

$pageTitle = 'Laboratory Catalog';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole('Admin');

$user = getCurrentUser();
$pdo = getDBConnection();

$tests = $pdo->query("SELECT * FROM lab_tests ORDER BY test_name ASC")->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold mb-0">Diagnostic Lab Test Catalog</h3>
            </div>

            <div class="card card-custom border-0 shadow-sm">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0 fs-7">
                            <thead class="table-light text-uppercase">
                                <tr>
                                    <th>Test Code</th>
                                    <th>Test Name</th>
                                    <th>Category</th>
                                    <th>Standard Cost</th>
                                    <th>Description</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($tests as $t): ?>
                                    <tr>
                                        <td class="fw-bold text-primary"><?= htmlspecialchars($t['test_code']) ?></td>
                                        <td class="fw-bold"><?= htmlspecialchars($t['test_name']) ?></td>
                                        <td><span class="badge bg-secondary"><?= htmlspecialchars($t['category']) ?></span></td>
                                        <td class="fw-bold text-dark fs-6"><?= formatCurrency($t['cost']) ?></td>
                                        <td class="text-muted"><?= htmlspecialchars($t['description']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
