<?php
// MediCareX - Executive Reporting Center
// Developed by Romit Kumar

$pageTitle = 'Operational Reports';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole('Admin');

$user = getCurrentUser();
$pdo = getDBConnection();

$totalAdmissions = $pdo->query("SELECT COUNT(*) FROM admissions")->fetchColumn();
$totalDischarges = $pdo->query("SELECT COUNT(*) FROM discharges")->fetchColumn();
$totalInvoices = $pdo->query("SELECT COUNT(*) FROM invoices")->fetchColumn();
$totalPaidRevenue = $pdo->query("SELECT SUM(amount) FROM payments WHERE payment_status = 'Success'")->fetchColumn() ?: 0;

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold mb-0">Executive Reports & Analytics</h3>
                <button onclick="window.print()" class="btn btn-outline-primary rounded-pill px-4"><i class="bi bi-printer me-1"></i> Print System Summary</button>
            </div>

            <div class="row g-4 mb-4">
                <div class="col-md-6">
                    <div class="card card-custom p-4">
                        <h5 class="fw-bold text-primary mb-3">Operational Summary</h5>
                        <ul class="list-group list-group-flush fs-7">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <span>Total Inpatient Admissions</span>
                                <span class="fw-bold fs-6"><?= $totalAdmissions ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <span>Total Patient Discharges</span>
                                <span class="fw-bold fs-6"><?= $totalDischarges ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <span>Total Generated Invoices</span>
                                <span class="fw-bold fs-6"><?= $totalInvoices ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <span>Realized Revenue Realized</span>
                                <span class="fw-bold text-success fs-6"><?= formatCurrency($totalPaidRevenue) ?></span>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card card-custom p-4">
                        <h5 class="fw-bold text-success mb-3">System Health Status</h5>
                        <div class="fs-7 mb-2"><strong>Database Engine:</strong> MySQL 8+ / MariaDB</div>
                        <div class="fs-7 mb-2"><strong>Environment:</strong> XAMPP / Apache Web Server</div>
                        <div class="fs-7 mb-2"><strong>Security Protocol:</strong> PDO Prepared Statements & CSRF Verification</div>
                        <div class="fs-7 mb-2"><strong>Authentication Mode:</strong> Role-Based Access Control (7 Roles)</div>
                        <div class="fs-7 text-primary fw-bold mt-3"><i class="bi bi-code-slash"></i> <?= DEVELOPER_NAME ?></div>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
