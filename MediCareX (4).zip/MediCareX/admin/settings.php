<?php
// MediCareX - System Settings & Developer Info
// Developed by Romit Kumar

$pageTitle = 'System Settings';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole('Admin');

$user = getCurrentUser();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold mb-0">System Configuration & Metadata</h3>
            </div>

            <div class="row g-4">
                <div class="col-lg-6">
                    <div class="card card-custom p-4">
                        <h5 class="fw-bold text-primary mb-3">Application Metadata</h5>
                        <div class="fs-7 mb-2"><strong>Application Title:</strong> <?= APP_NAME ?></div>
                        <div class="fs-7 mb-2"><strong>Hospital Tagline:</strong> <?= APP_TAGLINE ?></div>
                        <div class="fs-7 mb-2"><strong>Primary Technology Stack:</strong> PHP 8+, MySQL PDO, Bootstrap 5, Chart.js</div>
                        <div class="fs-7 mb-2"><strong>Lead Developer:</strong> <span class="fw-bold text-primary"><?= DEVELOPER_NAME ?></span></div>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
