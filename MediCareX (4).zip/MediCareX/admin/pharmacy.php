<?php
// MediCareX - Admin Pharmacy Stock & Medicine Master
// Developed by Romit Kumar

$pageTitle = 'Pharmacy Master';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

requireRole('Admin');

$user = getCurrentUser();
$pdo = getDBConnection();

// 1. Add Medicine
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_medicine'])) {
    validateCSRFOrDie();
    $name = cleanInput($_POST['name'] ?? '');
    $category = cleanInput($_POST['category'] ?? '');
    $manufacturer = cleanInput($_POST['manufacturer'] ?? '');
    $batch_number = cleanInput($_POST['batch_number'] ?? '');
    $quantity = intval($_POST['quantity'] ?? 0);
    $min_stock_alert = intval($_POST['min_stock_alert'] ?? 10);
    $price = floatval($_POST['price'] ?? 0);
    $expiry_date = cleanInput($_POST['expiry_date'] ?? '');

    $med_code = generateCode('MED', 'medicines', 'medicine_code');

    $ins = $pdo->prepare("
        INSERT INTO medicines (medicine_code, name, category, manufacturer, batch_number, quantity, min_stock_alert, price, expiry_date) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $ins->execute([$med_code, $name, $category, $manufacturer, $batch_number, $quantity, $min_stock_alert, $price, $expiry_date]);

    logAudit($user['id'], $user['name'], 'Admin', 'MEDICINE_ADD', "Added new medicine {$name} (Code: {$med_code}).");
    setFlash('success', "Medicine '{$name}' added to inventory! (Code: {$med_code})");
    header("Location: pharmacy.php");
    exit();
}

// 2. Edit Medicine Details & Stock
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_medicine'])) {
    validateCSRFOrDie();
    $id = intval($_POST['med_id'] ?? 0);
    $name = cleanInput($_POST['name'] ?? '');
    $category = cleanInput($_POST['category'] ?? '');
    $manufacturer = cleanInput($_POST['manufacturer'] ?? '');
    $batch_number = cleanInput($_POST['batch_number'] ?? '');
    $quantity = intval($_POST['quantity'] ?? 0);
    $min_stock_alert = intval($_POST['min_stock_alert'] ?? 10);
    $price = floatval($_POST['price'] ?? 0);
    $expiry_date = cleanInput($_POST['expiry_date'] ?? '');

    $upd = $pdo->prepare("
        UPDATE medicines 
        SET name = ?, category = ?, manufacturer = ?, batch_number = ?, quantity = ?, min_stock_alert = ?, price = ?, expiry_date = ? 
        WHERE id = ?
    ");
    $upd->execute([$name, $category, $manufacturer, $batch_number, $quantity, $min_stock_alert, $price, $expiry_date, $id]);

    logAudit($user['id'], $user['name'], 'Admin', 'MEDICINE_EDIT', "Edited medicine ID {$id} ({$name}) stock to {$quantity}.");
    setFlash('success', "Medicine '{$name}' updated successfully!");
    header("Location: pharmacy.php");
    exit();
}

// 3. Quick Adjust Stock (+ or -)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['adjust_stock'])) {
    validateCSRFOrDie();
    $id = intval($_POST['med_id'] ?? 0);
    $adjust_amount = intval($_POST['adjust_amount'] ?? 0);
    $operation = cleanInput($_POST['operation'] ?? 'add');

    $curQty = $pdo->prepare("SELECT quantity, name FROM medicines WHERE id = ?");
    $curQty->execute([$id]);
    $item = $curQty->fetch();

    if ($item) {
        $newQty = ($operation === 'add') ? ($item['quantity'] + $adjust_amount) : max(0, $item['quantity'] - $adjust_amount);
        $pdo->prepare("UPDATE medicines SET quantity = ? WHERE id = ?")->execute([$newQty, $id]);
        logAudit($user['id'], $user['name'], 'Admin', 'STOCK_ADJUST', "Adjusted stock for {$item['name']} from {$item['quantity']} to {$newQty}.");
        setFlash('success', "Stock for '{$item['name']}' updated to {$newQty} units.");
    }
    header("Location: pharmacy.php");
    exit();
}

// 4. Delete Medicine
if (isset($_GET['action']) && $_GET['action'] === 'delete') {
    $id = intval($_GET['id'] ?? 0);
    $pdo->prepare("DELETE FROM medicines WHERE id = ?")->execute([$id]);
    setFlash('warning', "Medicine removed from catalog.");
    header("Location: pharmacy.php");
    exit();
}

// Filter Status
$filter = cleanInput($_GET['filter'] ?? 'all');
$medicines = $pdo->query("SELECT * FROM medicines ORDER BY name ASC")->fetchAll();

$totalMeds = count($medicines);
$lowStockCount = 0;
$expiredCount = 0;
$inStockCount = 0;

$filteredMeds = [];
$todayTime = strtotime(date('Y-m-d'));

foreach ($medicines as $m) {
    $isExp = (strtotime($m['expiry_date']) < $todayTime);
    $isLow = ($m['quantity'] <= $m['min_stock_alert']);

    if ($isExp) $expiredCount++;
    elseif ($isLow) $lowStockCount++;
    else $inStockCount++;

    if ($filter === 'low' && $isLow && !$isExp) $filteredMeds[] = $m;
    elseif ($filter === 'expired' && $isExp) $filteredMeds[] = $m;
    elseif ($filter === 'instock' && !$isLow && !$isExp) $filteredMeds[] = $m;
    elseif ($filter === 'all') $filteredMeds[] = $m;
}

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-3 p-md-4">
            <?php displayFlash(); ?>

            <!-- Page Header -->
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-2 mb-4">
                <div>
                    <h3 class="fw-bold mb-1"><i class="bi bi-capsule text-primary me-2"></i>Global Pharmacy Stock Master</h3>
                    <p class="text-muted mb-0 fs-7">Manage medicines inventory, adjust batch quantities, edit prices, and track expiry.</p>
                </div>
                <button type="button" class="btn btn-primary rounded-pill px-4 shadow-sm fs-7" data-bs-toggle="modal" data-bs-target="#addMedModal">
                    <i class="bi bi-plus-lg me-1"></i> Add New Medicine
                </button>
            </div>

            <!-- KPI Metric Cards -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-primary">
                        <small class="text-muted text-uppercase fw-bold fs-8">Total Catalog Items</small>
                        <h2 class="fw-bold mb-0 text-primary"><?= $totalMeds ?></h2>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-success">
                        <small class="text-muted text-uppercase fw-bold fs-8">Healthy Stock</small>
                        <h2 class="fw-bold mb-0 text-success"><?= $inStockCount ?></h2>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-warning">
                        <small class="text-muted text-uppercase fw-bold fs-8">Low Stock Alerts</small>
                        <h2 class="fw-bold mb-0 text-warning"><?= $lowStockCount ?></h2>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-danger">
                        <small class="text-muted text-uppercase fw-bold fs-8">Expired Items</small>
                        <h2 class="fw-bold mb-0 text-danger"><?= $expiredCount ?></h2>
                    </div>
                </div>
            </div>

            <!-- Filter Tabs & Table -->
            <div class="card card-custom border-0 shadow-sm">
                <div class="card-header bg-body border-0 py-3 d-flex flex-wrap gap-2 align-items-center">
                    <a href="pharmacy.php?filter=all" class="btn btn-sm rounded-pill <?= $filter === 'all' ? 'btn-primary' : 'btn-outline-secondary' ?>">
                        All Medicines (<?= $totalMeds ?>)
                    </a>
                    <a href="pharmacy.php?filter=instock" class="btn btn-sm rounded-pill <?= $filter === 'instock' ? 'btn-success text-white' : 'btn-outline-success' ?>">
                        <i class="bi bi-check-circle me-1"></i> In Stock (<?= $inStockCount ?>)
                    </a>
                    <a href="pharmacy.php?filter=low" class="btn btn-sm rounded-pill <?= $filter === 'low' ? 'btn-warning text-dark' : 'btn-outline-warning' ?>">
                        <i class="bi bi-exclamation-triangle me-1"></i> Low Stock (<?= $lowStockCount ?>)
                    </a>
                    <a href="pharmacy.php?filter=expired" class="btn btn-sm rounded-pill <?= $filter === 'expired' ? 'btn-danger text-white' : 'btn-outline-danger' ?>">
                        <i class="bi bi-clock-history me-1"></i> Expired (<?= $expiredCount ?>)
                    </a>
                </div>

                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 fs-7">
                        <thead class="table-light text-uppercase">
                            <tr>
                                <th>Code</th>
                                <th>Medicine Name</th>
                                <th>Category</th>
                                <th>Batch No.</th>
                                <th>Stock Qty</th>
                                <th>Unit Price</th>
                                <th>Expiry Date</th>
                                <th>Status</th>
                                <th class="text-end">Actions / Stock Edit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($filteredMeds)): ?>
                                <tr>
                                    <td colspan="9" class="text-center py-5 text-muted">
                                        <i class="bi bi-capsule fs-1 d-block mb-2 text-muted"></i>
                                        No medicines found matching selected filter.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($filteredMeds as $med): ?>
                                    <?php
                                    $isExp = (strtotime($med['expiry_date']) < $todayTime);
                                    $isLow = ($med['quantity'] <= $med['min_stock_alert']);
                                    ?>
                                    <tr>
                                        <td class="fw-bold text-primary"><?= htmlspecialchars($med['medicine_code']) ?></td>
                                        <td>
                                            <div class="fw-bold text-body"><?= htmlspecialchars($med['name']) ?></div>
                                            <small class="text-muted"><?= htmlspecialchars($med['manufacturer']) ?></small>
                                        </td>
                                        <td><span class="badge bg-secondary"><?= htmlspecialchars($med['category']) ?></span></td>
                                        <td><code><?= htmlspecialchars($med['batch_number']) ?></code></td>
                                        <td>
                                            <span class="fw-bold fs-6 <?= $isLow ? 'text-danger' : 'text-success' ?>">
                                                <?= $med['quantity'] ?> units
                                            </span>
                                            <small class="text-muted d-block fs-8">(Min alert: <?= $med['min_stock_alert'] ?>)</small>
                                        </td>
                                        <td class="fw-semibold"><?= formatCurrency($med['price']) ?></td>
                                        <td>
                                            <div class="<?= $isExp ? 'text-danger fw-bold' : '' ?>">
                                                <?= formatDate($med['expiry_date'], 'd M Y') ?>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if ($isExp): ?>
                                                <span class="badge bg-danger"><i class="bi bi-x-circle me-1"></i>Expired</span>
                                            <?php elseif ($isLow): ?>
                                                <span class="badge bg-warning text-dark"><i class="bi bi-exclamation-triangle me-1"></i>Low Stock</span>
                                            <?php else: ?>
                                                <span class="badge bg-success"><i class="bi bi-check-circle me-1"></i>In Stock</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end">
                                            <div class="btn-group btn-group-sm">
                                                <!-- Quick Restock Button -->
                                                <button type="button" class="btn btn-outline-success rounded-pill px-2 me-1" onclick="openStockModal(<?= $med['id'] ?>, '<?= htmlspecialchars(addslashes($med['name'])) ?>', <?= $med['quantity'] ?>)" title="Quick Stock Adjustment">
                                                    <i class="bi bi-plus-slash-minus me-1"></i> Stock
                                                </button>

                                                <!-- Full Edit Button -->
                                                <button type="button" class="btn btn-outline-primary rounded-pill px-3 me-1" onclick="openEditMedModal(<?= htmlspecialchars(json_encode($med)) ?>)">
                                                    <i class="bi bi-pencil-square me-1"></i> Edit
                                                </button>

                                                <!-- Delete -->
                                                <a href="pharmacy.php?action=delete&id=<?= $med['id'] ?>" class="btn btn-outline-danger rounded-pill px-2" onclick="return confirm('Delete <?= htmlspecialchars(addslashes($med['name'])) ?>?')" title="Delete Medicine">
                                                    <i class="bi bi-trash"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        <!-- Add Medicine Modal -->
        <div class="modal fade" id="addMedModal" tabindex="-1">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-capsule me-2"></i> Add Medicine Item</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST" action="">
                        <?= renderCSRFField() ?>
                        <input type="hidden" name="add_medicine" value="1">

                        <div class="modal-body p-4">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Medicine Name *</label>
                                    <input type="text" name="name" class="form-control" placeholder="e.g. Paracetamol 650mg" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Category *</label>
                                    <input type="text" name="category" class="form-control" placeholder="e.g. Analgesic / Antibiotic / Antacid" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Manufacturer *</label>
                                    <input type="text" name="manufacturer" class="form-control" placeholder="e.g. Cipla Ltd / Sun Pharma" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Batch Number *</label>
                                    <input type="text" name="batch_number" class="form-control" placeholder="e.g. BAT-90812" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Initial Stock *</label>
                                    <input type="number" name="quantity" class="form-control" min="0" value="100" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Min Alert Level</label>
                                    <input type="number" name="min_stock_alert" class="form-control" min="1" value="15" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Price per Unit (₹) *</label>
                                    <input type="number" step="0.01" name="price" class="form-control" placeholder="25.00" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Expiry Date *</label>
                                    <input type="date" name="expiry_date" class="form-control" min="<?= date('Y-m-d') ?>" required>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-top-0 pt-0">
                            <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary rounded-pill px-4 shadow">Add to Catalog</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Edit Medicine Modal -->
        <div class="modal fade" id="editMedModal" tabindex="-1">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-dark text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-pencil-square me-2"></i> Edit Medicine & Stock</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST" action="">
                        <?= renderCSRFField() ?>
                        <input type="hidden" name="edit_medicine" value="1">
                        <input type="hidden" name="med_id" id="edit_med_id">

                        <div class="modal-body p-4">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Medicine Name *</label>
                                    <input type="text" name="name" id="edit_name" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Category *</label>
                                    <input type="text" name="category" id="edit_category" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Manufacturer</label>
                                    <input type="text" name="manufacturer" id="edit_manufacturer" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Batch Number *</label>
                                    <input type="text" name="batch_number" id="edit_batch" class="form-control" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Stock Quantity (Units) *</label>
                                    <input type="number" name="quantity" id="edit_quantity" class="form-control" min="0" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Low Alert Threshold</label>
                                    <input type="number" name="min_stock_alert" id="edit_min_alert" class="form-control" min="1" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Price per Unit (₹) *</label>
                                    <input type="number" step="0.01" name="price" id="edit_price" class="form-control" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Expiry Date *</label>
                                    <input type="date" name="expiry_date" id="edit_expiry" class="form-control" required>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-top-0 pt-0">
                            <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary rounded-pill px-4 shadow">Update Medicine</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Quick Stock Adjust Modal -->
        <div class="modal fade" id="stockAdjustModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-success text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-plus-slash-minus me-2"></i> Quick Stock Adjustment</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST" action="">
                        <?= renderCSRFField() ?>
                        <input type="hidden" name="adjust_stock" value="1">
                        <input type="hidden" name="med_id" id="stock_med_id">

                        <div class="modal-body p-4">
                            <div class="p-3 bg-body-tertiary rounded-3 mb-3 border text-center">
                                <h6 class="fw-bold mb-1 text-primary" id="stock_med_name">Medicine Name</h6>
                                <small class="text-muted">Current Quantity: <strong id="stock_cur_qty" class="text-dark">0</strong> units</small>
                            </div>

                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Operation *</label>
                                    <select name="operation" class="form-select">
                                        <option value="add">➕ Add Stock (Restock)</option>
                                        <option value="deduct">➖ Deduct Stock (Dispense / Damage)</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Units Count *</label>
                                    <input type="number" name="adjust_amount" class="form-control" min="1" value="50" required>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-top-0 pt-0">
                            <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-success rounded-pill px-4 shadow">Apply Stock Adjustment</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>

<script>
function openEditMedModal(med) {
    document.getElementById('edit_med_id').value = med.id;
    document.getElementById('edit_name').value = med.name;
    document.getElementById('edit_category').value = med.category;
    document.getElementById('edit_manufacturer').value = med.manufacturer;
    document.getElementById('edit_batch').value = med.batch_number;
    document.getElementById('edit_quantity').value = med.quantity;
    document.getElementById('edit_min_alert').value = med.min_stock_alert;
    document.getElementById('edit_price').value = parseFloat(med.price).toFixed(2);
    document.getElementById('edit_expiry').value = med.expiry_date;
    new bootstrap.Modal(document.getElementById('editMedModal')).show();
}

function openStockModal(id, name, qty) {
    document.getElementById('stock_med_id').value = id;
    document.getElementById('stock_med_name').textContent = name;
    document.getElementById('stock_cur_qty').textContent = qty;
    new bootstrap.Modal(document.getElementById('stockAdjustModal')).show();
}
</script>
