<?php
// MediCareX - Admin Room & Bed Management Matrix
// Developed by Romit Kumar

$pageTitle = 'Rooms & Beds Matrix';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

requireRole('Admin');

$user = getCurrentUser();
$pdo = getDBConnection();

// 1. Handle Add Room
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_room'])) {
    validateCSRFOrDie();
    $room_number = cleanInput($_POST['room_number'] ?? '');
    $room_type = cleanInput($_POST['room_type'] ?? 'General Ward');
    $floor = cleanInput($_POST['floor'] ?? '1st Floor');
    $daily_rate = floatval($_POST['daily_rate'] ?? 500.00);

    $ins = $pdo->prepare("INSERT INTO rooms (room_number, room_type, floor, daily_rate, status) VALUES (?, ?, ?, ?, 'Active')");
    $ins->execute([$room_number, $room_type, $floor, $daily_rate]);

    logAudit($user['id'], $user['name'], 'Admin', 'ROOM_ADD', "Created room {$room_number} ({$room_type}).");
    setFlash('success', "Room {$room_number} added successfully!");
    header("Location: rooms_beds.php");
    exit();
}

// 2. Handle Add Bed
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_bed'])) {
    validateCSRFOrDie();
    $room_id = intval($_POST['room_id'] ?? 0);
    $bed_number = cleanInput($_POST['bed_number'] ?? '');
    $status = cleanInput($_POST['status'] ?? 'Available');

    $ins = $pdo->prepare("INSERT INTO beds (room_id, bed_number, status) VALUES (?, ?, ?)");
    $ins->execute([$room_id, $bed_number, $status]);

    logAudit($user['id'], $user['name'], 'Admin', 'BED_ADD', "Added bed {$bed_number} to room ID {$room_id}.");
    setFlash('success', "Bed {$bed_number} added successfully!");
    header("Location: rooms_beds.php");
    exit();
}

// 3. Handle Edit Bed Status & Details
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_bed'])) {
    validateCSRFOrDie();
    $bed_id = intval($_POST['bed_id'] ?? 0);
    $room_id = intval($_POST['room_id'] ?? 0);
    $bed_number = cleanInput($_POST['bed_number'] ?? '');
    $status = cleanInput($_POST['status'] ?? 'Available');

    $upd = $pdo->prepare("UPDATE beds SET room_id = ?, bed_number = ?, status = ? WHERE id = ?");
    $upd->execute([$room_id, $bed_number, $status, $bed_id]);

    logAudit($user['id'], $user['name'], 'Admin', 'BED_UPDATE', "Updated bed ID {$bed_id} ({$bed_number}) status to {$status}.");
    setFlash('success', "Bed {$bed_number} updated to status: {$status}");
    header("Location: rooms_beds.php");
    exit();
}

// 4. Handle Edit Room Details
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_room'])) {
    validateCSRFOrDie();
    $room_id = intval($_POST['room_id'] ?? 0);
    $room_number = cleanInput($_POST['room_number'] ?? '');
    $room_type = cleanInput($_POST['room_type'] ?? 'General Ward');
    $floor = cleanInput($_POST['floor'] ?? '1st Floor');
    $daily_rate = floatval($_POST['daily_rate'] ?? 500.00);

    $upd = $pdo->prepare("UPDATE rooms SET room_number = ?, room_type = ?, floor = ?, daily_rate = ? WHERE id = ?");
    $upd->execute([$room_number, $room_type, $floor, $daily_rate, $room_id]);

    logAudit($user['id'], $user['name'], 'Admin', 'ROOM_UPDATE', "Updated room ID {$room_id} ({$room_number}).");
    setFlash('success', "Room {$room_number} updated successfully!");
    header("Location: rooms_beds.php");
    exit();
}

// 5. Handle Delete Bed
if (isset($_GET['action']) && $_GET['action'] === 'delete_bed') {
    $bed_id = intval($_GET['id'] ?? 0);
    $pdo->prepare("DELETE FROM beds WHERE id = ?")->execute([$bed_id]);
    setFlash('warning', "Bed record deleted.");
    header("Location: rooms_beds.php");
    exit();
}

// 6. Handle Quick Status Change via GET
if (isset($_GET['action']) && $_GET['action'] === 'set_bed_status') {
    $bed_id = intval($_GET['id'] ?? 0);
    $new_status = cleanInput($_GET['status'] ?? 'Available');
    if (in_array($new_status, ['Available', 'Occupied', 'Under Maintenance'])) {
        $pdo->prepare("UPDATE beds SET status = ? WHERE id = ?")->execute([$new_status, $bed_id]);
        setFlash('success', "Bed #{$bed_id} marked as {$new_status}.");
    }
    header("Location: rooms_beds.php");
    exit();
}

// Query Rooms & Beds
$rooms = $pdo->query("SELECT * FROM rooms ORDER BY room_number ASC")->fetchAll();

$filterStatus = cleanInput($_GET['status'] ?? 'All');
$whereClause = "";
$params = [];
if ($filterStatus !== 'All') {
    $whereClause = "WHERE b.status = ?";
    $params[] = $filterStatus;
}

$bedStmt = $pdo->prepare("
    SELECT b.*, r.room_number, r.room_type, r.floor, r.daily_rate 
    FROM beds b 
    JOIN rooms r ON b.room_id = r.id 
    {$whereClause}
    ORDER BY r.room_number ASC, b.bed_number ASC
");
$bedStmt->execute($params);
$beds = $bedStmt->fetchAll();

// Statistics
$totalBeds = $pdo->query("SELECT COUNT(*) FROM beds")->fetchColumn();
$availBeds = $pdo->query("SELECT COUNT(*) FROM beds WHERE status = 'Available'")->fetchColumn();
$occBeds = $pdo->query("SELECT COUNT(*) FROM beds WHERE status = 'Occupied'")->fetchColumn();
$maintBeds = $pdo->query("SELECT COUNT(*) FROM beds WHERE status = 'Under Maintenance'")->fetchColumn();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-3 p-md-4">
            <?php displayFlash(); ?>

            <!-- Page Header -->
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-2 mb-4">
                <div>
                    <h3 class="fw-bold mb-1"><i class="bi bi-hospital text-primary me-2"></i>Rooms & Beds Matrix</h3>
                    <p class="text-muted mb-0 fs-7">Manage hospital in-patient wards, room categories, bed status (Available, Occupied, Under Maintenance).</p>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" class="btn btn-outline-primary rounded-pill px-3 shadow-sm fs-7" data-bs-toggle="modal" data-bs-target="#addRoomModal">
                        <i class="bi bi-door-open me-1"></i> Add Room
                    </button>
                    <button type="button" class="btn btn-primary rounded-pill px-3 shadow-sm fs-7" data-bs-toggle="modal" data-bs-target="#addBedModal">
                        <i class="bi bi-plus-lg me-1"></i> Add Bed
                    </button>
                </div>
            </div>

            <!-- KPI Metric Cards -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-primary">
                        <small class="text-muted text-uppercase fw-bold fs-8">Total Beds</small>
                        <h2 class="fw-bold mb-0 text-primary"><?= $totalBeds ?></h2>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-success">
                        <small class="text-muted text-uppercase fw-bold fs-8">Available Beds</small>
                        <h2 class="fw-bold mb-0 text-success"><?= $availBeds ?></h2>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-danger">
                        <small class="text-muted text-uppercase fw-bold fs-8">Occupied Beds</small>
                        <h2 class="fw-bold mb-0 text-danger"><?= $occBeds ?></h2>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-warning">
                        <small class="text-muted text-uppercase fw-bold fs-8">Under Maintenance</small>
                        <h2 class="fw-bold mb-0 text-warning"><?= $maintBeds ?></h2>
                    </div>
                </div>
            </div>

            <!-- Filter Status Tabs -->
            <div class="card card-custom border-0 shadow-sm mb-4">
                <div class="card-header bg-body border-0 py-3 d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
                    <div class="d-flex flex-wrap gap-2">
                        <a href="rooms_beds.php?status=All" class="btn btn-sm rounded-pill <?= $filterStatus === 'All' ? 'btn-primary' : 'btn-outline-secondary' ?>">
                            All Beds (<?= $totalBeds ?>)
                        </a>
                        <a href="rooms_beds.php?status=Available" class="btn btn-sm rounded-pill <?= $filterStatus === 'Available' ? 'btn-success text-white' : 'btn-outline-success' ?>">
                            <i class="bi bi-check-circle me-1"></i> Available (<?= $availBeds ?>)
                        </a>
                        <a href="rooms_beds.php?status=Occupied" class="btn btn-sm rounded-pill <?= $filterStatus === 'Occupied' ? 'btn-danger text-white' : 'btn-outline-danger' ?>">
                            <i class="bi bi-person-fill me-1"></i> Occupied (<?= $occBeds ?>)
                        </a>
                        <a href="rooms_beds.php?status=Under Maintenance" class="btn btn-sm rounded-pill <?= $filterStatus === 'Under Maintenance' ? 'btn-warning text-dark' : 'btn-outline-warning' ?>">
                            <i class="bi bi-tools me-1"></i> Maintenance (<?= $maintBeds ?>)
                        </a>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 fs-7">
                        <thead class="table-light text-uppercase">
                            <tr>
                                <th>Bed ID</th>
                                <th>Room Number</th>
                                <th>Category</th>
                                <th>Floor</th>
                                <th>Bed Number</th>
                                <th>Daily Rate</th>
                                <th>Status</th>
                                <th class="text-end">Actions / Quick Update</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($beds)): ?>
                                <tr>
                                    <td colspan="8" class="text-center py-5 text-muted">
                                        <i class="bi bi-hospital fs-1 d-block mb-2 text-muted"></i>
                                        No bed records found matching "<?= htmlspecialchars($filterStatus) ?>".
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($beds as $bed): ?>
                                    <tr>
                                        <td>#<?= $bed['id'] ?></td>
                                        <td class="fw-bold text-primary">
                                            <i class="bi bi-door-closed me-1"></i><?= htmlspecialchars($bed['room_number']) ?>
                                        </td>
                                        <td><span class="badge bg-secondary"><?= htmlspecialchars($bed['room_type']) ?></span></td>
                                        <td><?= htmlspecialchars($bed['floor']) ?></td>
                                        <td><span class="badge bg-dark fs-7"><i class="bi bi-layout-sidebar me-1"></i><?= htmlspecialchars($bed['bed_number']) ?></span></td>
                                        <td class="fw-semibold text-success"><?= formatCurrency($bed['daily_rate']) ?>/day</td>
                                        <td>
                                            <?php if ($bed['status'] === 'Available'): ?>
                                                <span class="badge bg-success"><i class="bi bi-check-circle me-1"></i>Available</span>
                                            <?php elseif ($bed['status'] === 'Occupied'): ?>
                                                <span class="badge bg-danger"><i class="bi bi-person-fill me-1"></i>Occupied</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning text-dark"><i class="bi bi-tools me-1"></i>Under Maintenance</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end">
                                            <div class="btn-group btn-group-sm">
                                                <!-- Quick Status Dropdown -->
                                                <button type="button" class="btn btn-outline-secondary dropdown-toggle rounded-pill px-2 me-1" data-bs-toggle="dropdown">
                                                    Status
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-end fs-8 shadow-sm">
                                                    <li><a class="dropdown-item text-success" href="rooms_beds.php?action=set_bed_status&id=<?= $bed['id'] ?>&status=Available"><i class="bi bi-check-circle me-2"></i>Set Available</a></li>
                                                    <li><a class="dropdown-item text-danger" href="rooms_beds.php?action=set_bed_status&id=<?= $bed['id'] ?>&status=Occupied"><i class="bi bi-person-fill me-2"></i>Set Occupied</a></li>
                                                    <li><a class="dropdown-item text-warning" href="rooms_beds.php?action=set_bed_status&id=<?= $bed['id'] ?>&status=Under Maintenance"><i class="bi bi-tools me-2"></i>Set Maintenance</a></li>
                                                </ul>

                                                <!-- Full Edit Button -->
                                                <button type="button" class="btn btn-outline-primary rounded-pill px-3 me-1" onclick="openEditBedModal(<?= htmlspecialchars(json_encode($bed)) ?>)">
                                                    <i class="bi bi-pencil-square me-1"></i> Edit
                                                </button>

                                                <!-- Delete -->
                                                <a href="rooms_beds.php?action=delete_bed&id=<?= $bed['id'] ?>" class="btn btn-outline-danger rounded-pill px-2" onclick="return confirm('Delete Bed <?= htmlspecialchars($bed['bed_number']) ?>?')" title="Delete Bed">
                                                    <i class="bi bi-trash"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Room Catalog Overview Section -->
            <div class="card card-custom border-0 shadow-sm mt-4">
                <div class="card-header bg-body border-0 py-3 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0"><i class="bi bi-building me-2 text-primary"></i>Room Categories & Floor Directory</h5>
                    <button type="button" class="btn btn-sm btn-outline-primary rounded-pill" data-bs-toggle="modal" data-bs-target="#addRoomModal">
                        <i class="bi bi-plus me-1"></i> New Room
                    </button>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 fs-7">
                        <thead class="table-light text-uppercase">
                            <tr>
                                <th>Room No.</th>
                                <th>Category / Type</th>
                                <th>Floor</th>
                                <th>Daily Charge</th>
                                <th>Total Beds</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($rooms as $rm): ?>
                                <?php
                                $bedCount = $pdo->prepare("SELECT COUNT(*) FROM beds WHERE room_id = ?");
                                $bedCount->execute([$rm['id']]);
                                $bCnt = $bedCount->fetchColumn();
                                ?>
                                <tr>
                                    <td class="fw-bold text-primary">Room <?= htmlspecialchars($rm['room_number']) ?></td>
                                    <td><?= htmlspecialchars($rm['room_type']) ?></td>
                                    <td><?= htmlspecialchars($rm['floor']) ?></td>
                                    <td class="fw-bold text-success"><?= formatCurrency($rm['daily_rate']) ?></td>
                                    <td><span class="badge bg-primary rounded-pill"><?= $bCnt ?> Beds</span></td>
                                    <td class="text-end">
                                        <button type="button" class="btn btn-sm btn-outline-secondary rounded-pill" onclick="openEditRoomModal(<?= htmlspecialchars(json_encode($rm)) ?>)">
                                            <i class="bi bi-pencil me-1"></i> Edit Room
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        <!-- Add Room Modal -->
        <div class="modal fade" id="addRoomModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-door-open me-2"></i> Add Hospital Room</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST" action="">
                        <?= renderCSRFField() ?>
                        <input type="hidden" name="add_room" value="1">
                        <div class="modal-body p-4">
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Room Number *</label>
                                <input type="text" name="room_number" class="form-control" placeholder="e.g. 101, 204, ICU-01" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Room Category *</label>
                                <select name="room_type" class="form-select" required>
                                    <option value="General Ward">General Ward</option>
                                    <option value="Semi-Private">Semi-Private Room</option>
                                    <option value="Private Deluxe">Private Deluxe</option>
                                    <option value="Intensive Care Unit (ICU)">Intensive Care Unit (ICU)</option>
                                    <option value="Cardiac Care Unit (CCU)">Cardiac Care Unit (CCU)</option>
                                    <option value="Emergency Trauma">Emergency Trauma</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Floor Location *</label>
                                <select name="floor" class="form-select" required>
                                    <option value="Ground Floor">Ground Floor</option>
                                    <option value="1st Floor">1st Floor</option>
                                    <option value="2nd Floor">2nd Floor</option>
                                    <option value="3rd Floor">3rd Floor</option>
                                    <option value="4th Floor">4th Floor</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Daily Rate (₹) *</label>
                                <input type="number" step="0.01" name="daily_rate" class="form-control" value="800.00" required>
                            </div>
                        </div>
                        <div class="modal-footer border-top-0 pt-0">
                            <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary rounded-pill px-4 shadow">Save Room</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Add Bed Modal -->
        <div class="modal fade" id="addBedModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-layout-sidebar me-2"></i> Add Hospital Bed</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST" action="">
                        <?= renderCSRFField() ?>
                        <input type="hidden" name="add_bed" value="1">
                        <div class="modal-body p-4">
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Select Room *</label>
                                <select name="room_id" class="form-select" required>
                                    <option value="">-- Choose Room --</option>
                                    <?php foreach ($rooms as $rm): ?>
                                        <option value="<?= $rm['id'] ?>">Room <?= htmlspecialchars($rm['room_number']) ?> (<?= htmlspecialchars($rm['room_type']) ?> - <?= htmlspecialchars($rm['floor']) ?>)</option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Bed Number *</label>
                                <input type="text" name="bed_number" class="form-control" placeholder="e.g. Bed-1, Bed-2, ICU-B1" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Initial Status *</label>
                                <select name="status" class="form-select" required>
                                    <option value="Available">Available</option>
                                    <option value="Occupied">Occupied</option>
                                    <option value="Under Maintenance">Under Maintenance</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer border-top-0 pt-0">
                            <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary rounded-pill px-4 shadow">Add Bed</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Edit Bed Modal -->
        <div class="modal fade" id="editBedModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-dark text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-pencil-square me-2"></i> Edit Bed Status & Details</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST" action="">
                        <?= renderCSRFField() ?>
                        <input type="hidden" name="edit_bed" value="1">
                        <input type="hidden" name="bed_id" id="edit_bed_id">

                        <div class="modal-body p-4">
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Assigned Room *</label>
                                <select name="room_id" id="edit_bed_room_id" class="form-select" required>
                                    <?php foreach ($rooms as $rm): ?>
                                        <option value="<?= $rm['id'] ?>">Room <?= htmlspecialchars($rm['room_number']) ?> (<?= htmlspecialchars($rm['room_type']) ?>)</option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Bed Code / Number *</label>
                                <input type="text" name="bed_number" id="edit_bed_number" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Occupancy & Operational Status *</label>
                                <select name="status" id="edit_bed_status" class="form-select" required>
                                    <option value="Available">🟢 Available (Vacant for Admission)</option>
                                    <option value="Occupied">🔴 Occupied (Patient Admitted)</option>
                                    <option value="Under Maintenance">🟡 Under Maintenance (Sanitizing / Repair)</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer border-top-0 pt-0">
                            <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary rounded-pill px-4 shadow">Update Bed Status</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Edit Room Modal -->
        <div class="modal fade" id="editRoomModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-dark text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-pencil-square me-2"></i> Edit Room Details</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST" action="">
                        <?= renderCSRFField() ?>
                        <input type="hidden" name="edit_room" value="1">
                        <input type="hidden" name="room_id" id="edit_room_id">

                        <div class="modal-body p-4">
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Room Number *</label>
                                <input type="text" name="room_number" id="edit_room_number" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Category *</label>
                                <select name="room_type" id="edit_room_type" class="form-select" required>
                                    <option value="General Ward">General Ward</option>
                                    <option value="Semi-Private">Semi-Private</option>
                                    <option value="Private Deluxe">Private Deluxe</option>
                                    <option value="Intensive Care Unit (ICU)">Intensive Care Unit (ICU)</option>
                                    <option value="Cardiac Care Unit (CCU)">Cardiac Care Unit (CCU)</option>
                                    <option value="Emergency Trauma">Emergency Trauma</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Floor *</label>
                                <select name="floor" id="edit_room_floor" class="form-select" required>
                                    <option value="Ground Floor">Ground Floor</option>
                                    <option value="1st Floor">1st Floor</option>
                                    <option value="2nd Floor">2nd Floor</option>
                                    <option value="3rd Floor">3rd Floor</option>
                                    <option value="4th Floor">4th Floor</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Daily Rate (₹) *</label>
                                <input type="number" step="0.01" name="daily_rate" id="edit_room_rate" class="form-control" required>
                            </div>
                        </div>
                        <div class="modal-footer border-top-0 pt-0">
                            <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary rounded-pill px-4 shadow">Save Room Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>

<script>
function openEditBedModal(bed) {
    document.getElementById('edit_bed_id').value = bed.id;
    document.getElementById('edit_bed_room_id').value = bed.room_id;
    document.getElementById('edit_bed_number').value = bed.bed_number;
    document.getElementById('edit_bed_status').value = bed.status;
    new bootstrap.Modal(document.getElementById('editBedModal')).show();
}

function openEditRoomModal(room) {
    document.getElementById('edit_room_id').value = room.id;
    document.getElementById('edit_room_number').value = room.room_number;
    document.getElementById('edit_room_type').value = room.room_type;
    document.getElementById('edit_room_floor').value = room.floor;
    document.getElementById('edit_room_rate').value = parseFloat(room.daily_rate).toFixed(2);
    new bootstrap.Modal(document.getElementById('editRoomModal')).show();
}
</script>
