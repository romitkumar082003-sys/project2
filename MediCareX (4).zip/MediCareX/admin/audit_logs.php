<?php
// MediCareX - System Audit Log Viewer
// Developed by Romit Kumar

$pageTitle = 'Audit Logs';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole('Admin');

$user = getCurrentUser();
$pdo = getDBConnection();

$logs = $pdo->query("SELECT * FROM audit_logs ORDER BY id DESC LIMIT 100")->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold mb-0">System Security Audit Logs</h3>
            </div>

            <div class="card card-custom border-0 shadow-sm">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0 fs-7">
                            <thead class="table-light text-uppercase">
                                <tr>
                                    <th>Log ID</th>
                                    <th>Timestamp</th>
                                    <th>User</th>
                                    <th>Role</th>
                                    <th>Action</th>
                                    <th>Description</th>
                                    <th>IP Address</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($logs as $l): ?>
                                    <tr>
                                        <td>#<?= $l['id'] ?></td>
                                        <td class="fw-semibold text-primary"><?= formatDate($l['created_at']) ?></td>
                                        <td class="fw-bold"><?= htmlspecialchars($l['user_name']) ?></td>
                                        <td><span class="badge bg-secondary"><?= htmlspecialchars($l['role']) ?></span></td>
                                        <td><span class="badge bg-dark"><?= htmlspecialchars($l['action']) ?></span></td>
                                        <td class="text-muted"><?= htmlspecialchars($l['description']) ?></td>
                                        <td><code><?= htmlspecialchars($l['ip_address']) ?></code></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
