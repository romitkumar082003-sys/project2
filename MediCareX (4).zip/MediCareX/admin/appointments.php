<?php
// MediCareX - Global Appointment Master & Status Manager
// Developed by Romit Kumar

$pageTitle = 'Global Appointments';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

requireRole('Admin');

$user = getCurrentUser();
$pdo = getDBConnection();

// 1. Handle Quick Status Change via POST or GET
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    validateCSRFOrDie();
    $apt_id = intval($_POST['apt_id'] ?? 0);
    $status = cleanInput($_POST['status'] ?? 'Confirmed');

    $allowed = ['Pending', 'Confirmed', 'Checked In', 'In Consultation', 'Completed', 'Cancelled'];
    if (in_array($status, $allowed)) {
        $upd = $pdo->prepare("UPDATE appointments SET status = ? WHERE id = ?");
        $upd->execute([$status, $apt_id]);

        logAudit($user['id'], $user['name'], 'Admin', 'APPOINTMENT_STATUS_UPDATE', "Updated appointment ID {$apt_id} status to {$status}.");
        setFlash('success', "Appointment #{$apt_id} status changed to '{$status}'.");
    }
    header("Location: appointments.php");
    exit();
}

// 2. Handle Full Edit Appointment (Date, Slot, Status, Reason)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_appointment'])) {
    validateCSRFOrDie();
    $apt_id = intval($_POST['apt_id'] ?? 0);
    $appointment_date = cleanInput($_POST['appointment_date'] ?? date('Y-m-d'));
    $time_slot = cleanInput($_POST['time_slot'] ?? '09:30 AM');
    $token_number = cleanInput($_POST['token_number'] ?? 'A-001');
    $status = cleanInput($_POST['status'] ?? 'Confirmed');
    $reason = cleanInput($_POST['reason'] ?? '');

    $upd = $pdo->prepare("
        UPDATE appointments 
        SET appointment_date = ?, time_slot = ?, token_number = ?, status = ?, reason = ? 
        WHERE id = ?
    ");
    $upd->execute([$appointment_date, $time_slot, $token_number, $status, $reason, $apt_id]);

    logAudit($user['id'], $user['name'], 'Admin', 'APPOINTMENT_EDIT', "Modified appointment ID {$apt_id} details.");
    setFlash('success', "Appointment details updated successfully!");
    header("Location: appointments.php");
    exit();
}

// 3. Quick Status via GET (1-click action)
if (isset($_GET['action']) && $_GET['action'] === 'set_status') {
    $apt_id = intval($_GET['id'] ?? 0);
    $status = cleanInput($_GET['status'] ?? '');
    $allowed = ['Pending', 'Confirmed', 'Checked In', 'In Consultation', 'Completed', 'Cancelled'];
    if (in_array($status, $allowed)) {
        $pdo->prepare("UPDATE appointments SET status = ? WHERE id = ?")->execute([$status, $apt_id]);
        logAudit($user['id'], $user['name'], 'Admin', 'APPOINTMENT_STATUS_UPDATE', "Quick updated appointment #{$apt_id} to {$status}.");
        setFlash('success', "Appointment marked as '{$status}'.");
    }
    header("Location: appointments.php");
    exit();
}

// Filter Status
$filterStatus = cleanInput($_GET['status'] ?? 'All');
$where = "";
$params = [];
if ($filterStatus !== 'All') {
    $where = "WHERE a.status = ?";
    $params[] = $filterStatus;
}

$appointments = $pdo->prepare("
    SELECT a.*, p.patient_code, u_p.name as patient_name, u_p.phone as patient_phone, 
           u_d.name as doctor_name, dep.dept_name, d.specialization
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    JOIN users u_p ON p.user_id = u_p.id
    JOIN doctors d ON a.doctor_id = d.id
    JOIN users u_d ON d.user_id = u_d.id
    JOIN departments dep ON a.department_id = dep.id
    {$where}
    ORDER BY a.appointment_date DESC, a.id DESC
");
$appointments->execute($params);
$aptList = $appointments->fetchAll();

// Counts
$totalApts = $pdo->query("SELECT COUNT(*) FROM appointments")->fetchColumn();
$pendingApts = $pdo->query("SELECT COUNT(*) FROM appointments WHERE status = 'Pending'")->fetchColumn();
$confirmedApts = $pdo->query("SELECT COUNT(*) FROM appointments WHERE status = 'Confirmed'")->fetchColumn();
$checkedInApts = $pdo->query("SELECT COUNT(*) FROM appointments WHERE status = 'Checked In'")->fetchColumn();
$completedApts = $pdo->query("SELECT COUNT(*) FROM appointments WHERE status = 'Completed'")->fetchColumn();
$cancelledApts = $pdo->query("SELECT COUNT(*) FROM appointments WHERE status = 'Cancelled'")->fetchColumn();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-3 p-md-4">
            <?php displayFlash(); ?>

            <!-- Page Header -->
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-2 mb-4">
                <div>
                    <h3 class="fw-bold mb-1"><i class="bi bi-calendar2-check text-primary me-2"></i>Global Appointments Master</h3>
                    <p class="text-muted mb-0 fs-7">Manage hospital OPD appointments, review statuses (Confirmed, Checked In, Pending, Completed) and modify bookings.</p>
                </div>
                <a href="<?= get_base_url() ?>/reception/book_appointment.php" class="btn btn-primary rounded-pill px-4 shadow-sm fs-7">
                    <i class="bi bi-plus-lg me-1"></i> New Walk-In Appointment
                </a>
            </div>

            <!-- KPI Metric Cards -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-2">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-primary">
                        <small class="text-muted text-uppercase fw-bold fs-8">Total</small>
                        <h3 class="fw-bold mb-0 text-primary"><?= $totalApts ?></h3>
                    </div>
                </div>
                <div class="col-6 col-md-2">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-success">
                        <small class="text-muted text-uppercase fw-bold fs-8">Confirmed</small>
                        <h3 class="fw-bold mb-0 text-success"><?= $confirmedApts ?></h3>
                    </div>
                </div>
                <div class="col-6 col-md-2">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-info">
                        <small class="text-muted text-uppercase fw-bold fs-8">Checked In</small>
                        <h3 class="fw-bold mb-0 text-info"><?= $checkedInApts ?></h3>
                    </div>
                </div>
                <div class="col-6 col-md-2">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-warning">
                        <small class="text-muted text-uppercase fw-bold fs-8">Pending</small>
                        <h3 class="fw-bold mb-0 text-warning"><?= $pendingApts ?></h3>
                    </div>
                </div>
                <div class="col-6 col-md-2">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-dark">
                        <small class="text-muted text-uppercase fw-bold fs-8">Completed</small>
                        <h3 class="fw-bold mb-0 text-dark"><?= $completedApts ?></h3>
                    </div>
                </div>
                <div class="col-6 col-md-2">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-danger">
                        <small class="text-muted text-uppercase fw-bold fs-8">Cancelled</small>
                        <h3 class="fw-bold mb-0 text-danger"><?= $cancelledApts ?></h3>
                    </div>
                </div>
            </div>

            <!-- Filter Status Tabs -->
            <div class="card card-custom border-0 shadow-sm">
                <div class="card-header bg-body border-0 py-3 d-flex flex-wrap gap-2 align-items-center">
                    <a href="appointments.php?status=All" class="btn btn-sm rounded-pill <?= $filterStatus === 'All' ? 'btn-primary' : 'btn-outline-secondary' ?>">
                        All (<?= $totalApts ?>)
                    </a>
                    <a href="appointments.php?status=Confirmed" class="btn btn-sm rounded-pill <?= $filterStatus === 'Confirmed' ? 'btn-success text-white' : 'btn-outline-success' ?>">
                        <i class="bi bi-check-circle me-1"></i> Confirmed (<?= $confirmedApts ?>)
                    </a>
                    <a href="appointments.php?status=Checked In" class="btn btn-sm rounded-pill <?= $filterStatus === 'Checked In' ? 'btn-info text-white' : 'btn-outline-info' ?>">
                        <i class="bi bi-person-check me-1"></i> Checked In (<?= $checkedInApts ?>)
                    </a>
                    <a href="appointments.php?status=Pending" class="btn btn-sm rounded-pill <?= $filterStatus === 'Pending' ? 'btn-warning text-dark' : 'btn-outline-warning' ?>">
                        <i class="bi bi-clock me-1"></i> Pending (<?= $pendingApts ?>)
                    </a>
                    <a href="appointments.php?status=Completed" class="btn btn-sm rounded-pill <?= $filterStatus === 'Completed' ? 'btn-dark' : 'btn-outline-dark' ?>">
                        <i class="bi bi-check-all me-1"></i> Completed (<?= $completedApts ?>)
                    </a>
                    <a href="appointments.php?status=Cancelled" class="btn btn-sm rounded-pill <?= $filterStatus === 'Cancelled' ? 'btn-danger text-white' : 'btn-outline-danger' ?>">
                        <i class="bi bi-x-circle me-1"></i> Cancelled (<?= $cancelledApts ?>)
                    </a>
                </div>

                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 fs-7">
                        <thead class="table-light text-uppercase">
                            <tr>
                                <th>Token</th>
                                <th>Code</th>
                                <th>Patient Name</th>
                                <th>Attending Doctor</th>
                                <th>Department</th>
                                <th>Date & Slot</th>
                                <th>Current Status</th>
                                <th class="text-end">Status Action / Edit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($aptList)): ?>
                                <tr>
                                    <td colspan="8" class="text-center py-5 text-muted">
                                        <i class="bi bi-calendar-x fs-1 d-block mb-2 text-muted"></i>
                                        No appointments found matching "<?= htmlspecialchars($filterStatus) ?>".
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($aptList as $apt): ?>
                                    <tr>
                                        <td><span class="badge bg-primary px-3 py-2 fs-7"><?= htmlspecialchars($apt['token_number']) ?></span></td>
                                        <td class="fw-bold text-primary"><?= htmlspecialchars($apt['appointment_code']) ?></td>
                                        <td>
                                            <div class="fw-bold text-body"><?= htmlspecialchars($apt['patient_name']) ?></div>
                                            <small class="text-muted"><?= htmlspecialchars($apt['patient_code']) ?> • <?= htmlspecialchars($apt['patient_phone'] ?? 'N/A') ?></small>
                                        </td>
                                        <td>
                                            <div class="fw-semibold"><?= htmlspecialchars($apt['doctor_name']) ?></div>
                                            <small class="text-muted"><?= htmlspecialchars($apt['specialization']) ?></small>
                                        </td>
                                        <td><span class="badge bg-secondary"><?= htmlspecialchars($apt['dept_name']) ?></span></td>
                                        <td>
                                            <div class="fw-semibold text-body"><?= formatDate($apt['appointment_date'], 'd M Y') ?></div>
                                            <small class="text-primary"><i class="bi bi-clock me-1"></i><?= htmlspecialchars($apt['time_slot']) ?></small>
                                        </td>
                                        <td>
                                            <?php if ($apt['status'] === 'Confirmed'): ?>
                                                <span class="badge bg-success"><i class="bi bi-check-circle me-1"></i>Confirmed</span>
                                            <?php elseif ($apt['status'] === 'Checked In'): ?>
                                                <span class="badge bg-info text-white"><i class="bi bi-person-check me-1"></i>Checked In</span>
                                            <?php elseif ($apt['status'] === 'Pending'): ?>
                                                <span class="badge bg-warning text-dark"><i class="bi bi-hourglass-split me-1"></i>Pending</span>
                                            <?php elseif ($apt['status'] === 'Completed'): ?>
                                                <span class="badge bg-dark"><i class="bi bi-check2-all me-1"></i>Completed</span>
                                            <?php elseif ($apt['status'] === 'Cancelled'): ?>
                                                <span class="badge bg-danger"><i class="bi bi-x-circle me-1"></i>Cancelled</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary"><?= htmlspecialchars($apt['status']) ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end">
                                            <div class="btn-group btn-group-sm">
                                                <!-- Quick Status Dropdown -->
                                                <button type="button" class="btn btn-outline-secondary dropdown-toggle rounded-pill px-2 me-1" data-bs-toggle="dropdown">
                                                    Status
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-end fs-8 shadow-sm">
                                                    <li><a class="dropdown-item text-success" href="appointments.php?action=set_status&id=<?= $apt['id'] ?>&status=Confirmed"><i class="bi bi-check-circle me-2"></i>Set Confirmed</a></li>
                                                    <li><a class="dropdown-item text-info" href="appointments.php?action=set_status&id=<?= $apt['id'] ?>&status=Checked In"><i class="bi bi-person-check me-2"></i>Set Checked In</a></li>
                                                    <li><a class="dropdown-item text-warning" href="appointments.php?action=set_status&id=<?= $apt['id'] ?>&status=Pending"><i class="bi bi-hourglass me-2"></i>Set Pending</a></li>
                                                    <li><a class="dropdown-item text-dark" href="appointments.php?action=set_status&id=<?= $apt['id'] ?>&status=Completed"><i class="bi bi-check-all me-2"></i>Set Completed</a></li>
                                                    <li><hr class="dropdown-divider"></li>
                                                    <li><a class="dropdown-item text-danger" href="appointments.php?action=set_status&id=<?= $apt['id'] ?>&status=Cancelled" onclick="return confirm('Cancel this appointment?')"><i class="bi bi-x-circle me-2"></i>Cancel Appointment</a></li>
                                                </ul>

                                                <!-- Full Edit Button -->
                                                <button type="button" class="btn btn-outline-primary rounded-pill px-3" onclick="openEditAptModal(<?= htmlspecialchars(json_encode($apt)) ?>)">
                                                    <i class="bi bi-pencil-square me-1"></i> Edit
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        <!-- Edit Appointment Modal -->
        <div class="modal fade" id="editAptModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-dark text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-pencil-square me-2"></i> Edit Appointment & Status</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST" action="">
                        <?= renderCSRFField() ?>
                        <input type="hidden" name="edit_appointment" value="1">
                        <input type="hidden" name="apt_id" id="edit_apt_id">

                        <div class="modal-body p-4">
                            <div class="p-3 bg-body-tertiary rounded-3 mb-3 border">
                                <div class="d-flex justify-content-between">
                                    <strong class="text-primary" id="modal_apt_code">APT-0000</strong>
                                    <span class="badge bg-primary" id="modal_token_num">A-001</span>
                                </div>
                                <div class="fs-7 text-muted mt-1" id="modal_pat_name">Patient Name</div>
                                <div class="fs-8 text-muted" id="modal_doc_name">Doctor Name</div>
                            </div>

                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Appointment Date *</label>
                                    <input type="date" name="appointment_date" id="edit_apt_date" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Time Slot *</label>
                                    <select name="time_slot" id="edit_time_slot" class="form-select" required>
                                        <option value="09:00 AM">09:00 AM</option>
                                        <option value="09:30 AM">09:30 AM</option>
                                        <option value="10:00 AM">10:00 AM</option>
                                        <option value="10:30 AM">10:30 AM</option>
                                        <option value="11:00 AM">11:00 AM</option>
                                        <option value="11:30 AM">11:30 AM</option>
                                        <option value="01:00 PM">01:00 PM</option>
                                        <option value="01:30 PM">01:30 PM</option>
                                        <option value="02:00 PM">02:00 PM</option>
                                        <option value="02:30 PM">02:30 PM</option>
                                        <option value="03:00 PM">03:00 PM</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Queue Token Number *</label>
                                    <input type="text" name="token_number" id="edit_token_number" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Operational Status *</label>
                                    <select name="status" id="edit_status" class="form-select" required>
                                        <option value="Pending">🟡 Pending</option>
                                        <option value="Confirmed">🟢 Confirmed</option>
                                        <option value="Checked In">🔵 Checked In</option>
                                        <option value="In Consultation">🟣 In Consultation</option>
                                        <option value="Completed">⚫ Completed</option>
                                        <option value="Cancelled">🔴 Cancelled</option>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <label class="form-label fw-semibold">Reason / Symptoms Notes</label>
                                    <textarea name="reason" id="edit_reason" class="form-control" rows="2"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-top-0 pt-0">
                            <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary rounded-pill px-4 shadow">Update Appointment</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>

<script>
function openEditAptModal(apt) {
    document.getElementById('edit_apt_id').value = apt.id;
    document.getElementById('modal_apt_code').textContent = apt.appointment_code;
    document.getElementById('modal_token_num').textContent = apt.token_number;
    document.getElementById('modal_pat_name').textContent = `Patient: ${apt.patient_name} (${apt.patient_code})`;
    document.getElementById('modal_doc_name').textContent = `Doctor: ${apt.doctor_name} (${apt.dept_name})`;

    document.getElementById('edit_apt_date').value = apt.appointment_date;
    document.getElementById('edit_time_slot').value = apt.time_slot;
    document.getElementById('edit_token_number').value = apt.token_number;
    document.getElementById('edit_status').value = apt.status;
    document.getElementById('edit_reason').value = apt.reason || '';

    new bootstrap.Modal(document.getElementById('editAptModal')).show();
}
</script>
