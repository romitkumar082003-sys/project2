<?php
// MediCareX - Admin Doctor Management & Credential Roster
// Developed by Romit Kumar

$pageTitle = 'Doctor Management';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

requireRole('Admin');

$user = getCurrentUser();
$pdo = getDBConnection();

$departments = $pdo->query("SELECT * FROM departments WHERE status = 'Active' ORDER BY dept_name ASC")->fetchAll();

$errorMsg = '';

// 1. Add New Doctor
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_doctor'])) {
    validateCSRFOrDie();

    $name = cleanInput($_POST['name'] ?? '');
    $email = cleanInput($_POST['email'] ?? '');
    $phone = cleanInput($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? 'password123';
    $department_id = intval($_POST['department_id'] ?? 0);
    $specialization = cleanInput($_POST['specialization'] ?? '');
    $qualification = cleanInput($_POST['qualification'] ?? '');
    $experience_years = intval($_POST['experience_years'] ?? 5);
    $consultation_fee = floatval($_POST['consultation_fee'] ?? 500.00);
    $availability_days = cleanInput($_POST['availability_days'] ?? 'Mon,Tue,Wed,Thu,Fri');
    $availability_time = cleanInput($_POST['availability_time'] ?? '09:00 AM - 02:00 PM');

    $chk = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
    $chk->execute([$email]);

    if ($chk->fetchColumn() > 0) {
        $errorMsg = "A user account with email {$email} already exists.";
    } else {
        try {
            $pdo->beginTransaction();

            $user_code = generateCode('DOC', 'users', 'user_code');
            $hash = password_hash($password, PASSWORD_DEFAULT);

            $insU = $pdo->prepare("
                INSERT INTO users (user_code, name, email, password, role_id, phone, status) 
                VALUES (?, ?, ?, ?, 2, ?, 'Active')
            ");
            $insU->execute([$user_code, $name, $email, $hash, $phone]);
            $user_id = $pdo->lastInsertId();

            $insD = $pdo->prepare("
                INSERT INTO doctors (user_id, doctor_code, department_id, specialization, qualification, experience_years, consultation_fee, availability_days, availability_time) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $insD->execute([$user_id, $user_code, $department_id, $specialization, $qualification, $experience_years, $consultation_fee, $availability_days, $availability_time]);

            $pdo->commit();

            logAudit($user['id'], $user['name'], 'Admin', 'DOCTOR_ADD', "Registered new doctor {$name} (Code: {$user_code}).");
            setFlash('success', "Doctor account for {$name} created successfully! (Code: {$user_code})");
            header("Location: doctors.php");
            exit();
        } catch (Exception $e) {
            $pdo->rollBack();
            $errorMsg = "Database error: " . $e->getMessage();
        }
    }
}

// 2. Edit Doctor Details
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_doctor'])) {
    validateCSRFOrDie();

    $doc_id = intval($_POST['doc_id'] ?? 0);
    $user_id = intval($_POST['user_id'] ?? 0);
    $name = cleanInput($_POST['name'] ?? '');
    $phone = cleanInput($_POST['phone'] ?? '');
    $department_id = intval($_POST['department_id'] ?? 0);
    $specialization = cleanInput($_POST['specialization'] ?? '');
    $qualification = cleanInput($_POST['qualification'] ?? '');
    $experience_years = intval($_POST['experience_years'] ?? 5);
    $consultation_fee = floatval($_POST['consultation_fee'] ?? 500.00);
    $availability_days = cleanInput($_POST['availability_days'] ?? 'Mon,Tue,Wed,Thu,Fri');
    $availability_time = cleanInput($_POST['availability_time'] ?? '09:00 AM - 02:00 PM');
    $status = cleanInput($_POST['status'] ?? 'Active');

    try {
        $pdo->beginTransaction();

        $updU = $pdo->prepare("UPDATE users SET name = ?, phone = ?, status = ? WHERE id = ?");
        $updU->execute([$name, $phone, $status, $user_id]);

        $updD = $pdo->prepare("
            UPDATE doctors 
            SET department_id = ?, specialization = ?, qualification = ?, experience_years = ?, consultation_fee = ?, availability_days = ?, availability_time = ? 
            WHERE id = ?
        ");
        $updD->execute([$department_id, $specialization, $qualification, $experience_years, $consultation_fee, $availability_days, $availability_time, $doc_id]);

        $pdo->commit();

        logAudit($user['id'], $user['name'], 'Admin', 'DOCTOR_EDIT', "Updated doctor {$name} credentials.");
        setFlash('success', "Doctor '{$name}' profile and credentials updated successfully!");
        header("Location: doctors.php");
        exit();
    } catch (Exception $e) {
        $pdo->rollBack();
        $errorMsg = "Update failed: " . $e->getMessage();
    }
}

// 3. Quick Toggle Doctor Status (Active <-> Inactive)
if (isset($_GET['action']) && $_GET['action'] === 'toggle_status') {
    $user_id = intval($_GET['user_id'] ?? 0);
    $uStmt = $pdo->prepare("SELECT name, status FROM users WHERE id = ?");
    $uStmt->execute([$user_id]);
    $u = $uStmt->fetch();

    if ($u) {
        $newStatus = ($u['status'] === 'Active') ? 'Inactive' : 'Active';
        $pdo->prepare("UPDATE users SET status = ? WHERE id = ?")->execute([$newStatus, $user_id]);
        logAudit($user['id'], $user['name'], 'Admin', 'DOCTOR_STATUS_TOGGLE', "Changed doctor {$u['name']} status to {$newStatus}.");
        setFlash('success', "Dr. {$u['name']} is now marked as {$newStatus}!");
    }
    header("Location: doctors.php");
    exit();
}

// Query Doctors
$filterDept = intval($_GET['dept'] ?? 0);
$filterStatus = cleanInput($_GET['status'] ?? 'All');

$whereArr = [];
$params = [];
if ($filterDept > 0) {
    $whereArr[] = "d.department_id = ?";
    $params[] = $filterDept;
}
if ($filterStatus !== 'All') {
    $whereArr[] = "u.status = ?";
    $params[] = $filterStatus;
}
$whereSql = !empty($whereArr) ? "WHERE " . implode(" AND ", $whereArr) : "";

$doctors = $pdo->prepare("
    SELECT d.*, u.name, u.email, u.phone, u.status, dep.dept_name, dep.icon as dept_icon 
    FROM doctors d 
    JOIN users u ON d.user_id = u.id 
    JOIN departments dep ON d.department_id = dep.id 
    {$whereSql}
    ORDER BY dep.dept_name ASC, d.id ASC
");
$doctors->execute($params);
$docList = $doctors->fetchAll();

$totalDoctors = $pdo->query("SELECT COUNT(*) FROM doctors")->fetchColumn();
$activeDoctors = $pdo->query("SELECT COUNT(*) FROM doctors d JOIN users u ON d.user_id = u.id WHERE u.status = 'Active'")->fetchColumn();
$inactiveDoctors = $pdo->query("SELECT COUNT(*) FROM doctors d JOIN users u ON d.user_id = u.id WHERE u.status != 'Active'")->fetchColumn();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-3 p-md-4">
            <?php displayFlash(); ?>

            <!-- Page Header -->
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-2 mb-4">
                <div>
                    <h3 class="fw-bold mb-1"><i class="bi bi-person-badge-fill text-primary me-2"></i>Doctor Roster & Credentials</h3>
                    <p class="text-muted mb-0 fs-7">Manage hospital doctors, update qualifications, consultation fees, and active clinical status.</p>
                </div>
                <button type="button" class="btn btn-primary rounded-pill px-4 shadow-sm fs-7" data-bs-toggle="modal" data-bs-target="#addDocModal">
                    <i class="bi bi-plus-lg me-1"></i> Register New Doctor
                </button>
            </div>

            <!-- KPI Cards -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-4">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-primary">
                        <small class="text-muted text-uppercase fw-bold fs-8">Total Doctors</small>
                        <h2 class="fw-bold mb-0 text-primary"><?= $totalDoctors ?></h2>
                    </div>
                </div>
                <div class="col-6 col-md-4">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-success">
                        <small class="text-muted text-uppercase fw-bold fs-8">Active Specialists</small>
                        <h2 class="fw-bold mb-0 text-success"><?= $activeDoctors ?></h2>
                    </div>
                </div>
                <div class="col-6 col-md-4">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-secondary">
                        <small class="text-muted text-uppercase fw-bold fs-8">Inactive / On Leave</small>
                        <h2 class="fw-bold mb-0 text-secondary"><?= $inactiveDoctors ?></h2>
                    </div>
                </div>
            </div>

            <!-- Filter Status Tabs -->
            <div class="card card-custom border-0 shadow-sm">
                <div class="card-header bg-body border-0 py-3 d-flex flex-wrap justify-content-between align-items-center gap-2">
                    <div class="d-flex flex-wrap gap-2">
                        <a href="doctors.php?status=All" class="btn btn-sm rounded-pill <?= $filterStatus === 'All' ? 'btn-primary' : 'btn-outline-secondary' ?>">
                            All Doctors (<?= $totalDoctors ?>)
                        </a>
                        <a href="doctors.php?status=Active" class="btn btn-sm rounded-pill <?= $filterStatus === 'Active' ? 'btn-success text-white' : 'btn-outline-success' ?>">
                            <i class="bi bi-check-circle me-1"></i> Active (<?= $activeDoctors ?>)
                        </a>
                        <a href="doctors.php?status=Inactive" class="btn btn-sm rounded-pill <?= $filterStatus === 'Inactive' ? 'btn-secondary text-white' : 'btn-outline-secondary' ?>">
                            <i class="bi bi-dash-circle me-1"></i> Inactive (<?= $inactiveDoctors ?>)
                        </a>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 fs-7">
                        <thead class="table-light text-uppercase">
                            <tr>
                                <th>Doctor Code</th>
                                <th>Doctor Details</th>
                                <th>Department</th>
                                <th>Specialization</th>
                                <th>Qualifications</th>
                                <th>Experience</th>
                                <th>OPD Fee</th>
                                <th>Status</th>
                                <th class="text-end">Actions / Edit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($docList)): ?>
                                <tr>
                                    <td colspan="9" class="text-center py-5 text-muted">
                                        <i class="bi bi-person-x fs-1 d-block mb-2 text-muted"></i>
                                        No doctors found matching selected filters.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($docList as $doc): ?>
                                    <?php $isActive = ($doc['status'] === 'Active'); ?>
                                    <tr>
                                        <td class="fw-bold text-primary"><?= htmlspecialchars($doc['doctor_code']) ?></td>
                                        <td>
                                            <div class="fw-bold text-body"><?= htmlspecialchars($doc['name']) ?></div>
                                            <small class="text-muted"><i class="bi bi-envelope me-1"></i><?= htmlspecialchars($doc['email']) ?> • <i class="bi bi-telephone me-1"></i><?= htmlspecialchars($doc['phone'] ?? 'N/A') ?></small>
                                        </td>
                                        <td><span class="badge bg-primary bg-opacity-10 text-primary border border-primary border-opacity-25"><?= htmlspecialchars($doc['dept_name']) ?></span></td>
                                        <td><?= htmlspecialchars($doc['specialization']) ?></td>
                                        <td><?= htmlspecialchars($doc['qualification']) ?></td>
                                        <td><span class="badge bg-light text-dark border"><?= $doc['experience_years'] ?> Yrs</span></td>
                                        <td class="fw-bold text-success fs-6"><?= formatCurrency($doc['consultation_fee']) ?></td>
                                        <td>
                                            <?php if ($isActive): ?>
                                                <span class="badge bg-success rounded-pill px-3 py-1"><i class="bi bi-check-circle me-1"></i>Active</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary rounded-pill px-3 py-1"><i class="bi bi-dash-circle me-1"></i>Inactive</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end">
                                            <div class="btn-group btn-group-sm">
                                                <!-- Quick Toggle Status -->
                                                <a href="doctors.php?action=toggle_status&user_id=<?= $doc['user_id'] ?>" class="btn btn-sm <?= $isActive ? 'btn-outline-warning' : 'btn-outline-success' ?> rounded-pill px-2 me-1" title="Toggle Active/Inactive">
                                                    <i class="bi <?= $isActive ? 'bi-pause-fill' : 'bi-play-fill' ?>"></i> <?= $isActive ? 'Pause' : 'Activate' ?>
                                                </a>

                                                <!-- Full Edit Button -->
                                                <button type="button" class="btn btn-outline-primary rounded-pill px-3" onclick="openEditDocModal(<?= htmlspecialchars(json_encode($doc)) ?>)">
                                                    <i class="bi bi-pencil-square me-1"></i> Edit
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        <!-- Add Doctor Modal -->
        <div class="modal fade" id="addDocModal" tabindex="-1">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-person-badge-fill me-2"></i> Register Doctor Account</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST" action="">
                        <?= renderCSRFField() ?>
                        <input type="hidden" name="add_doctor" value="1">

                        <div class="modal-body p-4">
                            <?php if ($errorMsg): ?>
                                <div class="alert alert-danger border-0 shadow-sm mb-3"><?= htmlspecialchars($errorMsg) ?></div>
                            <?php endif; ?>

                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Doctor Full Name *</label>
                                    <input type="text" name="name" class="form-control" placeholder="e.g. Dr. Ramesh Mehra" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Email Address (Login) *</label>
                                    <input type="email" name="email" class="form-control" placeholder="e.g. ramesh@medicarex.local" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Phone Number *</label>
                                    <input type="text" name="phone" class="form-control" placeholder="+91 98765 43210" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Initial Password *</label>
                                    <input type="text" name="password" class="form-control" value="password123" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Medical Department *</label>
                                    <select name="department_id" class="form-select" required>
                                        <?php foreach ($departments as $dept): ?>
                                            <option value="<?= $dept['id'] ?>"><?= htmlspecialchars($dept['dept_name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Clinical Specialization *</label>
                                    <input type="text" name="specialization" class="form-control" placeholder="e.g. Pediatric Cardiology" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Qualifications & Degrees *</label>
                                    <input type="text" name="qualification" class="form-control" placeholder="e.g. MBBS, MD, DM" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Experience (Yrs)</label>
                                    <input type="number" name="experience_years" class="form-control" value="10" min="0">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Consultation Fee (₹) *</label>
                                    <input type="number" step="0.01" name="consultation_fee" class="form-control" value="600.00" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">OPD Working Days</label>
                                    <input type="text" name="availability_days" class="form-control" value="Mon,Tue,Wed,Thu,Fri">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">OPD Consultation Hours</label>
                                    <input type="text" name="availability_time" class="form-control" value="09:00 AM - 02:00 PM">
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-top-0 pt-0">
                            <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary rounded-pill px-4 shadow">Create Doctor Account</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Edit Doctor Modal -->
        <div class="modal fade" id="editDocModal" tabindex="-1">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-dark text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-pencil-square me-2"></i> Edit Doctor Credentials & Details</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST" action="">
                        <?= renderCSRFField() ?>
                        <input type="hidden" name="edit_doctor" value="1">
                        <input type="hidden" name="doc_id" id="edit_doc_id">
                        <input type="hidden" name="user_id" id="edit_user_id">

                        <div class="modal-body p-4">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Doctor Full Name *</label>
                                    <input type="text" name="name" id="edit_name" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Phone Number *</label>
                                    <input type="text" name="phone" id="edit_phone" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Medical Department *</label>
                                    <select name="department_id" id="edit_department_id" class="form-select" required>
                                        <?php foreach ($departments as $dept): ?>
                                            <option value="<?= $dept['id'] ?>"><?= htmlspecialchars($dept['dept_name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Clinical Specialization *</label>
                                    <input type="text" name="specialization" id="edit_specialization" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Degrees & Qualifications *</label>
                                    <input type="text" name="qualification" id="edit_qualification" class="form-control" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Experience (Yrs)</label>
                                    <input type="number" name="experience_years" id="edit_experience_years" class="form-control" min="0" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Consultation Fee (₹) *</label>
                                    <input type="number" step="0.01" name="consultation_fee" id="edit_consultation_fee" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Working Days</label>
                                    <input type="text" name="availability_days" id="edit_availability_days" class="form-control">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">OPD Timings</label>
                                    <input type="text" name="availability_time" id="edit_availability_time" class="form-control">
                                </div>
                                <div class="col-md-12">
                                    <label class="form-label fw-semibold">Operational Account Status *</label>
                                    <select name="status" id="edit_status" class="form-select" required>
                                        <option value="Active">🟢 Active (Available for OPD & Scheduling)</option>
                                        <option value="Inactive">🔴 Inactive (On Leave / Suspended)</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-top-0 pt-0">
                            <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary rounded-pill px-4 shadow">Update Doctor Details</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>

<script>
function openEditDocModal(doc) {
    document.getElementById('edit_doc_id').value = doc.id;
    document.getElementById('edit_user_id').value = doc.user_id;
    document.getElementById('edit_name').value = doc.name;
    document.getElementById('edit_phone').value = doc.phone || '';
    document.getElementById('edit_department_id').value = doc.department_id;
    document.getElementById('edit_specialization').value = doc.specialization;
    document.getElementById('edit_qualification').value = doc.qualification;
    document.getElementById('edit_experience_years').value = doc.experience_years || 5;
    document.getElementById('edit_consultation_fee').value = parseFloat(doc.consultation_fee).toFixed(2);
    document.getElementById('edit_availability_days').value = doc.availability_days || 'Mon,Tue,Wed,Thu,Fri';
    document.getElementById('edit_availability_time').value = doc.availability_time || '09:00 AM - 02:00 PM';
    document.getElementById('edit_status').value = doc.status || 'Active';

    new bootstrap.Modal(document.getElementById('editDocModal')).show();
}
</script>
