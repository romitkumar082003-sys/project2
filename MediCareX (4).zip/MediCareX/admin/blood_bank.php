<?php
// MediCareX - Blood Bank Inventory & Donor Center
// Developed by Romit Kumar

$pageTitle = 'Blood Bank Inventory';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

requireRole('Admin');

$user = getCurrentUser();
$pdo = getDBConnection();

// 1. Edit Blood Group Units, Availability Status & Thresholds
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_blood'])) {
    validateCSRFOrDie();

    $id = intval($_POST['blood_id'] ?? 0);
    $status_choice = cleanInput($_POST['status_choice'] ?? '');
    $total_units = intval($_POST['total_units'] ?? 0);
    $reserved_units = intval($_POST['reserved_units'] ?? 0);
    $min_units_alert = intval($_POST['min_units_alert'] ?? 5);

    // If explicitly marked as unavailable/out of stock
    if ($status_choice === 'out') {
        $total_units = 0;
    } elseif ($status_choice === 'available' && $total_units <= 0) {
        $total_units = max(15, $min_units_alert + 5);
    } elseif ($status_choice === 'low' && ($total_units <= 0 || $total_units > $min_units_alert)) {
        $total_units = min(3, $min_units_alert);
    }

    $upd = $pdo->prepare("UPDATE blood_inventory SET total_units = ?, reserved_units = ?, min_units_alert = ? WHERE id = ?");
    $upd->execute([$total_units, $reserved_units, $min_units_alert, $id]);

    $statusLabel = ($total_units <= 0) ? 'NOT AVAILABLE (Out of Stock)' : (($total_units <= $min_units_alert) ? 'LOW STOCK' : 'AVAILABLE');

    logAudit($user['id'], $user['name'], 'Admin', 'BLOOD_STOCK_UPDATE', "Updated blood inventory ID {$id}: Status {$statusLabel}, Units {$total_units}.");
    setFlash('success', "Blood group status updated to '{$statusLabel}' ({$total_units} units)!");
    header("Location: blood_bank.php");
    exit();
}

// 2. Quick Actions: Toggle Status (Available / Not Available / Low) or Inc / Dec
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id'] ?? 0);
    $action = cleanInput($_GET['action']);
    
    $cur = $pdo->prepare("SELECT total_units, blood_group, min_units_alert FROM blood_inventory WHERE id = ?");
    $cur->execute([$id]);
    $item = $cur->fetch();

    if ($item) {
        $bloodGroup = $item['blood_group'];
        $minAlert = $item['min_units_alert'] ?: 5;

        if ($action === 'set_unavailable') {
            // Mark as Not Available / Out of Stock
            $pdo->prepare("UPDATE blood_inventory SET total_units = 0 WHERE id = ?")->execute([$id]);
            logAudit($user['id'], $user['name'], 'Admin', 'BLOOD_STOCK_UPDATE', "Marked blood group {$bloodGroup} as NOT AVAILABLE (0 units).");
            setFlash('danger', "Blood group {$bloodGroup} is now marked as NOT AVAILABLE (Out of Stock).");
        } elseif ($action === 'set_available') {
            // Mark as Available with standard healthy supply (e.g. 15 units)
            $newUnits = max(15, $minAlert + 5);
            $pdo->prepare("UPDATE blood_inventory SET total_units = ? WHERE id = ?")->execute([$newUnits, $id]);
            logAudit($user['id'], $user['name'], 'Admin', 'BLOOD_STOCK_UPDATE', "Marked blood group {$bloodGroup} as AVAILABLE ({$newUnits} units).");
            setFlash('success', "Blood group {$bloodGroup} is now marked as AVAILABLE ({$newUnits} units in stock).");
        } elseif ($action === 'set_low') {
            // Mark as Low stock
            $newUnits = min(3, $minAlert);
            $pdo->prepare("UPDATE blood_inventory SET total_units = ? WHERE id = ?")->execute([$newUnits, $id]);
            setFlash('warning', "Blood group {$bloodGroup} is now marked as LOW STOCK ({$newUnits} units).");
        } elseif ($action === 'inc') {
            $newUnits = $item['total_units'] + 1;
            $pdo->prepare("UPDATE blood_inventory SET total_units = ? WHERE id = ?")->execute([$newUnits, $id]);
            setFlash('success', "+1 unit added to {$bloodGroup} (Total: {$newUnits})");
        } elseif ($action === 'dec') {
            $newUnits = max(0, $item['total_units'] - 1);
            $pdo->prepare("UPDATE blood_inventory SET total_units = ? WHERE id = ?")->execute([$newUnits, $id]);
            $msgType = ($newUnits === 0) ? 'danger' : 'warning';
            setFlash($msgType, "-1 unit removed from {$bloodGroup} (Total: {$newUnits})");
        }
    }
    header("Location: blood_bank.php");
    exit();
}

$bloodList = $pdo->query("SELECT * FROM blood_inventory ORDER BY blood_group ASC")->fetchAll();

$filter = cleanInput($_GET['filter'] ?? 'all');
$filteredList = [];
$totalUnitsSum = 0;
$availableCount = 0;
$lowCount = 0;
$outCount = 0;

foreach ($bloodList as $b) {
    $totalUnitsSum += $b['total_units'];
    $isOut = ($b['total_units'] <= 0);
    $isLow = ($b['total_units'] > 0 && $b['total_units'] <= $b['min_units_alert']);
    $isAvail = ($b['total_units'] > $b['min_units_alert']);

    if ($isOut) $outCount++;
    elseif ($isLow) $lowCount++;
    else $availableCount++;

    if ($filter === 'available' && $isAvail) $filteredList[] = $b;
    elseif ($filter === 'low' && $isLow) $filteredList[] = $b;
    elseif ($filter === 'out' && $isOut) $filteredList[] = $b;
    elseif ($filter === 'all') $filteredList[] = $b;
}

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-3 p-md-4">
            <?php displayFlash(); ?>

            <!-- Page Header -->
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-2 mb-4">
                <div>
                    <h3 class="fw-bold mb-1"><i class="bi bi-droplet-fill text-danger me-2"></i>Blood Bank Inventory Center</h3>
                    <p class="text-muted mb-0 fs-7">Real-time blood stock tracking, status management (Available, Low Stock, Not Available / Out of Stock), and instant updates.</p>
                </div>
            </div>

            <!-- KPI Metric Cards -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-primary">
                        <small class="text-muted text-uppercase fw-bold fs-8">Total Blood Units</small>
                        <h2 class="fw-bold mb-0 text-primary"><?= $totalUnitsSum ?> <span class="fs-7 text-muted fw-normal">Units</span></h2>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-success">
                        <small class="text-muted text-uppercase fw-bold fs-8">Available Groups</small>
                        <h2 class="fw-bold mb-0 text-success"><?= $availableCount ?> <span class="fs-7 text-muted fw-normal">In Stock</span></h2>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-warning">
                        <small class="text-muted text-uppercase fw-bold fs-8">Low Stock Alerts</small>
                        <h2 class="fw-bold mb-0 text-warning"><?= $lowCount ?> <span class="fs-7 text-muted fw-normal">Critical</span></h2>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-danger">
                        <small class="text-muted text-uppercase fw-bold fs-8">Not Available</small>
                        <h2 class="fw-bold mb-0 text-danger"><?= $outCount ?> <span class="fs-7 text-muted fw-normal">Out of Stock</span></h2>
                    </div>
                </div>
            </div>

            <!-- Filter Status Tabs -->
            <div class="d-flex flex-wrap gap-2 mb-4">
                <a href="blood_bank.php?filter=all" class="btn btn-sm rounded-pill <?= $filter === 'all' ? 'btn-primary shadow-sm' : 'btn-outline-secondary' ?>">
                    All Blood Groups (<?= count($bloodList) ?>)
                </a>
                <a href="blood_bank.php?filter=available" class="btn btn-sm rounded-pill <?= $filter === 'available' ? 'btn-success text-white shadow-sm' : 'btn-outline-success' ?>">
                    <i class="bi bi-check-circle me-1"></i> Available (<?= $availableCount ?>)
                </a>
                <a href="blood_bank.php?filter=low" class="btn btn-sm rounded-pill <?= $filter === 'low' ? 'btn-warning text-dark shadow-sm' : 'btn-outline-warning' ?>">
                    <i class="bi bi-exclamation-triangle me-1"></i> Low Stock (<?= $lowCount ?>)
                </a>
                <a href="blood_bank.php?filter=out" class="btn btn-sm rounded-pill <?= $filter === 'out' ? 'btn-danger text-white shadow-sm' : 'btn-outline-danger' ?>">
                    <i class="bi bi-x-circle me-1"></i> Not Available / Out of Stock (<?= $outCount ?>)
                </a>
            </div>

            <!-- Blood Bank Cards Grid -->
            <div class="row g-4">
                <?php if (empty($filteredList)): ?>
                    <div class="col-12 text-center py-5 text-muted">
                        <i class="bi bi-droplet-half fs-1 d-block mb-2 text-muted"></i>
                        No blood groups found under selected status.
                    </div>
                <?php else: ?>
                    <?php foreach ($filteredList as $b): ?>
                        <?php
                        $isOut = ($b['total_units'] <= 0);
                        $isLow = ($b['total_units'] > 0 && $b['total_units'] <= $b['min_units_alert']);
                        
                        $cardBorder = $isOut ? 'border-danger' : ($isLow ? 'border-warning' : 'border-success');
                        $badgeClass = $isOut ? 'bg-danger' : ($isLow ? 'bg-warning text-dark' : 'bg-success');
                        $badgeIcon = $isOut ? 'bi-x-circle' : ($isLow ? 'bi-exclamation-triangle' : 'bi-check-circle');
                        $badgeText = $isOut ? 'NOT AVAILABLE' : ($isLow ? 'LOW STOCK' : 'AVAILABLE');
                        $usableUnits = max(0, $b['total_units'] - $b['reserved_units']);
                        
                        $curStatus = $isOut ? 'out' : ($isLow ? 'low' : 'available');
                        ?>
                        <div class="col-md-6 col-lg-3">
                            <div class="card card-custom blood-card p-4 h-100 border-0 shadow-sm border-top border-4 <?= $cardBorder ?> position-relative">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <div>
                                        <h2 class="fw-extrabold text-danger mb-0 d-flex align-items-center">
                                            <i class="bi bi-droplet-fill me-2 fs-3"></i><?= htmlspecialchars($b['blood_group']) ?>
                                        </h2>
                                        <small class="text-muted fs-8">Rh Factor Blood Group</small>
                                    </div>
                                    <span class="badge <?= $badgeClass ?> rounded-pill px-3 py-1 fs-8 shadow-sm">
                                        <i class="bi <?= $badgeIcon ?> me-1"></i><?= $badgeText ?>
                                    </span>
                                </div>

                                <div class="p-3 bg-body-tertiary rounded-3 mb-3 border">
                                    <div class="d-flex justify-content-between align-items-baseline mb-1">
                                        <span class="fs-7 text-muted">Total In Bank:</span>
                                        <span class="fs-4 fw-bold <?= $isOut ? 'text-danger' : 'text-dark' ?>">
                                            <?= $b['total_units'] ?> <span class="fs-8 fw-normal text-muted">units</span>
                                        </span>
                                    </div>
                                    <div class="d-flex justify-content-between fs-8 text-muted mb-1">
                                        <span>Reserved Units:</span>
                                        <span class="fw-semibold text-warning"><?= $b['reserved_units'] ?> units</span>
                                    </div>
                                    <div class="d-flex justify-content-between fs-8 text-muted">
                                        <span>Ready to Dispense:</span>
                                        <span class="fw-bold <?= $usableUnits > 0 ? 'text-success' : 'text-danger' ?>"><?= $usableUnits ?> units</span>
                                    </div>
                                </div>

                                <!-- Quick 1-Click Status Pill Strip (No Overlap, 100% Instant) -->
                                <div class="mb-3">
                                    <label class="form-label fs-8 text-muted fw-bold text-uppercase mb-1 d-block">Quick Status</label>
                                    <div class="btn-group w-100 p-1 bg-body-secondary rounded-pill border">
                                        <a href="blood_bank.php?action=set_available&id=<?= $b['id'] ?>" 
                                           class="btn btn-sm rounded-pill py-1 fs-8 fw-semibold <?= (!$isOut && !$isLow) ? 'btn-success text-white shadow-sm' : 'btn-light text-muted border-0' ?>" 
                                           title="Set Available (15 Units)">
                                            <i class="bi bi-check-circle me-1"></i>Avail
                                        </a>
                                        <a href="blood_bank.php?action=set_low&id=<?= $b['id'] ?>" 
                                           class="btn btn-sm rounded-pill py-1 fs-8 fw-semibold <?= $isLow ? 'btn-warning text-dark shadow-sm' : 'btn-light text-muted border-0' ?>" 
                                           title="Set Low Stock (3 Units)">
                                            <i class="bi bi-exclamation-triangle me-1"></i>Low
                                        </a>
                                        <a href="blood_bank.php?action=set_unavailable&id=<?= $b['id'] ?>" 
                                           class="btn btn-sm rounded-pill py-1 fs-8 fw-semibold <?= $isOut ? 'btn-danger text-white shadow-sm' : 'btn-light text-muted border-0' ?>" 
                                           title="Set Not Available (0 Units)">
                                            <i class="bi bi-slash-circle me-1"></i>Out
                                        </a>
                                    </div>
                                </div>

                                <div class="d-flex justify-content-between align-items-center mt-auto pt-2 border-top">
                                    <!-- Quick +/- buttons -->
                                    <div class="btn-group btn-group-sm">
                                        <a href="blood_bank.php?action=dec&id=<?= $b['id'] ?>" class="btn btn-outline-danger px-2" title="Deduct 1 Unit"><i class="bi bi-dash"></i></a>
                                        <a href="blood_bank.php?action=inc&id=<?= $b['id'] ?>" class="btn btn-outline-success px-2" title="Add 1 Unit"><i class="bi bi-plus"></i></a>
                                    </div>

                                    <!-- Quick Dropup Actions (Opens UPWARDS so it NEVER overlaps below cards) -->
                                    <div class="dropup position-relative">
                                        <button class="btn btn-sm btn-light border dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" data-bs-display="static">
                                            <i class="bi bi-gear me-1"></i> Action
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end shadow-lg border p-2" style="min-width: 220px; z-index: 1060;">
                                            <li><h6 class="dropdown-header text-uppercase fs-8 fw-bold">Set Availability</h6></li>
                                            <li><a class="dropdown-item rounded-2 py-1 text-success fw-semibold" href="blood_bank.php?action=set_available&id=<?= $b['id'] ?>"><i class="bi bi-check-circle-fill me-2"></i>Available (15 Units)</a></li>
                                            <li><a class="dropdown-item rounded-2 py-1 text-warning fw-semibold" href="blood_bank.php?action=set_low&id=<?= $b['id'] ?>"><i class="bi bi-exclamation-triangle-fill me-2"></i>Low Stock (3 Units)</a></li>
                                            <li><a class="dropdown-item rounded-2 py-1 text-danger fw-semibold" href="blood_bank.php?action=set_unavailable&id=<?= $b['id'] ?>"><i class="bi bi-slash-circle-fill me-2"></i>Not Available (0 Units)</a></li>
                                            <li><hr class="dropdown-divider"></li>
                                            <li>
                                                <a class="dropdown-item rounded-2 py-1 text-primary fw-semibold" href="javascript:void(0)" onclick="openEditBloodModal(<?= htmlspecialchars(json_encode(array_merge($b, ['cur_status' => $curStatus]))) ?>)">
                                                    <i class="bi bi-pencil-square me-2"></i>Full Edit Details
                                                </a>
                                            </li>
                                        </ul>
                                    </div>

                                    <!-- Edit Modal Trigger -->
                                    <button type="button" class="btn btn-sm btn-primary rounded-pill px-3" onclick="openEditBloodModal(<?= htmlspecialchars(json_encode(array_merge($b, ['cur_status' => $curStatus]))) ?>)">
                                        <i class="bi bi-pencil-square me-1"></i> Edit
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

        </div>

        <!-- Edit Blood Stock & Status Modal -->
        <div class="modal fade" id="editBloodModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-dark text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-pencil-square me-2"></i> Edit Blood Stock & Availability</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST" action="">
                        <?= renderCSRFField() ?>
                        <input type="hidden" name="edit_blood" value="1">
                        <input type="hidden" name="blood_id" id="edit_blood_id">

                        <div class="modal-body p-4">
                            <div class="p-3 bg-danger bg-opacity-10 text-danger rounded-3 mb-3 border border-danger border-opacity-25 text-center">
                                <h3 class="fw-extrabold mb-0" id="modal_blood_group">O+</h3>
                                <small class="text-muted">Rh Factor Blood Group Management</small>
                            </div>

                            <!-- Availability Status Selector -->
                            <div class="mb-3">
                                <label class="form-label fw-bold">Availability Status *</label>
                                <select name="status_choice" id="edit_status_choice" class="form-select fw-semibold" onchange="handleStatusChange(this.value)">
                                    <option value="available" class="text-success">🟢 Available (In Stock & Ready to Dispense)</option>
                                    <option value="low" class="text-warning">🟡 Low Stock (Critical Emergency Level)</option>
                                    <option value="out" class="text-danger">🔴 Not Available / Out of Stock (0 Units)</option>
                                </select>
                                <small class="text-muted fs-8">Selecting 'Not Available' will automatically set total units to 0</small>
                            </div>

                            <div class="mb-3" id="units_container">
                                <label class="form-label fw-semibold">Total Stock Units in Bank *</label>
                                <input type="number" name="total_units" id="edit_total_units" class="form-control" min="0" required oninput="handleUnitsInput(this.value)">
                                <small class="text-muted fs-8" id="units_help">Enter 0 to mark Out of Stock / Not Available</small>
                            </div>

                            <div class="row g-3">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">Reserved Units *</label>
                                    <input type="number" name="reserved_units" id="edit_reserved_units" class="form-control" min="0" required>
                                    <small class="text-muted fs-8">Locked for scheduled procedures</small>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-semibold">Low Stock Alert Level *</label>
                                    <input type="number" name="min_units_alert" id="edit_min_alert" class="form-control" min="1" required>
                                    <small class="text-muted fs-8">Triggers Low Stock status below this</small>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-top-0 pt-0">
                            <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-danger rounded-pill px-4 shadow">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>

<style>
.blood-card {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    position: relative;
}
.blood-card:hover {
    z-index: 20;
}
.blood-card:focus-within, .blood-card.active-dropdown {
    z-index: 1055 !important;
}
.dropup .dropdown-menu {
    margin-bottom: 8px !important;
}
</style>

<script>
// Prevent any overlap by elevating card z-index when dropup is opened
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.dropup, .dropdown').forEach(dd => {
        dd.addEventListener('show.bs.dropdown', function () {
            const card = this.closest('.card');
            if (card) {
                card.classList.add('active-dropdown');
                card.style.zIndex = '1055';
            }
        });
        dd.addEventListener('hidden.bs.dropdown', function () {
            const card = this.closest('.card');
            if (card) {
                card.classList.remove('active-dropdown');
                card.style.zIndex = '';
            }
        });
    });
});

function openEditBloodModal(blood) {
    document.getElementById('edit_blood_id').value = blood.id;
    document.getElementById('modal_blood_group').textContent = blood.blood_group;
    document.getElementById('edit_total_units').value = blood.total_units;
    document.getElementById('edit_reserved_units').value = blood.reserved_units;
    document.getElementById('edit_min_alert').value = blood.min_units_alert;

    const statusSelect = document.getElementById('edit_status_choice');
    if (blood.cur_status) {
        statusSelect.value = blood.cur_status;
    } else {
        if (blood.total_units <= 0) {
            statusSelect.value = 'out';
        } else if (blood.total_units <= blood.min_units_alert) {
            statusSelect.value = 'low';
        } else {
            statusSelect.value = 'available';
        }
    }

    new bootstrap.Modal(document.getElementById('editBloodModal')).show();
}

function handleStatusChange(status) {
    const unitsInput = document.getElementById('edit_total_units');
    const minAlert = parseInt(document.getElementById('edit_min_alert').value) || 5;

    if (status === 'out') {
        unitsInput.value = 0;
        unitsInput.classList.add('is-invalid');
        unitsInput.classList.remove('is-valid');
    } else if (status === 'available') {
        if (parseInt(unitsInput.value) <= 0) {
            unitsInput.value = Math.max(15, minAlert + 5);
        }
        unitsInput.classList.remove('is-invalid');
        unitsInput.classList.add('is-valid');
    } else if (status === 'low') {
        unitsInput.value = Math.min(3, minAlert);
        unitsInput.classList.remove('is-invalid', 'is-valid');
    }
}

function handleUnitsInput(val) {
    const num = parseInt(val) || 0;
    const minAlert = parseInt(document.getElementById('edit_min_alert').value) || 5;
    const statusSelect = document.getElementById('edit_status_choice');

    if (num <= 0) {
        statusSelect.value = 'out';
    } else if (num <= minAlert) {
        statusSelect.value = 'low';
    } else {
        statusSelect.value = 'available';
    }
}
</script>

