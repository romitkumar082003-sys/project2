<?php
// MediCareX - SQLite Zero-Config Database Initializer
// Developed by Romit Kumar

$dbFile = __DIR__ . '/medicarex.sqlite';

try {
    $pdo = new PDO('sqlite:' . $dbFile);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 1. Roles
    $pdo->exec("CREATE TABLE IF NOT EXISTS roles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        role_name TEXT UNIQUE NOT NULL
    )");
    $pdo->exec("INSERT OR IGNORE INTO roles (id, role_name) VALUES 
        (1, 'Admin'), (2, 'Doctor'), (3, 'Nurse'), (4, 'Receptionist'), 
        (5, 'Pharmacist'), (6, 'Lab Technician'), (7, 'Patient')");

    // 2. Users
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role_id INTEGER NOT NULL,
        phone TEXT,
        avatar TEXT DEFAULT 'default_avatar.png',
        status TEXT DEFAULT 'Active',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    $hash = password_hash('password123', PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT OR IGNORE INTO users (id, user_code, name, email, password, role_id, phone, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'Active')");
    $stmt->execute([1, 'ADM-1001', 'System Administrator', 'admin@medicarex.local', $hash, 1, '+91 9876543210']);
    $stmt->execute([2, 'DOC-2001', 'Dr. Ankit Sharma', 'doctor@medicarex.local', $hash, 2, '+91 9876543211']);
    $stmt->execute([3, 'DOC-2002', 'Dr. Priya Singh', 'doctor2@medicarex.local', $hash, 2, '+91 9876543212']);
    $stmt->execute([4, 'NUR-3001', 'Nurse Sunita Verma', 'nurse@medicarex.local', $hash, 3, '+91 9876543213']);
    $stmt->execute([5, 'REC-4001', 'Rahul Verma (Reception)', 'reception@medicarex.local', $hash, 4, '+91 9876543214']);
    $stmt->execute([6, 'PHA-5001', 'Vikram Patel (Pharmacy)', 'pharmacy@medicarex.local', $hash, 5, '+91 9876543215']);
    $stmt->execute([7, 'LAB-6001', 'Suresh Kumar (Lab)', 'lab@medicarex.local', $hash, 6, '+91 9876543216']);
    $stmt->execute([8, 'PAT-7001', 'Ramesh Gupta', 'patient@medicarex.local', $hash, 7, '+91 9876543217']);
    $stmt->execute([9, 'PAT-7002', 'Anita Roy', 'anita.roy@example.com', $hash, 7, '+91 9876543218']);
    $stmt->execute([10, 'DOC-2003', 'Dr. Rajesh Verma', 'rajesh.ortho@medicarex.local', $hash, 2, '+91 9876543220']);
    $stmt->execute([11, 'DOC-2004', 'Dr. Sneha Kulkarni', 'sneha.pedia@medicarex.local', $hash, 2, '+91 9876543221']);
    $stmt->execute([12, 'DOC-2005', 'Dr. Rohan Mehta', 'rohan.derma@medicarex.local', $hash, 2, '+91 9876543222']);
    $stmt->execute([13, 'DOC-2006', 'Dr. Alok Nath', 'alok.medicine@medicarex.local', $hash, 2, '+91 9876543223']);
    $stmt->execute([14, 'DOC-2007', 'Dr. Sunidhi Sen', 'sunidhi.gynae@medicarex.local', $hash, 2, '+91 9876543224']);
    $stmt->execute([15, 'DOC-2008', 'Dr. Manish Tiwari', 'manish.ent@medicarex.local', $hash, 2, '+91 9876543225']);
    $stmt->execute([16, 'DOC-2009', 'Dr. Kavita Nair', 'kavita.dental@medicarex.local', $hash, 2, '+91 9876543226']);
    $stmt->execute([17, 'DOC-2010', 'Dr. Deepak Joshi', 'deepak.doc@medicarex.local', $hash, 2, '+91 9876543227']);
    $stmt->execute([18, 'DOC-2011', 'Dr. Neha Kapoor', 'neha.pedia@medicarex.local', $hash, 2, '+91 9876543228']);

    // 3. Departments
    $pdo->exec("CREATE TABLE IF NOT EXISTS departments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        dept_name TEXT NOT NULL,
        description TEXT,
        icon TEXT DEFAULT 'bi-hospital',
        status TEXT DEFAULT 'Active'
    )");
    $pdo->exec("INSERT OR IGNORE INTO departments (id, dept_name, description, icon) VALUES 
        (1, 'Cardiology', 'Heart, blood vessels, and cardiovascular disorders.', 'bi-heart-pulse-fill'),
        (2, 'Neurology', 'Brain, spinal cord, and nerve treatments.', 'bi-cpu-fill'),
        (3, 'Orthopedics', 'Bones, joints, muscles, and ligament care.', 'bi-person-arms-up'),
        (4, 'Pediatrics', 'Child healthcare, vaccinations, and infant wellness.', 'bi-emoji-smile-fill'),
        (5, 'Dermatology', 'Skin, hair, and cosmetic medical procedures.', 'bi-sun-fill'),
        (6, 'General Medicine', 'Comprehensive primary care and diagnosis.', 'bi-bandaid-fill'),
        (7, 'Gynecology', 'Women reproductive health and maternity care.', 'bi-gender-female'),
        (8, 'ENT', 'Ear, Nose, Throat diagnosis and surgeries.', 'bi-ear-fill'),
        (9, 'Dental', 'Teeth, gums, and oral healthcare.', 'bi-capsule')");

    // 4. Patients
    $pdo->exec("CREATE TABLE IF NOT EXISTS patients (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        patient_code TEXT UNIQUE NOT NULL,
        dob TEXT,
        gender TEXT NOT NULL,
        blood_group TEXT DEFAULT 'O+',
        address TEXT,
        emergency_contact TEXT,
        medical_history TEXT
    )");
    $pdo->exec("INSERT OR IGNORE INTO patients (id, user_id, patient_code, dob, gender, blood_group, address, emergency_contact, medical_history) VALUES 
        (1, 8, 'PAT-7001', '1988-05-14', 'Male', 'B+', '123 MG Road, New Delhi', '+91 9988776655', 'Mild hypertension, penicillin allergy.'),
        (2, 9, 'PAT-7002', '1993-11-20', 'Female', 'O+', '45 Park Street, Kolkata', '+91 9876512345', 'No major prior chronic conditions.')");

    // 5. Doctors
    $pdo->exec("CREATE TABLE IF NOT EXISTS doctors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        doctor_code TEXT UNIQUE NOT NULL,
        department_id INTEGER NOT NULL,
        specialization TEXT NOT NULL,
        qualification TEXT NOT NULL,
        experience_years INTEGER DEFAULT 10,
        consultation_fee REAL DEFAULT 500.00,
        availability_days TEXT DEFAULT 'Mon,Tue,Wed,Thu,Fri',
        availability_time TEXT DEFAULT '09:00 AM - 02:00 PM'
    )");
    $pdo->exec("INSERT OR IGNORE INTO doctors (id, user_id, doctor_code, department_id, specialization, qualification, experience_years, consultation_fee, availability_days, availability_time) VALUES 
        (1, 2, 'DOC-2001', 1, 'Interventional Cardiology', 'MBBS, MD, DM (Cardiology)', 12, 800.00, 'Mon,Tue,Wed,Thu,Fri', '09:00 AM - 02:00 PM'),
        (2, 3, 'DOC-2002', 2, 'Clinical Neurology & Stroke Care', 'MBBS, MD, DNB (Neurology)', 9, 750.00, 'Mon,Wed,Fri', '10:00 AM - 03:00 PM'),
        (3, 10, 'DOC-2003', 3, 'Joint Replacement & Trauma Surgery', 'MBBS, MS (Orthopedics)', 15, 700.00, 'Mon,Tue,Thu,Sat', '09:00 AM - 01:00 PM'),
        (4, 11, 'DOC-2004', 4, 'Consultant Pediatrician & Neonatologist', 'MBBS, MD (Pediatrics), DCH', 8, 600.00, 'Mon,Tue,Wed,Thu,Fri,Sat', '09:30 AM - 02:30 PM'),
        (5, 12, 'DOC-2005', 5, 'Clinical Dermatology & Cosmetology', 'MBBS, MD (DVL)', 10, 650.00, 'Tue,Wed,Fri,Sat', '10:00 AM - 04:00 PM'),
        (6, 13, 'DOC-2006', 6, 'Internal Medicine & Critical Care', 'MBBS, MD (General Medicine)', 14, 500.00, 'Mon,Tue,Wed,Thu,Fri,Sat', '08:30 AM - 01:30 PM'),
        (7, 14, 'DOC-2007', 7, 'Obstetrics & High-Risk Pregnancy', 'MBBS, MS (OBG), DGO', 11, 700.00, 'Mon,Wed,Fri,Sat', '09:00 AM - 02:00 PM'),
        (8, 15, 'DOC-2008', 8, 'ENT & Head Neck Surgery', 'MBBS, MS (ENT)', 10, 600.00, 'Mon,Tue,Thu,Sat', '10:00 AM - 03:00 PM'),
        (9, 16, 'DOC-2009', 9, 'Dental Surgery & Implantology', 'BDS, MDS (Oral & Maxillofacial)', 7, 500.00, 'Mon,Wed,Thu,Fri,Sat', '09:30 AM - 02:30 PM'),
        (10, 17, 'DOC-2010', 6, 'Family Medicine & Diabetes Care', 'MBBS, Fellowship in Diabetology', 8, 450.00, 'Mon,Tue,Wed,Thu,Fri', '01:00 PM - 06:00 PM'),
        (11, 18, 'DOC-2011', 4, 'Pediatric Care & Child Nutrition', 'MBBS, DNB (Pediatrics)', 6, 550.00, 'Tue,Wed,Thu,Fri,Sat', '02:00 PM - 06:00 PM')");

    // 6. Appointments
    $pdo->exec("CREATE TABLE IF NOT EXISTS appointments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        appointment_code TEXT UNIQUE NOT NULL,
        patient_id INTEGER NOT NULL,
        doctor_id INTEGER NOT NULL,
        department_id INTEGER NOT NULL,
        appointment_date TEXT NOT NULL,
        time_slot TEXT NOT NULL,
        token_number TEXT NOT NULL,
        reason TEXT,
        status TEXT DEFAULT 'Pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    $today = date('Y-m-d');
    $pdo->exec("INSERT OR IGNORE INTO appointments (id, appointment_code, patient_id, doctor_id, department_id, appointment_date, time_slot, token_number, reason, status) VALUES 
        (1, 'APT-1001', 1, 1, 1, '{$today}', '09:30 AM', 'A-001', 'Routine chest discomfort evaluation.', 'Checked In'),
        (2, 'APT-1002', 2, 2, 2, '{$today}', '10:15 AM', 'B-001', 'Migraine headache and dizziness.', 'Pending')");

    // 7. Consultations
    $pdo->exec("CREATE TABLE IF NOT EXISTS consultations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        appointment_id INTEGER NOT NULL,
        patient_id INTEGER NOT NULL,
        doctor_id INTEGER NOT NULL,
        symptoms TEXT NOT NULL,
        diagnosis TEXT NOT NULL,
        bp TEXT DEFAULT '120/80',
        temp TEXT DEFAULT '98.6 F',
        weight TEXT DEFAULT '70 kg',
        pulse TEXT DEFAULT '72 bpm',
        notes TEXT,
        follow_up_date TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    $pdo->exec("INSERT OR IGNORE INTO consultations (id, appointment_id, patient_id, doctor_id, symptoms, diagnosis, bp, temp, weight, pulse, notes) VALUES 
        (1, 1, 1, 1, 'Occasional chest tightness after exertion', 'Mild Angina Pectoris', '130/85', '98.4 F', '72 kg', '76 bpm', 'Advised low sodium diet and stress management.')");

    // 8. Prescriptions & Items
    $pdo->exec("CREATE TABLE IF NOT EXISTS prescriptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        consultation_id INTEGER,
        patient_id INTEGER NOT NULL,
        doctor_id INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS prescription_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        prescription_id INTEGER NOT NULL,
        medicine_id INTEGER,
        medicine_name TEXT NOT NULL,
        dosage TEXT NOT NULL,
        frequency TEXT NOT NULL,
        duration TEXT NOT NULL,
        instructions TEXT DEFAULT 'Take after food'
    )");
    $pdo->exec("INSERT OR IGNORE INTO prescriptions (id, consultation_id, patient_id, doctor_id) VALUES (1, 1, 1, 1)");
    $pdo->exec("INSERT OR IGNORE INTO prescription_items (id, prescription_id, medicine_name, dosage, frequency, duration, instructions) VALUES 
        (1, 1, 'Atorvastatin 10mg', '1 tablet', 'Once daily at night', '30 days', 'Take after food'),
        (2, 1, 'Aspirin 75mg', '1 tablet', 'Once daily morning', '30 days', 'Take after breakfast')");

    // 9. Medicines Inventory
    $pdo->exec("CREATE TABLE IF NOT EXISTS medicines (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        medicine_code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        category TEXT NOT NULL,
        manufacturer TEXT,
        batch_number TEXT NOT NULL,
        quantity INTEGER NOT NULL DEFAULT 0,
        min_stock_alert INTEGER DEFAULT 10,
        price REAL NOT NULL,
        expiry_date TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    $pdo->exec("INSERT OR IGNORE INTO medicines (id, medicine_code, name, category, manufacturer, batch_number, quantity, min_stock_alert, price, expiry_date) VALUES 
        (1, 'MED-501', 'Paracetamol 650mg', 'Analgesic / Antipyretic', 'Cipla Healthcare', 'BAT-2026A', 150, 20, 15.50, '2027-12-31'),
        (2, 'MED-502', 'Amoxicillin 500mg', 'Antibiotic', 'Sun Pharma', 'BAT-2026B', 8, 15, 45.00, '2027-08-15'),
        (3, 'MED-503', 'Atorvastatin 10mg', 'Cardiovascular', 'Lupin Labs', 'BAT-2025C', 80, 10, 85.00, '2026-02-10'),
        (4, 'MED-504', 'Metformin 500mg', 'Anti-diabetic', 'Dr. Reddy''s', 'BAT-2026D', 200, 25, 30.00, '2028-01-20'),
        (5, 'MED-505', 'Pantoprazole 40mg', 'Gastrointestinal', 'Torrent Pharma', 'BAT-2026E', 90, 15, 25.00, '2027-11-30')");

    // 10. Lab Tests & Reports
    $pdo->exec("CREATE TABLE IF NOT EXISTS lab_tests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        test_code TEXT UNIQUE NOT NULL,
        test_name TEXT NOT NULL,
        category TEXT NOT NULL,
        cost REAL NOT NULL,
        description TEXT
    )");
    $pdo->exec("INSERT OR IGNORE INTO lab_tests (id, test_code, test_name, category, cost, description) VALUES 
        (1, 'LAB-101', 'Complete Blood Count (CBC)', 'Hematology', 450.00, 'Evaluates overall health and detects anomalies.'),
        (2, 'LAB-102', 'Fasting Blood Sugar (FBS)', 'Biochemistry', 200.00, 'Measures blood glucose levels.'),
        (3, 'LAB-103', 'Lipid Profile', 'Cardiology', 850.00, 'Total cholesterol, HDL, LDL, Triglycerides.'),
        (4, 'LAB-104', 'Liver Function Test (LFT)', 'Biochemistry', 750.00, 'Bilirubin, SGOT, SGPT.'),
        (5, 'LAB-105', 'Kidney Function Test (KFT)', 'Biochemistry', 650.00, 'Creatinine, BUN.'),
        (6, 'LAB-106', 'Chest X-Ray PA View', 'Radiology', 500.00, 'Radiographic view of lungs and heart.')");

    $pdo->exec("CREATE TABLE IF NOT EXISTS lab_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        request_code TEXT UNIQUE NOT NULL,
        patient_id INTEGER NOT NULL,
        doctor_id INTEGER NOT NULL,
        consultation_id INTEGER,
        test_id INTEGER NOT NULL,
        priority TEXT DEFAULT 'Normal',
        notes TEXT,
        status TEXT DEFAULT 'Pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    $pdo->exec("INSERT OR IGNORE INTO lab_requests (id, request_code, patient_id, doctor_id, test_id, priority, notes, status) VALUES 
        (1, 'LREQ-1001', 1, 1, 1, 'Normal', 'Baseline checkup', 'Completed'),
        (2, 'LREQ-1002', 1, 1, 3, 'Urgent', 'Lipid screening', 'Pending')");

    $pdo->exec("CREATE TABLE IF NOT EXISTS lab_reports (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        request_id INTEGER NOT NULL,
        patient_id INTEGER NOT NULL,
        technician_id INTEGER NOT NULL,
        result_summary TEXT NOT NULL,
        report_file TEXT,
        test_data_json TEXT,
        completed_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    $pdo->exec("INSERT OR IGNORE INTO lab_reports (id, request_id, patient_id, technician_id, result_summary) VALUES 
        (1, 1, 1, 1, 'Hemoglobin: 14.2 g/dL (Normal). WBC: 7,500 /mcL. Platelets: 250,000 /mcL.')");

    // 11. Vitals
    $pdo->exec("CREATE TABLE IF NOT EXISTS vitals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        patient_id INTEGER NOT NULL,
        recorded_by_user_id INTEGER NOT NULL,
        bp TEXT NOT NULL,
        temperature TEXT NOT NULL,
        pulse TEXT NOT NULL,
        spo2 TEXT NOT NULL,
        weight TEXT NOT NULL,
        notes TEXT,
        recorded_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    $pdo->exec("INSERT OR IGNORE INTO vitals (id, patient_id, recorded_by_user_id, bp, temperature, pulse, spo2, weight, notes) VALUES 
        (1, 1, 4, '130/85', '98.4 F', '76 bpm', '99%', '72 kg', 'Slightly elevated BP, patient calm.')");

    // 12. Rooms & Beds
    $pdo->exec("CREATE TABLE IF NOT EXISTS rooms (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        room_number TEXT UNIQUE NOT NULL,
        room_type TEXT NOT NULL,
        floor TEXT DEFAULT '1st Floor',
        daily_rate REAL NOT NULL
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS beds (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        room_id INTEGER NOT NULL,
        bed_number TEXT NOT NULL,
        status TEXT DEFAULT 'Available'
    )");
    $pdo->exec("INSERT OR IGNORE INTO rooms (id, room_number, room_type, floor, daily_rate) VALUES 
        (1, 'GW-101', 'General Ward', '1st Floor', 800.00),
        (2, 'SP-201', 'Semi Private', '2nd Floor', 2500.00),
        (3, 'PV-301', 'Private', '3rd Floor', 4500.00),
        (4, 'ICU-401', 'ICU', '4th Floor', 9000.00)");
    $pdo->exec("INSERT OR IGNORE INTO beds (id, room_id, bed_number, status) VALUES 
        (1, 1, 'GW-101-A', 'Occupied'),
        (2, 1, 'GW-101-B', 'Available'),
        (3, 2, 'SP-201-A', 'Available'),
        (4, 3, 'PV-301-A', 'Available'),
        (5, 4, 'ICU-401-A', 'Maintenance')");

    // 13. Admissions & Discharges
    $pdo->exec("CREATE TABLE IF NOT EXISTS admissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        admission_code TEXT UNIQUE NOT NULL,
        patient_id INTEGER NOT NULL,
        doctor_id INTEGER NOT NULL,
        department_id INTEGER NOT NULL,
        room_id INTEGER NOT NULL,
        bed_id INTEGER NOT NULL,
        admission_date DATETIME NOT NULL,
        expected_discharge_date TEXT,
        diagnosis TEXT NOT NULL,
        status TEXT DEFAULT 'Admitted',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    $pdo->exec("INSERT OR IGNORE INTO admissions (id, admission_code, patient_id, doctor_id, department_id, room_id, bed_id, admission_date, diagnosis, status) VALUES 
        (1, 'ADM-8001', 1, 1, 1, 1, 1, datetime('now'), 'Acute Coronary Monitoring', 'Admitted')");

    $pdo->exec("CREATE TABLE IF NOT EXISTS discharges (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        admission_id INTEGER NOT NULL,
        patient_id INTEGER NOT NULL,
        doctor_id INTEGER NOT NULL,
        discharge_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        treatment_summary TEXT NOT NULL,
        medicines_summary TEXT NOT NULL,
        doctor_instructions TEXT,
        follow_up_date TEXT,
        final_bill_id INTEGER
    )");

    // 14. Invoices & Payments
    $pdo->exec("CREATE TABLE IF NOT EXISTS invoices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_code TEXT UNIQUE NOT NULL,
        patient_id INTEGER NOT NULL,
        appointment_id INTEGER,
        admission_id INTEGER,
        consultation_fee REAL DEFAULT 0.00,
        lab_charges REAL DEFAULT 0.00,
        medicine_charges REAL DEFAULT 0.00,
        room_charges REAL DEFAULT 0.00,
        other_charges REAL DEFAULT 0.00,
        subtotal REAL NOT NULL,
        discount REAL DEFAULT 0.00,
        tax REAL DEFAULT 0.00,
        grand_total REAL NOT NULL,
        payment_status TEXT DEFAULT 'Pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    $pdo->exec("INSERT OR IGNORE INTO invoices (id, invoice_code, patient_id, appointment_id, consultation_fee, lab_charges, subtotal, tax, grand_total, payment_status) VALUES 
        (1, 'INV-9001', 1, 1, 800.00, 450.00, 1250.00, 62.50, 1312.50, 'Pending'),
        (2, 'INV-9002', 2, 2, 750.00, 0.00, 750.00, 37.50, 787.50, 'Paid')");

    $pdo->exec("CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoice_id INTEGER NOT NULL,
        payment_code TEXT UNIQUE NOT NULL,
        transaction_id TEXT NOT NULL,
        amount REAL NOT NULL,
        payment_method TEXT NOT NULL,
        payment_status TEXT DEFAULT 'Success',
        payment_date DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    $pdo->exec("INSERT OR IGNORE INTO payments (id, invoice_id, payment_code, transaction_id, amount, payment_method, payment_status) VALUES 
        (1, 2, 'PAY-3001', 'TXN_UPI_9871236540', 787.50, 'UPI', 'Success')");

    // 15. Blood Inventory
    $pdo->exec("CREATE TABLE IF NOT EXISTS blood_inventory (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        blood_group TEXT UNIQUE NOT NULL,
        total_units INTEGER NOT NULL DEFAULT 0,
        reserved_units INTEGER NOT NULL DEFAULT 0,
        min_units_alert INTEGER DEFAULT 5,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    $pdo->exec("INSERT OR IGNORE INTO blood_inventory (blood_group, total_units, reserved_units, min_units_alert) VALUES 
        ('A+', 25, 2, 5), ('A-', 8, 1, 5), ('B+', 30, 4, 5), ('B-', 4, 0, 5),
        ('AB+', 12, 1, 5), ('AB-', 3, 0, 5), ('O+', 45, 5, 10), ('O-', 6, 2, 5)");

    // 16. Notifications
    $pdo->exec("CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        link TEXT DEFAULT '#',
        is_read INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    $pdo->exec("INSERT OR IGNORE INTO notifications (user_id, title, message, link) VALUES 
        (8, 'Appointment Confirmed', 'Your appointment with Dr. Ankit Sharma is checked in.', 'patient/my_appointments.php'),
        (2, 'New Patient Checked In', 'Patient Ramesh Gupta has checked in for Consultation Token A-001.', 'doctor/index.php'),
        (1, 'Low Stock Alert', 'Medicine Amoxicillin 500mg is low in stock.', 'admin/pharmacy.php')");

    // 17. Audit Logs
    $pdo->exec("CREATE TABLE IF NOT EXISTS audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        user_name TEXT DEFAULT 'System',
        role TEXT DEFAULT 'Guest',
        action TEXT NOT NULL,
        description TEXT NOT NULL,
        ip_address TEXT DEFAULT '127.0.0.1',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    $pdo->exec("INSERT OR IGNORE INTO audit_logs (user_id, user_name, role, action, description) VALUES 
        (1, 'System Administrator', 'Admin', 'SYSTEM_INIT', 'MediCareX Zero-Config Database initialized.')");

    // 18. Other staff roles
    $pdo->exec("CREATE TABLE IF NOT EXISTS nurses (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, nurse_code TEXT UNIQUE, department_id INTEGER DEFAULT 6, qualification TEXT DEFAULT 'B.Sc Nursing')");
    $pdo->exec("INSERT OR IGNORE INTO nurses (id, user_id, nurse_code) VALUES (1, 4, 'NUR-3001')");

    $pdo->exec("CREATE TABLE IF NOT EXISTS receptionists (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, emp_code TEXT UNIQUE)");
    $pdo->exec("INSERT OR IGNORE INTO receptionists (id, user_id, emp_code) VALUES (1, 5, 'REC-4001')");

    $pdo->exec("CREATE TABLE IF NOT EXISTS pharmacists (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, emp_code TEXT UNIQUE)");
    $pdo->exec("INSERT OR IGNORE INTO pharmacists (id, user_id, emp_code) VALUES (1, 6, 'PHA-5001')");

    $pdo->exec("CREATE TABLE IF NOT EXISTS lab_technicians (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, emp_code TEXT UNIQUE)");
    $pdo->exec("INSERT OR IGNORE INTO lab_technicians (id, user_id, emp_code) VALUES (1, 7, 'LAB-6001')");

    echo "SUCCESS: SQLite Database created and seeded at " . $dbFile . "\n";
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}
