-- MediCareX - Smart Hospital Management System
-- Database Schema & Sample Seed Data
-- Developed by Romit Kumar

CREATE DATABASE IF NOT EXISTS `medicarex` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `medicarex`;

-- Disable foreign key checks for clean structure rebuild
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `audit_logs`;
DROP TABLE IF EXISTS `notifications`;
DROP TABLE IF EXISTS `blood_inventory`;
DROP TABLE IF EXISTS `payments`;
DROP TABLE IF EXISTS `invoices`;
DROP TABLE IF EXISTS `discharges`;
DROP TABLE IF EXISTS `admissions`;
DROP TABLE IF EXISTS `beds`;
DROP TABLE IF EXISTS `rooms`;
DROP TABLE IF EXISTS `vitals`;
DROP TABLE IF EXISTS `lab_reports`;
DROP TABLE IF EXISTS `lab_requests`;
DROP TABLE IF EXISTS `lab_tests`;
DROP TABLE IF EXISTS `prescription_items`;
DROP TABLE IF EXISTS `prescriptions`;
DROP TABLE IF EXISTS `medicines`;
DROP TABLE IF EXISTS `consultations`;
DROP TABLE IF EXISTS `appointments`;
DROP TABLE IF EXISTS `doctor_availability`;
DROP TABLE IF EXISTS `lab_technicians`;
DROP TABLE IF EXISTS `pharmacists`;
DROP TABLE IF EXISTS `receptionists`;
DROP TABLE IF EXISTS `nurses`;
DROP TABLE IF EXISTS `doctors`;
DROP TABLE IF EXISTS `patients`;
DROP TABLE IF EXISTS `departments`;
DROP TABLE IF EXISTS `users`;
DROP TABLE IF EXISTS `roles`;

SET FOREIGN_KEY_CHECKS = 1;

-- 1. ROLES TABLE
CREATE TABLE `roles` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `role_name` VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `roles` (`id`, `role_name`) VALUES
(1, 'Admin'),
(2, 'Doctor'),
(3, 'Nurse'),
(4, 'Receptionist'),
(5, 'Pharmacist'),
(6, 'Lab Technician'),
(7, 'Patient');

-- 2. USERS TABLE
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_code` VARCHAR(20) NOT NULL UNIQUE,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `role_id` INT NOT NULL,
  `phone` VARCHAR(20) DEFAULT NULL,
  `avatar` VARCHAR(255) DEFAULT 'default_avatar.png',
  `status` ENUM('Active', 'Inactive', 'Suspended') DEFAULT 'Active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Hash for 'password123' -> $2y$10$b118F3F/v4kNtXFj2GT3s.fv2J2y/vT.NQ5yxjGI500lbmz6QujZu
INSERT INTO `users` (`id`, `user_code`, `name`, `email`, `password`, `role_id`, `phone`, `status`) VALUES
(1, 'ADM-1001', 'System Administrator', 'admin@medicarex.local', '$2y$10$b118F3F/v4kNtXFj2GT3s.fv2J2y/vT.NQ5yxjGI500lbmz6QujZu', 1, '+91 9876543210', 'Active'),
(2, 'DOC-2001', 'Dr. Ankit Sharma', 'doctor@medicarex.local', '$2y$10$b118F3F/v4kNtXFj2GT3s.fv2J2y/vT.NQ5yxjGI500lbmz6QujZu', 2, '+91 9876543211', 'Active'),
(3, 'DOC-2002', 'Dr. Priya Singh', 'doctor2@medicarex.local', '$2y$10$b118F3F/v4kNtXFj2GT3s.fv2J2y/vT.NQ5yxjGI500lbmz6QujZu', 2, '+91 9876543212', 'Active'),
(4, 'NUR-3001', 'Nurse Sunita Verma', 'nurse@medicarex.local', '$2y$10$b118F3F/v4kNtXFj2GT3s.fv2J2y/vT.NQ5yxjGI500lbmz6QujZu', 3, '+91 9876543213', 'Active'),
(5, 'REC-4001', 'Rahul Verma (Reception)', 'reception@medicarex.local', '$2y$10$b118F3F/v4kNtXFj2GT3s.fv2J2y/vT.NQ5yxjGI500lbmz6QujZu', 4, '+91 9876543214', 'Active'),
(6, 'PHA-5001', 'Vikram Patel (Pharmacy)', 'pharmacy@medicarex.local', '$2y$10$b118F3F/v4kNtXFj2GT3s.fv2J2y/vT.NQ5yxjGI500lbmz6QujZu', 5, '+91 9876543215', 'Active'),
(7, 'LAB-6001', 'Suresh Kumar (Lab)', 'lab@medicarex.local', '$2y$10$b118F3F/v4kNtXFj2GT3s.fv2J2y/vT.NQ5yxjGI500lbmz6QujZu', 6, '+91 9876543216', 'Active'),
(8, 'PAT-7001', 'Ramesh Gupta', 'patient@medicarex.local', '$2y$10$b118F3F/v4kNtXFj2GT3s.fv2J2y/vT.NQ5yxjGI500lbmz6QujZu', 7, '+91 9876543217', 'Active'),
(9, 'PAT-7002', 'Anita Roy', 'anita.roy@example.com', '$2y$10$b118F3F/v4kNtXFj2GT3s.fv2J2y/vT.NQ5yxjGI500lbmz6QujZu', 7, '+91 9876543218', 'Active'),
(10, 'DOC-2003', 'Dr. Rajesh Verma', 'rajesh.ortho@medicarex.local', '$2y$10$b118F3F/v4kNtXFj2GT3s.fv2J2y/vT.NQ5yxjGI500lbmz6QujZu', 2, '+91 9876543220', 'Active'),
(11, 'DOC-2004', 'Dr. Sneha Kulkarni', 'sneha.pedia@medicarex.local', '$2y$10$b118F3F/v4kNtXFj2GT3s.fv2J2y/vT.NQ5yxjGI500lbmz6QujZu', 2, '+91 9876543221', 'Active'),
(12, 'DOC-2005', 'Dr. Rohan Mehta', 'rohan.derma@medicarex.local', '$2y$10$b118F3F/v4kNtXFj2GT3s.fv2J2y/vT.NQ5yxjGI500lbmz6QujZu', 2, '+91 9876543222', 'Active'),
(13, 'DOC-2006', 'Dr. Alok Nath', 'alok.medicine@medicarex.local', '$2y$10$b118F3F/v4kNtXFj2GT3s.fv2J2y/vT.NQ5yxjGI500lbmz6QujZu', 2, '+91 9876543223', 'Active'),
(14, 'DOC-2007', 'Dr. Sunidhi Sen', 'sunidhi.gynae@medicarex.local', '$2y$10$b118F3F/v4kNtXFj2GT3s.fv2J2y/vT.NQ5yxjGI500lbmz6QujZu', 2, '+91 9876543224', 'Active'),
(15, 'DOC-2008', 'Dr. Manish Tiwari', 'manish.ent@medicarex.local', '$2y$10$b118F3F/v4kNtXFj2GT3s.fv2J2y/vT.NQ5yxjGI500lbmz6QujZu', 2, '+91 9876543225', 'Active'),
(16, 'DOC-2009', 'Dr. Kavita Nair', 'kavita.dental@medicarex.local', '$2y$10$b118F3F/v4kNtXFj2GT3s.fv2J2y/vT.NQ5yxjGI500lbmz6QujZu', 2, '+91 9876543226', 'Active'),
(17, 'DOC-2010', 'Dr. Deepak Joshi', 'deepak.doc@medicarex.local', '$2y$10$b118F3F/v4kNtXFj2GT3s.fv2J2y/vT.NQ5yxjGI500lbmz6QujZu', 2, '+91 9876543227', 'Active'),
(18, 'DOC-2011', 'Dr. Neha Kapoor', 'neha.pedia@medicarex.local', '$2y$10$b118F3F/v4kNtXFj2GT3s.fv2J2y/vT.NQ5yxjGI500lbmz6QujZu', 2, '+91 9876543228', 'Active');

-- 3. DEPARTMENTS TABLE
CREATE TABLE `departments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `dept_name` VARCHAR(100) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `icon` VARCHAR(50) DEFAULT 'bi-hospital',
  `status` ENUM('Active', 'Inactive') DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `departments` (`id`, `dept_name`, `description`, `icon`) VALUES
(1, 'Cardiology', 'Heart, blood vessels, and cardiovascular disorders.', 'bi-heart-pulse-fill'),
(2, 'Neurology', 'Brain, spinal cord, and nerve treatments.', 'bi-cpu-fill'),
(3, 'Orthopedics', 'Bones, joints, muscles, and ligament care.', 'bi-person-arms-up'),
(4, 'Pediatrics', 'Child healthcare, vaccinations, and infant wellness.', 'bi-emoji-smile-fill'),
(5, 'Dermatology', 'Skin, hair, and cosmetic medical procedures.', 'bi-sun-fill'),
(6, 'General Medicine', 'Comprehensive primary care and diagnosis.', 'bi-bandaid-fill'),
(7, 'Gynecology', 'Women reproductive health and maternity care.', 'bi-gender-female'),
(8, 'ENT', 'Ear, Nose, Throat diagnosis and surgeries.', 'bi-ear-fill'),
(9, 'Dental', 'Teeth, gums, and oral healthcare.', 'bi-capsule');

-- 4. PATIENTS TABLE
CREATE TABLE `patients` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `patient_code` VARCHAR(20) NOT NULL UNIQUE,
  `dob` DATE DEFAULT NULL,
  `gender` ENUM('Male', 'Female', 'Other') NOT NULL,
  `blood_group` VARCHAR(5) DEFAULT 'O+',
  `address` TEXT DEFAULT NULL,
  `emergency_contact` VARCHAR(20) DEFAULT NULL,
  `medical_history` TEXT DEFAULT NULL,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `patients` (`id`, `user_id`, `patient_code`, `dob`, `gender`, `blood_group`, `address`, `emergency_contact`, `medical_history`) VALUES
(1, 8, 'PAT-7001', '1988-05-14', 'Male', 'B+', '123 MG Road, New Delhi', '+91 9988776655', 'Mild hypertension, penicillin allergy.'),
(2, 9, 'PAT-7002', '1993-11-20', 'Female', 'O+', '45 Park Street, Kolkata', '+91 9876512345', 'No major prior chronic conditions.');

-- 5. DOCTORS TABLE
CREATE TABLE `doctors` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `doctor_code` VARCHAR(20) NOT NULL UNIQUE,
  `department_id` INT NOT NULL,
  `specialization` VARCHAR(100) NOT NULL,
  `qualification` VARCHAR(100) NOT NULL,
  `experience_years` INT DEFAULT 10,
  `consultation_fee` DECIMAL(10,2) DEFAULT 500.00,
  `availability_days` VARCHAR(100) DEFAULT 'Mon,Tue,Wed,Thu,Fri',
  `availability_time` VARCHAR(100) DEFAULT '09:00 AM - 02:00 PM',
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`department_id`) REFERENCES `departments`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `doctors` (`id`, `user_id`, `doctor_code`, `department_id`, `specialization`, `qualification`, `experience_years`, `consultation_fee`, `availability_days`, `availability_time`) VALUES
(1, 2, 'DOC-2001', 1, 'Interventional Cardiology', 'MBBS, MD, DM (Cardiology)', 12, 800.00, 'Mon,Tue,Wed,Thu,Fri', '09:00 AM - 02:00 PM'),
(2, 3, 'DOC-2002', 2, 'Clinical Neurology & Stroke Care', 'MBBS, MD, DNB (Neurology)', 9, 750.00, 'Mon,Wed,Fri', '10:00 AM - 03:00 PM'),
(3, 10, 'DOC-2003', 3, 'Joint Replacement & Trauma Surgery', 'MBBS, MS (Orthopedics)', 15, 700.00, 'Mon,Tue,Thu,Sat', '09:00 AM - 01:00 PM'),
(4, 11, 'DOC-2004', 4, 'Consultant Pediatrician & Neonatologist', 'MBBS, MD (Pediatrics), DCH', 8, 600.00, 'Mon,Tue,Wed,Thu,Fri,Sat', '09:30 AM - 02:30 PM'),
(5, 12, 'DOC-2005', 5, 'Clinical Dermatology & Cosmetology', 'MBBS, MD (DVL)', 10, 650.00, 'Tue,Wed,Fri,Sat', '10:00 AM - 04:00 PM'),
(6, 13, 'DOC-2006', 6, 'Internal Medicine & Critical Care', 'MBBS, MD (General Medicine)', 14, 500.00, 'Mon,Tue,Wed,Thu,Fri,Sat', '08:30 AM - 01:30 PM'),
(7, 14, 'DOC-2007', 7, 'Obstetrics & High-Risk Pregnancy', 'MBBS, MS (OBG), DGO', 11, 700.00, 'Mon,Wed,Fri,Sat', '09:00 AM - 02:00 PM'),
(8, 15, 'DOC-2008', 8, 'ENT & Head Neck Surgery', 'MBBS, MS (ENT)', 10, 600.00, 'Mon,Tue,Thu,Sat', '10:00 AM - 03:00 PM'),
(9, 16, 'DOC-2009', 9, 'Dental Surgery & Implantology', 'BDS, MDS (Oral & Maxillofacial)', 7, 500.00, 'Mon,Wed,Thu,Fri,Sat', '09:30 AM - 02:30 PM'),
(10, 17, 'DOC-2010', 6, 'Family Medicine & Diabetes Care', 'MBBS, Fellowship in Diabetology', 8, 450.00, 'Mon,Tue,Wed,Thu,Fri', '01:00 PM - 06:00 PM'),
(11, 18, 'DOC-2011', 4, 'Pediatric Care & Child Nutrition', 'MBBS, DNB (Pediatrics)', 6, 550.00, 'Tue,Wed,Thu,Fri,Sat', '02:00 PM - 06:00 PM');

-- 6. NURSES, RECEPTIONISTS, PHARMACISTS, LAB TECHS
CREATE TABLE `nurses` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `nurse_code` VARCHAR(20) NOT NULL UNIQUE,
  `department_id` INT DEFAULT 6,
  `qualification` VARCHAR(100) DEFAULT 'B.Sc Nursing',
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `nurses` (`id`, `user_id`, `nurse_code`, `department_id`, `qualification`) VALUES
(1, 4, 'NUR-3001', 6, 'B.Sc Nursing, Critical Care');

CREATE TABLE `receptionists` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `emp_code` VARCHAR(20) NOT NULL UNIQUE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `receptionists` (`id`, `user_id`, `emp_code`) VALUES (1, 5, 'REC-4001');

CREATE TABLE `pharmacists` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `emp_code` VARCHAR(20) NOT NULL UNIQUE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `pharmacists` (`id`, `user_id`, `emp_code`) VALUES (1, 6, 'PHA-5001');

CREATE TABLE `lab_technicians` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `emp_code` VARCHAR(20) NOT NULL UNIQUE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `lab_technicians` (`id`, `user_id`, `emp_code`) VALUES (1, 7, 'LAB-6001');

-- 7. APPOINTMENTS TABLE
CREATE TABLE `appointments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `appointment_code` VARCHAR(20) NOT NULL UNIQUE,
  `patient_id` INT NOT NULL,
  `doctor_id` INT NOT NULL,
  `department_id` INT NOT NULL,
  `appointment_date` DATE NOT NULL,
  `time_slot` VARCHAR(30) NOT NULL,
  `token_number` VARCHAR(10) NOT NULL,
  `reason` TEXT DEFAULT NULL,
  `status` ENUM('Pending', 'Confirmed', 'Checked In', 'In Consultation', 'Completed', 'Cancelled') DEFAULT 'Pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`patient_id`) REFERENCES `patients`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`doctor_id`) REFERENCES `doctors`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`department_id`) REFERENCES `departments`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `appointments` (`id`, `appointment_code`, `patient_id`, `doctor_id`, `department_id`, `appointment_date`, `time_slot`, `token_number`, `reason`, `status`, `created_at`) VALUES
(1, 'APT-1001', 1, 1, 1, CURDATE(), '09:30 AM', 'A-001', 'Routine chest discomfort evaluation.', 'Checked In', NOW()),
(2, 'APT-1002', 2, 2, 2, CURDATE(), '10:15 AM', 'B-001', 'Migraine headache and dizziness.', 'Pending', NOW());

-- 8. CONSULTATIONS TABLE
CREATE TABLE `consultations` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `appointment_id` INT NOT NULL,
  `patient_id` INT NOT NULL,
  `doctor_id` INT NOT NULL,
  `symptoms` TEXT NOT NULL,
  `diagnosis` TEXT NOT NULL,
  `bp` VARCHAR(20) DEFAULT '120/80',
  `temp` VARCHAR(10) DEFAULT '98.6 F',
  `weight` VARCHAR(10) DEFAULT '70 kg',
  `pulse` VARCHAR(10) DEFAULT '72 bpm',
  `notes` TEXT DEFAULT NULL,
  `follow_up_date` DATE DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`appointment_id`) REFERENCES `appointments`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`patient_id`) REFERENCES `patients`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`doctor_id`) REFERENCES `doctors`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. MEDICINES INVENTORY TABLE
CREATE TABLE `medicines` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `medicine_code` VARCHAR(20) NOT NULL UNIQUE,
  `name` VARCHAR(150) NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `manufacturer` VARCHAR(100) DEFAULT NULL,
  `batch_number` VARCHAR(50) NOT NULL,
  `quantity` INT NOT NULL DEFAULT 0,
  `min_stock_alert` INT DEFAULT 10,
  `price` DECIMAL(10,2) NOT NULL,
  `expiry_date` DATE NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `medicines` (`id`, `medicine_code`, `name`, `category`, `manufacturer`, `batch_number`, `quantity`, `min_stock_alert`, `price`, `expiry_date`) VALUES
(1, 'MED-501', 'Paracetamol 650mg', 'Analgesic / Antipyretic', 'Cipla Healthcare', 'BAT-2026A', 150, 20, 15.50, '2027-12-31'),
(2, 'MED-502', 'Amoxicillin 500mg', 'Antibiotic', 'Sun Pharma', 'BAT-2026B', 8, 15, 45.00, '2027-08-15'), -- LOW STOCK
(3, 'MED-503', 'Atorvastatin 10mg', 'Cardiovascular', 'Lupin Labs', 'BAT-2025C', 80, 10, 85.00, '2026-02-10'), -- EXPIRED FOR DEMO
(4, 'MED-504', 'Metformin 500mg', 'Anti-diabetic', 'Dr. Reddy\'s', 'BAT-2026D', 200, 25, 30.00, '2028-01-20'),
(5, 'MED-505', 'Pantoprazole 40mg', 'Gastrointestinal', 'Torrent Pharma', 'BAT-2026E', 90, 15, 25.00, '2027-11-30');

-- 10. PRESCRIPTIONS & PRESCRIPTION ITEMS
CREATE TABLE `prescriptions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `consultation_id` INT DEFAULT NULL,
  `patient_id` INT NOT NULL,
  `doctor_id` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`patient_id`) REFERENCES `patients`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`doctor_id`) REFERENCES `doctors`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `prescription_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `prescription_id` INT NOT NULL,
  `medicine_id` INT DEFAULT NULL,
  `medicine_name` VARCHAR(150) NOT NULL,
  `dosage` VARCHAR(50) NOT NULL,
  `frequency` VARCHAR(50) NOT NULL,
  `duration` VARCHAR(50) NOT NULL,
  `instructions` VARCHAR(255) DEFAULT 'Take after food',
  FOREIGN KEY (`prescription_id`) REFERENCES `prescriptions`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 11. LAB TESTS, REQUESTS & REPORTS
CREATE TABLE `lab_tests` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `test_code` VARCHAR(20) NOT NULL UNIQUE,
  `test_name` VARCHAR(150) NOT NULL,
  `category` VARCHAR(100) NOT NULL,
  `cost` DECIMAL(10,2) NOT NULL,
  `description` TEXT DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `lab_tests` (`id`, `test_code`, `test_name`, `category`, `cost`, `description`) VALUES
(1, 'LAB-101', 'Complete Blood Count (CBC)', 'Hematology', 450.00, 'Evaluates overall health and detects red/white blood cell anomalies.'),
(2, 'LAB-102', 'Fasting Blood Sugar (FBS)', 'Biochemistry', 200.00, 'Measures blood glucose levels after fasting.'),
(3, 'LAB-103', 'Lipid Profile', 'Cardiology', 850.00, 'Total cholesterol, HDL, LDL, and Triglycerides.'),
(4, 'LAB-104', 'Liver Function Test (LFT)', 'Biochemistry', 750.00, 'Bilirubin, SGOT, SGPT, and Alkaline Phosphatase.'),
(5, 'LAB-105', 'Kidney Function Test (KFT)', 'Biochemistry', 650.00, 'Serum Creatinine, Blood Urea Nitrogen, and Uric Acid.'),
(6, 'LAB-106', 'Chest X-Ray PA View', 'Radiology', 500.00, 'Radiographic view of lungs and cardiac silhouette.');

CREATE TABLE `lab_requests` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `request_code` VARCHAR(20) NOT NULL UNIQUE,
  `patient_id` INT NOT NULL,
  `doctor_id` INT NOT NULL,
  `consultation_id` INT DEFAULT NULL,
  `test_id` INT NOT NULL,
  `priority` ENUM('Normal', 'Urgent', 'Emergency') DEFAULT 'Normal',
  `notes` TEXT DEFAULT NULL,
  `status` ENUM('Pending', 'In Progress', 'Completed', 'Cancelled') DEFAULT 'Pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`patient_id`) REFERENCES `patients`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`doctor_id`) REFERENCES `doctors`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`test_id`) REFERENCES `lab_tests`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `lab_requests` (`id`, `request_code`, `patient_id`, `doctor_id`, `test_id`, `priority`, `notes`, `status`) VALUES
(1, 'LREQ-1001', 1, 1, 1, 'Normal', 'Check baseline hemoglobin.', 'Completed'),
(2, 'LREQ-1002', 1, 1, 3, 'Urgent', 'Check lipid profile for cardiac evaluation.', 'Pending');

CREATE TABLE `lab_reports` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `request_id` INT NOT NULL,
  `patient_id` INT NOT NULL,
  `technician_id` INT NOT NULL,
  `result_summary` TEXT NOT NULL,
  `report_file` VARCHAR(255) DEFAULT NULL,
  `test_data_json` TEXT DEFAULT NULL,
  `completed_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`request_id`) REFERENCES `lab_requests`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`patient_id`) REFERENCES `patients`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `lab_reports` (`id`, `request_id`, `patient_id`, `technician_id`, `result_summary`, `test_data_json`) VALUES
(1, 1, 1, 1, 'Hemoglobin: 14.2 g/dL (Normal). WBC: 7,500 /mcL (Normal). Platelets: 250,000 /mcL.', '{"Hemoglobin":"14.2 g/dL", "WBC":"7500 /mcL", "Platelets":"250000 /mcL"}');

-- 12. VITALS LOG TABLE
CREATE TABLE `vitals` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `patient_id` INT NOT NULL,
  `recorded_by_user_id` INT NOT NULL,
  `bp` VARCHAR(20) NOT NULL,
  `temperature` VARCHAR(20) NOT NULL,
  `pulse` VARCHAR(20) NOT NULL,
  `spo2` VARCHAR(20) NOT NULL,
  `weight` VARCHAR(20) NOT NULL,
  `notes` VARCHAR(255) DEFAULT NULL,
  `recorded_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`patient_id`) REFERENCES `patients`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `vitals` (`id`, `patient_id`, `recorded_by_user_id`, `bp`, `temperature`, `pulse`, `spo2`, `weight`, `notes`) VALUES
(1, 1, 4, '130/85', '98.4 F', '76 bpm', '99%', '72 kg', 'Slightly elevated BP, patient calm.');

-- 13. ROOMS & BEDS TABLE
CREATE TABLE `rooms` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `room_number` VARCHAR(20) NOT NULL UNIQUE,
  `room_type` ENUM('General Ward', 'Semi Private', 'Private', 'ICU', 'Emergency') NOT NULL,
  `floor` VARCHAR(20) DEFAULT '1st Floor',
  `daily_rate` DECIMAL(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `rooms` (`id`, `room_number`, `room_type`, `floor`, `daily_rate`) VALUES
(1, 'GW-101', 'General Ward', '1st Floor', 800.00),
(2, 'SP-201', 'Semi Private', '2nd Floor', 2500.00),
(3, 'PV-301', 'Private', '3rd Floor', 4500.00),
(4, 'ICU-401', 'ICU', '4th Floor', 9000.00);

CREATE TABLE `beds` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `room_id` INT NOT NULL,
  `bed_number` VARCHAR(20) NOT NULL,
  `status` ENUM('Available', 'Occupied', 'Maintenance') DEFAULT 'Available',
  FOREIGN KEY (`room_id`) REFERENCES `rooms`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `beds` (`id`, `room_id`, `bed_number`, `status`) VALUES
(1, 1, 'GW-101-A', 'Occupied'),
(2, 1, 'GW-101-B', 'Available'),
(3, 2, 'SP-201-A', 'Available'),
(4, 3, 'PV-301-A', 'Available'),
(5, 4, 'ICU-401-A', 'Maintenance');

-- 14. ADMISSIONS & DISCHARGES TABLE
CREATE TABLE `admissions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `admission_code` VARCHAR(20) NOT NULL UNIQUE,
  `patient_id` INT NOT NULL,
  `doctor_id` INT NOT NULL,
  `department_id` INT NOT NULL,
  `room_id` INT NOT NULL,
  `bed_id` INT NOT NULL,
  `admission_date` DATETIME NOT NULL,
  `expected_discharge_date` DATE DEFAULT NULL,
  `diagnosis` TEXT NOT NULL,
  `status` ENUM('Admitted', 'Under Treatment', 'Discharged') DEFAULT 'Admitted',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`patient_id`) REFERENCES `patients`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`doctor_id`) REFERENCES `doctors`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`room_id`) REFERENCES `rooms`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`bed_id`) REFERENCES `beds`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `admissions` (`id`, `admission_code`, `patient_id`, `doctor_id`, `department_id`, `room_id`, `bed_id`, `admission_date`, `diagnosis`, `status`) VALUES
(1, 'ADM-8001', 1, 1, 1, 1, 1, NOW(), 'Acute Coronary Monitoring', 'Admitted');

CREATE TABLE `discharges` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `admission_id` INT NOT NULL,
  `patient_id` INT NOT NULL,
  `doctor_id` INT NOT NULL,
  `discharge_date` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `treatment_summary` TEXT NOT NULL,
  `medicines_summary` TEXT NOT NULL,
  `doctor_instructions` TEXT DEFAULT NULL,
  `follow_up_date` DATE DEFAULT NULL,
  `final_bill_id` INT DEFAULT NULL,
  FOREIGN KEY (`admission_id`) REFERENCES `admissions`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`patient_id`) REFERENCES `patients`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`doctor_id`) REFERENCES `doctors`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 15. INVOICES & PAYMENTS TABLE
CREATE TABLE `invoices` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `invoice_code` VARCHAR(20) NOT NULL UNIQUE,
  `patient_id` INT NOT NULL,
  `appointment_id` INT DEFAULT NULL,
  `admission_id` INT DEFAULT NULL,
  `consultation_fee` DECIMAL(10,2) DEFAULT 0.00,
  `lab_charges` DECIMAL(10,2) DEFAULT 0.00,
  `medicine_charges` DECIMAL(10,2) DEFAULT 0.00,
  `room_charges` DECIMAL(10,2) DEFAULT 0.00,
  `other_charges` DECIMAL(10,2) DEFAULT 0.00,
  `subtotal` DECIMAL(10,2) NOT NULL,
  `discount` DECIMAL(10,2) DEFAULT 0.00,
  `tax` DECIMAL(10,2) DEFAULT 0.00,
  `grand_total` DECIMAL(10,2) NOT NULL,
  `payment_status` ENUM('Pending', 'Partial', 'Paid') DEFAULT 'Pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`patient_id`) REFERENCES `patients`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `invoices` (`id`, `invoice_code`, `patient_id`, `appointment_id`, `consultation_fee`, `lab_charges`, `subtotal`, `tax`, `grand_total`, `payment_status`) VALUES
(1, 'INV-9001', 1, 1, 800.00, 450.00, 1250.00, 62.50, 1312.50, 'Pending'),
(2, 'INV-9002', 2, 2, 750.00, 0.00, 750.00, 37.50, 787.50, 'Paid');

CREATE TABLE `payments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `invoice_id` INT NOT NULL,
  `payment_code` VARCHAR(25) NOT NULL UNIQUE,
  `transaction_id` VARCHAR(100) NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `payment_method` ENUM('UPI', 'Card', 'Net Banking', 'Cash') NOT NULL,
  `payment_status` ENUM('Success', 'Pending', 'Failed') DEFAULT 'Success',
  `payment_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`invoice_id`) REFERENCES `invoices`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `payments` (`id`, `invoice_id`, `payment_code`, `transaction_id`, `amount`, `payment_method`, `payment_status`) VALUES
(1, 2, 'PAY-3001', 'TXN_UPI_9871236540', 787.50, 'UPI', 'Success');

-- 16. BLOOD BANK INVENTORY TABLE
CREATE TABLE `blood_inventory` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `blood_group` VARCHAR(5) NOT NULL UNIQUE,
  `total_units` INT NOT NULL DEFAULT 0,
  `reserved_units` INT NOT NULL DEFAULT 0,
  `min_units_alert` INT DEFAULT 5,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `blood_inventory` (`blood_group`, `total_units`, `reserved_units`, `min_units_alert`) VALUES
('A+', 25, 2, 5),
('A-', 8, 1, 5),
('B+', 30, 4, 5),
('B-', 4, 0, 5), -- LOW STOCK
('AB+', 12, 1, 5),
('AB-', 3, 0, 5), -- LOW STOCK
('O+', 45, 5, 10),
('O-', 6, 2, 5);

-- 17. NOTIFICATIONS TABLE
CREATE TABLE `notifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `title` VARCHAR(150) NOT NULL,
  `message` TEXT NOT NULL,
  `link` VARCHAR(255) DEFAULT '#',
  `is_read` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `notifications` (`user_id`, `title`, `message`, `link`) VALUES
(8, 'Appointment Confirmed', 'Your appointment with Dr. Ankit Sharma is checked in.', 'patient/my_appointments.php'),
(2, 'New Patient Checked In', 'Patient Ramesh Gupta has checked in for Consultation Token A-001.', 'doctor/index.php'),
(1, 'Low Stock Alert', 'Medicine Amoxicillin 500mg is low in stock (8 units left).', 'admin/pharmacy.php');

-- 18. AUDIT LOGS TABLE
CREATE TABLE `audit_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT DEFAULT NULL,
  `user_name` VARCHAR(100) DEFAULT 'System',
  `role` VARCHAR(50) DEFAULT 'Guest',
  `action` VARCHAR(100) NOT NULL,
  `description` TEXT NOT NULL,
  `ip_address` VARCHAR(50) DEFAULT '127.0.0.1',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `audit_logs` (`user_id`, `user_name`, `role`, `action`, `description`) VALUES
(1, 'System Administrator', 'Admin', 'SYSTEM_INIT', 'MediCareX Database initialized successfully with default configuration and seed data.');
