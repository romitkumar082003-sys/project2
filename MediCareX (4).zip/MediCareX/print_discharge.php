<?php
// MediCareX - Printable Discharge Summary Generator
// Developed by Romit Kumar

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireLogin();

$id = intval($_GET['id'] ?? 0);
$pdo = getDBConnection();

$stmt = $pdo->prepare("
    SELECT dis.*, 
           adm.admission_code, adm.admission_date, adm.diagnosis as admission_diagnosis,
           p.patient_code, u_p.name as patient_name, u_p.phone as patient_phone, p.dob, p.gender, p.blood_group,
           d.doctor_code, u_d.name as doctor_name, d.specialization, dep.dept_name,
           r.room_number, r.room_type, b.bed_number
    FROM discharges dis
    JOIN admissions adm ON dis.admission_id = adm.id
    JOIN patients p ON dis.patient_id = p.id
    JOIN users u_p ON p.user_id = u_p.id
    JOIN doctors d ON dis.doctor_id = d.id
    JOIN users u_d ON d.user_id = u_d.id
    JOIN departments dep ON adm.department_id = dep.id
    JOIN rooms r ON adm.room_id = r.id
    JOIN beds b ON adm.bed_id = b.id
    WHERE dis.id = ? OR dis.admission_id = ?
");
$stmt->execute([$id, $id]);
$dis = $stmt->fetch();

if (!$dis) {
    die("Discharge summary record not found.");
}

$baseUrl = get_base_url();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Discharge Summary #<?= $dis['admission_code'] ?> - MediCareX</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>/assets/css/style.css">
    <style>
        body { background: #fff; color: #000; font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="p-4 p-md-5">

    <div class="container bg-white p-4 border rounded-3 shadow-sm" style="max-width: 850px;">
        <div class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-4">
            <div>
                <h2 class="fw-bold text-primary mb-0"><i class="bi bi-cross-circle-fill me-2"></i> MediCareX Hospital</h2>
                <small class="text-muted">Inpatient Clinical Department &bull; Discharge Summary</small>
            </div>
            <div class="text-end">
                <span class="badge bg-success px-3 py-2 fs-6">Discharged</span>
                <div class="fw-bold text-dark mt-1">ID: <?= htmlspecialchars($dis['admission_code']) ?></div>
            </div>
        </div>

        <div class="row g-3 mb-4 p-3 bg-light rounded-3 border fs-7">
            <div class="col-md-6 border-end">
                <h6 class="fw-bold text-primary text-uppercase fs-8 mb-1">Patient Information</h6>
                <div>Name: <strong><?= htmlspecialchars($dis['patient_name']) ?></strong> (ID: <?= htmlspecialchars($dis['patient_code']) ?>)</div>
                <div>Gender: <?= htmlspecialchars($dis['gender']) ?> | Blood Group: <?= htmlspecialchars($dis['blood_group']) ?></div>
                <div>Phone: <?= htmlspecialchars($dis['patient_phone']) ?></div>
                <div>Ward/Bed: <strong><?= htmlspecialchars($dis['room_number']) ?> (<?= htmlspecialchars($dis['room_type']) ?>) - Bed <?= htmlspecialchars($dis['bed_number']) ?></strong></div>
            </div>
            <div class="col-md-6 ps-md-4">
                <h6 class="fw-bold text-primary text-uppercase fs-8 mb-1">Admission & Attending Doctor</h6>
                <div>Doctor: <strong><?= htmlspecialchars($dis['doctor_name']) ?></strong> (<?= htmlspecialchars($dis['specialization']) ?>)</div>
                <div>Department: <?= htmlspecialchars($dis['dept_name']) ?></div>
                <div>Admitted Date: <?= formatDate($dis['admission_date'], 'd M Y, h:i A') ?></div>
                <div>Discharged Date: <?= formatDate($dis['discharge_date'], 'd M Y, h:i A') ?></div>
            </div>
        </div>

        <div class="mb-4 fs-7">
            <h6 class="fw-bold text-uppercase text-primary border-bottom pb-1">1. Final Diagnosis</h6>
            <p class="fw-semibold text-dark mb-0"><?= nl2br(htmlspecialchars($dis['admission_diagnosis'])) ?></p>
        </div>

        <div class="mb-4 fs-7">
            <h6 class="fw-bold text-uppercase text-primary border-bottom pb-1">2. Course of Treatment Summary</h6>
            <p class="text-dark mb-0"><?= nl2br(htmlspecialchars($dis['treatment_summary'])) ?></p>
        </div>

        <div class="mb-4 fs-7">
            <h6 class="fw-bold text-uppercase text-primary border-bottom pb-1">3. Discharge Medications</h6>
            <p class="text-dark mb-0"><?= nl2br(htmlspecialchars($dis['medicines_summary'])) ?></p>
        </div>

        <?php if (!empty($dis['doctor_instructions'])): ?>
            <div class="mb-4 fs-7">
                <h6 class="fw-bold text-uppercase text-primary border-bottom pb-1">4. Special Instructions & Precautions</h6>
                <p class="text-dark mb-0"><?= nl2br(htmlspecialchars($dis['doctor_instructions'])) ?></p>
            </div>
        <?php endif; ?>

        <?php if (!empty($dis['follow_up_date'])): ?>
            <div class="alert alert-info py-2 fs-7 mb-4">
                <i class="bi bi-calendar-event me-2"></i> Mandatory Follow-Up Date: <strong><?= formatDate($dis['follow_up_date'], 'd M Y') ?></strong>
            </div>
        <?php endif; ?>

        <div class="d-flex justify-content-between align-items-end mt-5 pt-3 border-top fs-7">
            <div>
                <small class="text-muted d-block">Generated by MediCareX Digital Health System</small>
                <small class="fw-bold text-primary"><?= DEVELOPER_NAME ?></small>
            </div>
            <div class="text-center" style="width: 220px;">
                <div class="border-bottom pb-4 mb-1"></div>
                <small class="fw-bold"><?= htmlspecialchars($dis['doctor_name']) ?></small><br>
                <small class="text-muted">Chief Medical Officer / Consultant</small>
            </div>
        </div>

        <div class="text-center mt-4 no-print">
            <button onclick="window.print()" class="btn btn-primary btn-lg rounded-pill px-4 shadow">
                <i class="bi bi-printer-fill me-2"></i> Print Discharge Summary / Save PDF
            </button>
        </div>
    </div>

</body>
</html>
