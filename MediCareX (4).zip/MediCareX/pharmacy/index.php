<?php
// MediCareX - Pharmacy Inventory Dashboard
// Developed by Romit Kumar

$pageTitle = 'Pharmacy Dashboard';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole(['Pharmacist', 'Admin']);

$user = getCurrentUser();
$pdo = getDBConnection();

$cntTotal = $pdo->query("SELECT COUNT(*) FROM medicines")->fetchColumn();
$cntLow = $pdo->query("SELECT COUNT(*) FROM medicines WHERE quantity <= min_stock_alert")->fetchColumn();
$cntExpired = $pdo->query("SELECT COUNT(*) FROM medicines WHERE expiry_date <= CURDATE()")->fetchColumn();

$medicines = $pdo->query("SELECT * FROM medicines ORDER BY id DESC LIMIT 10")->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <?php displayFlash(); ?>

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1">Pharmacy Inventory Dashboard</h3>
                    <p class="text-muted mb-0">Stock control, batch tracking, low-stock warnings, and expiry management</p>
                </div>
                <a href="medicines.php" class="btn btn-primary rounded-pill px-4 shadow-sm"><i class="bi bi-plus-lg me-1"></i> Add Medicine</a>
            </div>

            <!-- Alert KPIs -->
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="card card-custom card-kpi p-3">
                        <small class="text-muted fw-bold text-uppercase fs-8">Total Catalog Items</small>
                        <h2 class="fw-bold mb-0 text-primary"><?= $cntTotal ?></h2>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-custom card-kpi card-kpi-warning p-3">
                        <small class="text-muted fw-bold text-uppercase fs-8">Low Stock Alerts</small>
                        <h2 class="fw-bold mb-0 text-warning"><?= $cntLow ?></h2>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-custom card-kpi card-kpi-danger p-3">
                        <small class="text-muted fw-bold text-uppercase fs-8">Expired Medicines</small>
                        <h2 class="fw-bold mb-0 text-danger"><?= $cntExpired ?></h2>
                    </div>
                </div>
            </div>

            <!-- Medicines Stock Table -->
            <div class="card card-custom border-0 shadow-sm">
                <div class="card-header bg-body border-0 py-3 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0"><i class="bi bi-capsule me-2 text-primary"></i> Inventory Overview</h5>
                    <a href="low_stock.php" class="btn btn-sm btn-outline-danger rounded-pill"><i class="bi bi-exclamation-triangle-fill me-1"></i> View Alerts</a>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 fs-7">
                        <thead class="table-light text-uppercase">
                            <tr>
                                <th>Code</th>
                                <th>Medicine Name</th>
                                <th>Category</th>
                                <th>Batch No.</th>
                                <th>Stock</th>
                                <th>Unit Price</th>
                                <th>Expiry Date</th>
                                <th>Stock Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($medicines as $med): ?>
                                <?php
                                $isExpired = (strtotime($med['expiry_date']) <= time());
                                $isLow = ($med['quantity'] <= $med['min_stock_alert']);
                                ?>
                                <tr>
                                    <td class="fw-bold text-primary"><?= htmlspecialchars($med['medicine_code']) ?></td>
                                    <td class="fw-bold"><?= htmlspecialchars($med['name']) ?></td>
                                    <td><span class="badge bg-secondary"><?= htmlspecialchars($med['category']) ?></span></td>
                                    <td><code><?= htmlspecialchars($med['batch_number']) ?></code></td>
                                    <td class="fw-bold fs-6"><?= $med['quantity'] ?> units</td>
                                    <td><?= formatCurrency($med['price']) ?></td>
                                    <td><?= formatDate($med['expiry_date'], 'd M Y') ?></td>
                                    <td>
                                        <?php if ($isExpired): ?>
                                            <span class="badge bg-danger">EXPIRED</span>
                                        <?php elseif ($isLow): ?>
                                            <span class="badge bg-warning text-dark animate-pulse">LOW STOCK</span>
                                        <?php else: ?>
                                            <span class="badge bg-success">In Stock</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
