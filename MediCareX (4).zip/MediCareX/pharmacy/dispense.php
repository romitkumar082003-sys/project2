<?php
// MediCareX - Prescription Medicine Dispensing Desk
// Developed by Romit Kumar

$pageTitle = 'Dispense Medicines';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole(['Pharmacist', 'Admin']);

$user = getCurrentUser();
$pdo = getDBConnection();

$prescriptions = $pdo->query("
    SELECT rx.*, u_p.name as patient_name, p.patient_code, u_d.name as doctor_name
    FROM prescriptions rx
    JOIN patients p ON rx.patient_id = p.id
    JOIN users u_p ON p.user_id = u_p.id
    JOIN doctors d ON rx.doctor_id = d.id
    JOIN users u_d ON d.user_id = u_d.id
    ORDER BY rx.created_at DESC
")->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold mb-0">Dispense Prescription Medicines</h3>
            </div>

            <div class="card card-custom border-0 shadow-sm">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0 fs-7">
                            <thead class="table-light text-uppercase">
                                <tr>
                                    <th>Rx ID</th>
                                    <th>Patient Name</th>
                                    <th>Patient Code</th>
                                    <th>Prescribed By</th>
                                    <th>Issued Date</th>
                                    <th class="text-end">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($prescriptions)): ?>
                                    <tr><td colspan="6" class="text-center py-5 text-muted">No prescriptions pending dispensing.</td></tr>
                                <?php else: ?>
                                    <?php foreach ($prescriptions as $rx): ?>
                                        <tr>
                                            <td class="fw-bold text-primary">Rx #<?= $rx['id'] ?></td>
                                            <td class="fw-bold"><?= htmlspecialchars($rx['patient_name']) ?></td>
                                            <td><?= htmlspecialchars($rx['patient_code']) ?></td>
                                            <td><?= htmlspecialchars($rx['doctor_name']) ?></td>
                                            <td><?= formatDate($rx['created_at']) ?></td>
                                            <td class="text-end">
                                                <a href="<?= get_base_url() ?>/print_prescription.php?id=<?= $rx['id'] ?>" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill">
                                                    <i class="bi bi-file-earmark-medical me-1"></i> View Prescription
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
