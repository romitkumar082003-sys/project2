<?php
// MediCareX - Medicine Inventory CRUD
// Developed by Romit Kumar

$pageTitle = 'Medicine Inventory';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

requireRole(['Pharmacist', 'Admin']);

$user = getCurrentUser();
$pdo = getDBConnection();

// Add Medicine
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_medicine'])) {
    validateCSRFOrDie();

    $name = cleanInput($_POST['name'] ?? '');
    $category = cleanInput($_POST['category'] ?? '');
    $manufacturer = cleanInput($_POST['manufacturer'] ?? '');
    $batch_number = cleanInput($_POST['batch_number'] ?? '');
    $quantity = intval($_POST['quantity'] ?? 0);
    $min_stock_alert = intval($_POST['min_stock_alert'] ?? 10);
    $price = floatval($_POST['price'] ?? 0);
    $expiry_date = cleanInput($_POST['expiry_date'] ?? '');

    $med_code = generateCode('MED', 'medicines', 'medicine_code');

    $ins = $pdo->prepare("
        INSERT INTO medicines (medicine_code, name, category, manufacturer, batch_number, quantity, min_stock_alert, price, expiry_date) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $ins->execute([$med_code, $name, $category, $manufacturer, $batch_number, $quantity, $min_stock_alert, $price, $expiry_date]);

    logAudit($user['id'], $user['name'], $user['role_name'], 'MEDICINE_ADD', "Added new medicine {$name} (Code: {$med_code}).");
    setFlash('success', "Medicine added successfully! Code: {$med_code}");
    header("Location: medicines.php");
    exit();
}

// Edit Medicine
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_medicine'])) {
    validateCSRFOrDie();
    $id = intval($_POST['med_id'] ?? 0);
    $name = cleanInput($_POST['name'] ?? '');
    $category = cleanInput($_POST['category'] ?? '');
    $manufacturer = cleanInput($_POST['manufacturer'] ?? '');
    $batch_number = cleanInput($_POST['batch_number'] ?? '');
    $quantity = intval($_POST['quantity'] ?? 0);
    $min_stock_alert = intval($_POST['min_stock_alert'] ?? 10);
    $price = floatval($_POST['price'] ?? 0);
    $expiry_date = cleanInput($_POST['expiry_date'] ?? '');

    $upd = $pdo->prepare("
        UPDATE medicines 
        SET name = ?, category = ?, manufacturer = ?, batch_number = ?, quantity = ?, min_stock_alert = ?, price = ?, expiry_date = ? 
        WHERE id = ?
    ");
    $upd->execute([$name, $category, $manufacturer, $batch_number, $quantity, $min_stock_alert, $price, $expiry_date, $id]);

    logAudit($user['id'], $user['name'], $user['role_name'], 'MEDICINE_EDIT', "Updated medicine ID {$id} ({$name}).");
    setFlash('success', "Medicine '{$name}' updated successfully!");
    header("Location: medicines.php");
    exit();
}

// Delete Medicine
if (isset($_GET['action']) && $_GET['action'] === 'delete') {
    $id = intval($_GET['id'] ?? 0);
    $del = $pdo->prepare("DELETE FROM medicines WHERE id = ?");
    $del->execute([$id]);
    setFlash('warning', "Medicine item deleted from inventory.");
    header("Location: medicines.php");
    exit();
}

$medicines = $pdo->query("SELECT * FROM medicines ORDER BY name ASC")->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <?php displayFlash(); ?>

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1">Medicine Catalog & Stock</h3>
                    <p class="text-muted mb-0">Manage pharmaceutical inventory items and batch details</p>
                </div>
                <button type="button" class="btn btn-primary rounded-pill px-4 shadow-sm" data-bs-toggle="modal" data-bs-target="#addMedModal">
                    <i class="bi bi-plus-lg me-1"></i> Add New Medicine
                </button>
            </div>

            <div class="card card-custom border-0 shadow-sm">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0 fs-7">
                            <thead class="table-light text-uppercase">
                                <tr>
                                    <th>Code</th>
                                    <th>Medicine Name</th>
                                    <th>Category</th>
                                    <th>Manufacturer</th>
                                    <th>Batch No.</th>
                                    <th>Stock</th>
                                    <th>Unit Price</th>
                                    <th>Expiry</th>
                                    <th class="text-end">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($medicines as $med): ?>
                                    <tr>
                                        <td class="fw-bold text-primary"><?= htmlspecialchars($med['medicine_code']) ?></td>
                                        <td class="fw-bold"><?= htmlspecialchars($med['name']) ?></td>
                                        <td><span class="badge bg-secondary"><?= htmlspecialchars($med['category']) ?></span></td>
                                        <td><?= htmlspecialchars($med['manufacturer']) ?></td>
                                        <td><code><?= htmlspecialchars($med['batch_number']) ?></code></td>
                                        <td class="fw-bold fs-6"><?= $med['quantity'] ?></td>
                                        <td><?= formatCurrency($med['price']) ?></td>
                                        <td><?= formatDate($med['expiry_date'], 'd M Y') ?></td>
                                        <td class="text-end">
                                            <div class="btn-group btn-group-sm">
                                                <button type="button" class="btn btn-outline-primary rounded-pill px-3 me-1" onclick="openEditMedModal(<?= htmlspecialchars(json_encode($med)) ?>)">
                                                    <i class="bi bi-pencil-square me-1"></i> Edit
                                                </button>
                                                <a href="medicines.php?action=delete&id=<?= $med['id'] ?>" class="btn btn-outline-danger rounded-pill px-2" onclick="return confirm('Delete this medicine?')">
                                                    <i class="bi bi-trash"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add Medicine Modal -->
        <div class="modal fade" id="addMedModal" tabindex="-1">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-capsule me-2"></i> Add Medicine Item</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST" action="">
                        <?= renderCSRFField() ?>
                        <input type="hidden" name="add_medicine" value="1">

                        <div class="modal-body p-4">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Medicine Name *</label>
                                    <input type="text" name="name" class="form-control" placeholder="e.g. Paracetamol 650mg" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Category *</label>
                                    <input type="text" name="category" class="form-control" placeholder="e.g. Analgesic / Antibiotic" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Manufacturer</label>
                                    <input type="text" name="manufacturer" class="form-control" placeholder="e.g. Cipla / Sun Pharma">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Batch Number *</label>
                                    <input type="text" name="batch_number" class="form-control" placeholder="e.g. BAT-2026X" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Initial Stock *</label>
                                    <input type="number" name="quantity" class="form-control" min="0" value="100" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Low Alert Level</label>
                                    <input type="number" name="min_stock_alert" class="form-control" min="1" value="15">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Price per Unit (₹) *</label>
                                    <input type="number" step="0.01" name="price" class="form-control" placeholder="25.00" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Expiry Date *</label>
                                    <input type="date" name="expiry_date" class="form-control" required>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-top-0 pt-0">
                            <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary rounded-pill px-4 shadow">Add to Inventory</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Edit Medicine Modal -->
        <div class="modal fade" id="editMedModal" tabindex="-1">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-dark text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-pencil-square me-2"></i> Edit Medicine & Stock</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST" action="">
                        <?= renderCSRFField() ?>
                        <input type="hidden" name="edit_medicine" value="1">
                        <input type="hidden" name="med_id" id="edit_med_id">

                        <div class="modal-body p-4">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Medicine Name *</label>
                                    <input type="text" name="name" id="edit_name" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Category *</label>
                                    <input type="text" name="category" id="edit_category" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Manufacturer</label>
                                    <input type="text" name="manufacturer" id="edit_manufacturer" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Batch Number *</label>
                                    <input type="text" name="batch_number" id="edit_batch" class="form-control" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Stock Quantity (Units) *</label>
                                    <input type="number" name="quantity" id="edit_quantity" class="form-control" min="0" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Low Alert Threshold</label>
                                    <input type="number" name="min_stock_alert" id="edit_min_alert" class="form-control" min="1" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Price per Unit (₹) *</label>
                                    <input type="number" step="0.01" name="price" id="edit_price" class="form-control" required>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label fw-semibold">Expiry Date *</label>
                                    <input type="date" name="expiry_date" id="edit_expiry" class="form-control" required>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-top-0 pt-0">
                            <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary rounded-pill px-4 shadow">Update Medicine</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <script>
        function openEditMedModal(med) {
            document.getElementById('edit_med_id').value = med.id;
            document.getElementById('edit_name').value = med.name;
            document.getElementById('edit_category').value = med.category;
            document.getElementById('edit_manufacturer').value = med.manufacturer;
            document.getElementById('edit_batch').value = med.batch_number;
            document.getElementById('edit_quantity').value = med.quantity;
            document.getElementById('edit_min_alert').value = med.min_stock_alert;
            document.getElementById('edit_price').value = parseFloat(med.price).toFixed(2);
            document.getElementById('edit_expiry').value = med.expiry_date;
            new bootstrap.Modal(document.getElementById('editMedModal')).show();
        }
        </script>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
