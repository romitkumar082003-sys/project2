<?php
// MediCareX - Pharmacy Alert Center (Low Stock & Expiry Tracking)
// Developed by Romit Kumar

$pageTitle = 'Stock & Expiry Alerts';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole(['Pharmacist', 'Admin']);

$user = getCurrentUser();
$pdo = getDBConnection();

// Low Stock Items
$lowStockMeds = $pdo->query("SELECT * FROM medicines WHERE quantity <= min_stock_alert ORDER BY quantity ASC")->fetchAll();

// Expired & Near Expiry Items (within 30 days)
$expiredMeds = $pdo->query("SELECT * FROM medicines WHERE expiry_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) ORDER BY expiry_date ASC")->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1"><i class="bi bi-exclamation-triangle-fill text-danger me-2"></i> Low Stock & Expiry Alert Center</h3>
                    <p class="text-muted mb-0">Automated warning system for stock reorders and pharmaceutical expiration monitoring</p>
                </div>
            </div>

            <!-- Low Stock Table -->
            <div class="card card-custom border-0 shadow-sm mb-4">
                <div class="card-header bg-warning bg-opacity-10 border-0 py-3">
                    <h5 class="fw-bold text-dark mb-0"><i class="bi bi-box-seam me-2 text-warning"></i> Reorder Required: Low Stock Items</h5>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 fs-7">
                        <thead class="table-light text-uppercase">
                            <tr>
                                <th>Code</th>
                                <th>Medicine Name</th>
                                <th>Category</th>
                                <th>Current Stock</th>
                                <th>Min Threshold Alert</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($lowStockMeds)): ?>
                                <tr><td colspan="6" class="text-center py-4 text-muted"><i class="bi bi-check-circle-fill text-success fs-3 d-block mb-1"></i> All medicine items are adequately stocked!</td></tr>
                            <?php else: ?>
                                <?php foreach ($lowStockMeds as $m): ?>
                                    <tr>
                                        <td class="fw-bold text-primary"><?= htmlspecialchars($m['medicine_code']) ?></td>
                                        <td class="fw-bold"><?= htmlspecialchars($m['name']) ?></td>
                                        <td><?= htmlspecialchars($m['category']) ?></td>
                                        <td><span class="fw-bold text-danger fs-6"><?= $m['quantity'] ?> units</span></td>
                                        <td><?= $m['min_stock_alert'] ?> units</td>
                                        <td><span class="badge bg-warning text-dark fw-bold animate-pulse">LOW STOCK</span></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Expired / Near Expiry Table -->
            <div class="card card-custom border-0 shadow-sm">
                <div class="card-header bg-danger bg-opacity-10 border-0 py-3">
                    <h5 class="fw-bold text-danger mb-0"><i class="bi bi-calendar-x me-2"></i> Expiration Warning Center</h5>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 fs-7">
                        <thead class="table-light text-uppercase">
                            <tr>
                                <th>Code</th>
                                <th>Medicine Name</th>
                                <th>Batch No.</th>
                                <th>Stock</th>
                                <th>Expiry Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($expiredMeds)): ?>
                                <tr><td colspan="6" class="text-center py-4 text-muted"><i class="bi bi-check-circle-fill text-success fs-3 d-block mb-1"></i> No expired or near-expiry medicines found.</td></tr>
                            <?php else: ?>
                                <?php foreach ($expiredMeds as $m): ?>
                                    <?php $isPast = (strtotime($m['expiry_date']) <= time()); ?>
                                    <tr>
                                        <td class="fw-bold text-primary"><?= htmlspecialchars($m['medicine_code']) ?></td>
                                        <td class="fw-bold"><?= htmlspecialchars($m['name']) ?></td>
                                        <td><code><?= htmlspecialchars($m['batch_number']) ?></code></td>
                                        <td><?= $m['quantity'] ?> units</td>
                                        <td class="fw-bold"><?= formatDate($m['expiry_date'], 'd M Y') ?></td>
                                        <td>
                                            <?php if ($isPast): ?>
                                                <span class="badge bg-danger">EXPIRED</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning text-dark">EXPIRING SOON</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
