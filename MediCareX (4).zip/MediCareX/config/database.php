<?php
// MediCareX - Smart Hospital Management System
// Zero-Config Database Connection (SQLite Primary / MySQL Compatible)
// Developed by Romit Kumar

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('APP_NAME', 'MediCareX');
define('APP_TAGLINE', 'Smart Healthcare. Better Care.');
define('DEVELOPER_NAME', 'Developed by Romit Kumar');

function getDBConnection() {
    static $pdo = null;
    if ($pdo === null) {
        $sqliteFile = __DIR__ . '/../database/medicarex.sqlite';

        // Auto-initialize SQLite database if not present
        if (!file_exists($sqliteFile)) {
            require_once __DIR__ . '/../database/init_sqlite.php';
        }

        try {
            $pdo = new PDO('sqlite:' . $sqliteFile, null, null, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
            // Enable foreign keys, WAL mode, busy timeout & synchronous in SQLite
            $pdo->exec("PRAGMA foreign_keys = ON;");
            $pdo->exec("PRAGMA busy_timeout = 10000;");
            $pdo->exec("PRAGMA journal_mode = WAL;");
            $pdo->exec("PRAGMA synchronous = NORMAL;");

            // Register MySQL compatible functions in SQLite
            $pdo->sqliteCreateFunction('CURDATE', function() { return date('Y-m-d'); });
            $pdo->sqliteCreateFunction('NOW', function() { return date('Y-m-d H:i:s'); });
        } catch (PDOException $e) {
            die("<div style='font-family: sans-serif; max-width: 600px; margin: 50px auto; padding: 25px; border-radius: 12px; background: #fee2e2; color: #991b1b;'>
                <h3>Database Error</h3>
                <p>Unable to load local SQLite database.</p>
                <small>" . htmlspecialchars($e->getMessage()) . "</small>
            </div>");
        }
    }
    return $pdo;
}

// Global base URL helper
function get_base_url() {
    $script_name = $_SERVER['SCRIPT_NAME'] ?? '';
    $pos = strpos($script_name, '/MediCareX');
    if ($pos !== false) {
        return substr($script_name, 0, $pos + 10);
    }
    return '';
}
