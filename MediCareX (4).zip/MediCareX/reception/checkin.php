<?php
// MediCareX - Receptionist Check-In Workspace
// Developed by Romit Kumar

$pageTitle = 'Patient Check-In Desk';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole('Receptionist');

$user = getCurrentUser();
$pdo = getDBConnection();

// Check-in trigger
if (isset($_GET['action']) && $_GET['action'] === 'checkin') {
    $apt_id = intval($_GET['id'] ?? 0);
    
    $upd = $pdo->prepare("UPDATE appointments SET status = 'Checked In' WHERE id = ?");
    $upd->execute([$apt_id]);

    $aptInfo = $pdo->prepare("
        SELECT a.appointment_code, a.token_number, u_p.name as patient_name, u_d.id as doctor_user_id
        FROM appointments a
        JOIN patients p ON a.patient_id = p.id
        JOIN users u_p ON p.user_id = u_p.id
        JOIN doctors d ON a.doctor_id = d.id
        JOIN users u_d ON d.user_id = u_d.id
        WHERE a.id = ?
    ");
    $aptInfo->execute([$apt_id]);
    $info = $aptInfo->fetch();

    if ($info) {
        addNotification($info['doctor_user_id'], 'Patient Checked In', "Patient {$info['patient_name']} has checked in. Token: {$info['token_number']}.", 'doctor/index.php');
        logAudit($user['id'], $user['name'], 'Receptionist', 'PATIENT_CHECKIN', "Checked in Patient {$info['patient_name']} (Token {$info['token_number']}).");
    }

    setFlash('success', "Patient checked in successfully! Moved to Doctor's live OPD queue.");
    header("Location: checkin.php");
    exit();
}

$today = date('Y-m-d');
$query = "
    SELECT a.*, p.patient_code, u_p.name as patient_name, u_p.phone as patient_phone, u_d.name as doctor_name, dep.dept_name
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    JOIN users u_p ON p.user_id = u_p.id
    JOIN doctors d ON a.doctor_id = d.id
    JOIN users u_d ON d.user_id = u_d.id
    JOIN departments dep ON a.department_id = dep.id
    WHERE a.appointment_date = '{$today}'
    ORDER BY a.time_slot ASC
";
$appointments = $pdo->query($query)->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <?php displayFlash(); ?>

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1">Today's Check-In Desk</h3>
                    <p class="text-muted mb-0">Confirm patient arrival and assign active queue tokens</p>
                </div>
            </div>

            <div class="card card-custom border-0 shadow-sm">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light fs-7 text-uppercase">
                                <tr>
                                    <th>Token</th>
                                    <th>Appointment Code</th>
                                    <th>Patient Name</th>
                                    <th>Phone</th>
                                    <th>Assigned Doctor</th>
                                    <th>Slot</th>
                                    <th>Status</th>
                                    <th class="text-end">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($appointments)): ?>
                                    <tr>
                                        <td colspan="8" class="text-center py-5 text-muted">
                                            <i class="bi bi-calendar-x fs-1 d-block mb-2"></i>
                                            No appointments scheduled for today.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($appointments as $apt): ?>
                                        <tr>
                                            <td><span class="badge bg-primary px-3 py-2 fs-6"><?= htmlspecialchars($apt['token_number']) ?></span></td>
                                            <td class="fw-bold text-primary"><?= htmlspecialchars($apt['appointment_code']) ?></td>
                                            <td>
                                                <div class="fw-bold"><?= htmlspecialchars($apt['patient_name']) ?></div>
                                                <small class="text-muted"><?= htmlspecialchars($apt['patient_code']) ?></small>
                                            </td>
                                            <td><?= htmlspecialchars($apt['patient_phone']) ?></td>
                                            <td>
                                                <div class="fw-semibold"><?= htmlspecialchars($apt['doctor_name']) ?></div>
                                                <small class="text-muted"><?= htmlspecialchars($apt['dept_name']) ?></small>
                                            </td>
                                            <td class="fw-semibold"><?= htmlspecialchars($apt['time_slot']) ?></td>
                                            <td><?= renderStatusBadge($apt['status']) ?></td>
                                            <td class="text-end">
                                                <?php if (in_array($apt['status'], ['Pending', 'Confirmed'])): ?>
                                                    <a href="checkin.php?action=checkin&id=<?= $apt['id'] ?>" class="btn btn-sm btn-warning rounded-pill px-3 shadow-sm">
                                                        <i class="bi bi-box-arrow-in-right me-1"></i> Check In Patient
                                                    </a>
                                                <?php else: ?>
                                                    <span class="text-muted fs-7">Checked In</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
