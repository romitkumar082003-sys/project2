<?php
// MediCareX - Reception Billing Desk
// Developed by Romit Kumar

$pageTitle = 'Reception Billing Desk';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole(['Receptionist', 'Admin']);

$user = getCurrentUser();
$pdo = getDBConnection();

$invoices = $pdo->query("
    SELECT inv.*, p.patient_code, u.name as patient_name, u.phone 
    FROM invoices inv
    JOIN patients p ON inv.patient_id = p.id
    JOIN users u ON p.user_id = u.id
    ORDER BY inv.id DESC
")->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold mb-0">Billing & Collections Desk</h3>
            </div>

            <div class="card card-custom border-0 shadow-sm">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light fs-7 text-uppercase">
                                <tr>
                                    <th>Invoice Code</th>
                                    <th>Patient Name</th>
                                    <th>Phone</th>
                                    <th>Grand Total</th>
                                    <th>Payment Status</th>
                                    <th>Date</th>
                                    <th class="text-end">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($invoices)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center py-5 text-muted">
                                            <i class="bi bi-receipt fs-1 d-block mb-2"></i>
                                            No billing invoices recorded.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($invoices as $inv): ?>
                                        <tr>
                                            <td class="fw-bold text-primary"><?= htmlspecialchars($inv['invoice_code']) ?></td>
                                            <td class="fw-bold"><?= htmlspecialchars($inv['patient_name']) ?></td>
                                            <td><?= htmlspecialchars($inv['phone']) ?></td>
                                            <td class="fw-bold text-dark fs-6"><?= formatCurrency($inv['grand_total']) ?></td>
                                            <td><?= renderStatusBadge($inv['payment_status']) ?></td>
                                            <td><?= formatDate($inv['created_at']) ?></td>
                                            <td class="text-end">
                                                <a href="<?= get_base_url() ?>/print_invoice.php?id=<?= $inv['id'] ?>" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill">
                                                    <i class="bi bi-printer me-1"></i> Print Invoice
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
