<?php
// MediCareX - Fast Walk-In Patient Registration (Reception)
// Developed by Romit Kumar

$pageTitle = 'Walk-In Patient Registration';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

requireRole(['Receptionist', 'Admin']);

$user = getCurrentUser();
$pdo = getDBConnection();

$errorMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validateCSRFOrDie();

    $name = cleanInput($_POST['name'] ?? '');
    $email = cleanInput($_POST['email'] ?? '');
    $phone = cleanInput($_POST['phone'] ?? '');
    $dob = cleanInput($_POST['dob'] ?? '');
    $gender = cleanInput($_POST['gender'] ?? 'Male');
    $blood_group = cleanInput($_POST['blood_group'] ?? 'O+');
    $address = cleanInput($_POST['address'] ?? '');
    $emergency_contact = cleanInput($_POST['emergency_contact'] ?? '');

    if (empty($email)) {
        $email = strtolower(str_replace(' ', '', $name)) . rand(100, 999) . '@patient.local';
    }

    $chk = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
    $chk->execute([$email]);
    if ($chk->fetchColumn() > 0) {
        $errorMsg = "An account with this email address already exists.";
    } else {
        try {
            $pdo->beginTransaction();

            $user_code = generateCode('PAT', 'users', 'user_code');
            $hash = password_hash('password123', PASSWORD_DEFAULT);

            $stmt = $pdo->prepare("
                INSERT INTO users (user_code, name, email, password, role_id, phone, status) 
                VALUES (?, ?, ?, ?, 7, ?, 'Active')
            ");
            $stmt->execute([$user_code, $name, $email, $hash, $phone]);
            $user_id = $pdo->lastInsertId();

            $stmtPat = $pdo->prepare("
                INSERT INTO patients (user_id, patient_code, dob, gender, blood_group, address, emergency_contact) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmtPat->execute([$user_id, $user_code, $dob, $gender, $blood_group, $address, $emergency_contact]);

            $pdo->commit();

            logAudit($user['id'], $user['name'], $user['role_name'], 'PATIENT_WALKIN_REGISTER', "Registered walk-in patient {$user_code}.");
            setFlash('success', "Patient registered successfully! Patient ID Code: {$user_code}. Default Password: password123");
            header("Location: register_patient.php");
            exit();
        } catch (Exception $e) {
            $pdo->rollBack();
            $errorMsg = "Database error: " . $e->getMessage();
        }
    }
}

$recentPatients = $pdo->query("
    SELECT p.*, u.name, u.email, u.phone 
    FROM patients p 
    JOIN users u ON p.user_id = u.id 
    ORDER BY p.id DESC LIMIT 5
")->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <?php displayFlash(); ?>

            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold mb-0">Walk-In Patient Registration</h3>
            </div>

            <div class="row g-4">
                <div class="col-lg-7">
                    <div class="card card-custom p-4 border-0 shadow-sm">
                        <?php if ($errorMsg): ?>
                            <div class="alert alert-danger border-0 shadow-sm mb-3"><?= htmlspecialchars($errorMsg) ?></div>
                        <?php endif; ?>

                        <form method="POST" action="">
                            <?= renderCSRFField() ?>
                            <div class="row g-3 mb-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Full Name *</label>
                                    <input type="text" name="name" class="form-control" placeholder="Patient Name" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Phone Number *</label>
                                    <input type="text" name="phone" class="form-control" placeholder="+91 9876543210" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Email Address (Optional)</label>
                                    <input type="email" name="email" class="form-control" placeholder="Auto-generated if empty">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Date of Birth</label>
                                    <input type="date" name="dob" class="form-control">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Gender</label>
                                    <select name="gender" class="form-select">
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Blood Group</label>
                                    <select name="blood_group" class="form-select">
                                        <option value="A+">A+</option>
                                        <option value="A-">A-</option>
                                        <option value="B+">B+</option>
                                        <option value="B-">B-</option>
                                        <option value="AB+">AB+</option>
                                        <option value="AB-">AB-</option>
                                        <option value="O+">O+</option>
                                        <option value="O-">O-</option>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <label class="form-label fw-semibold">Address</label>
                                    <input type="text" name="address" class="form-control" placeholder="Residential location">
                                </div>
                            </div>
                            <div class="pt-3 border-top text-end">
                                <button type="submit" class="btn btn-primary rounded-pill px-4 shadow-sm">
                                    <i class="bi bi-person-check-fill me-1"></i> Register Walk-In Patient
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="col-lg-5">
                    <div class="card card-custom p-4 border-0 shadow-sm">
                        <h5 class="fw-bold mb-3">Recently Registered Patients</h5>
                        <ul class="list-group list-group-flush fs-7">
                            <?php foreach ($recentPatients as $rp): ?>
                                <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                                    <div>
                                        <div class="fw-bold"><?= htmlspecialchars($rp['name']) ?></div>
                                        <small class="text-muted"><?= htmlspecialchars($rp['patient_code']) ?> &bull; <?= htmlspecialchars($rp['phone']) ?></small>
                                    </div>
                                    <span class="badge bg-primary bg-opacity-10 text-primary"><?= htmlspecialchars($rp['blood_group']) ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
