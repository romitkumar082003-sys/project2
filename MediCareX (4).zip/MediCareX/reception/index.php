<?php
// MediCareX - Receptionist Desk Overview
// Developed by Romit Kumar

$pageTitle = 'Reception Desk';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole('Receptionist');

$user = getCurrentUser();
$pdo = getDBConnection();

$today = date('Y-m-d');

// Stats
$cntToday = $pdo->query("SELECT COUNT(*) FROM appointments WHERE appointment_date = '{$today}'")->fetchColumn();
$cntChecked = $pdo->query("SELECT COUNT(*) FROM appointments WHERE appointment_date = '{$today}' AND status = 'Checked In'")->fetchColumn();
$cntAdmitted = $pdo->query("SELECT COUNT(*) FROM admissions WHERE status = 'Admitted'")->fetchColumn();
$cntBeds = $pdo->query("SELECT COUNT(*) FROM beds WHERE status = 'Available'")->fetchColumn();

$todayAppointments = $pdo->query("
    SELECT a.*, p.patient_code, u_p.name as patient_name, u_d.name as doctor_name, dep.dept_name
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    JOIN users u_p ON p.user_id = u_p.id
    JOIN doctors d ON a.doctor_id = d.id
    JOIN users u_d ON d.user_id = u_d.id
    JOIN departments dep ON a.department_id = dep.id
    WHERE a.appointment_date = '{$today}'
    ORDER BY a.time_slot ASC
")->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <?php displayFlash(); ?>

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1">Reception & OPD Check-In Desk</h3>
                    <p class="text-muted mb-0">Manage walk-ins, patient arrivals, token check-ins, and inpatient admissions</p>
                </div>
                <div class="d-flex gap-2">
                    <a href="register_patient.php" class="btn btn-outline-primary rounded-pill"><i class="bi bi-person-plus-fill me-1"></i> Register Walk-In</a>
                    <a href="checkin.php" class="btn btn-primary rounded-pill px-4 shadow-sm"><i class="bi bi-box-arrow-in-right me-1"></i> Check-In Desk</a>
                </div>
            </div>

            <!-- KPI Summary Cards -->
            <div class="row g-3 mb-4">
                <div class="col-md-3">
                    <div class="card card-custom card-kpi p-3">
                        <small class="text-muted fw-bold text-uppercase fs-8">Today's Total OPD</small>
                        <h2 class="fw-bold mb-0 text-primary"><?= $cntToday ?></h2>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card card-custom card-kpi card-kpi-warning p-3">
                        <small class="text-muted fw-bold text-uppercase fs-8">Checked In OPD</small>
                        <h2 class="fw-bold mb-0 text-warning"><?= $cntChecked ?></h2>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card card-custom card-kpi card-kpi-info p-3">
                        <small class="text-muted fw-bold text-uppercase fs-8">Active Admissions</small>
                        <h2 class="fw-bold mb-0 text-info"><?= $cntAdmitted ?></h2>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card card-custom card-kpi card-kpi-success p-3">
                        <small class="text-muted fw-bold text-uppercase fs-8">Available Beds</small>
                        <h2 class="fw-bold mb-0 text-success"><?= $cntBeds ?></h2>
                    </div>
                </div>
            </div>

            <!-- Today's Appointments & Quick Check-in -->
            <div class="card card-custom border-0 shadow-sm mb-4">
                <div class="card-header bg-body border-0 py-3 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0"><i class="bi bi-calendar-check me-2 text-primary"></i> Today's OPD Roster & Check-In</h5>
                    <a href="checkin.php" class="btn btn-sm btn-outline-primary rounded-pill">Open Check-In Workspace</a>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light fs-7 text-uppercase">
                            <tr>
                                <th>Token</th>
                                <th>Code</th>
                                <th>Patient Name</th>
                                <th>Doctor</th>
                                <th>Time Slot</th>
                                <th>Status</th>
                                <th class="text-end">Quick Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($todayAppointments)): ?>
                                <tr>
                                    <td colspan="7" class="text-center py-5 text-muted">
                                        <i class="bi bi-calendar-x fs-1 d-block mb-2"></i>
                                        No appointments scheduled for today.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($todayAppointments as $apt): ?>
                                    <tr>
                                        <td><span class="badge bg-primary px-3 py-2 fs-7"><?= htmlspecialchars($apt['token_number']) ?></span></td>
                                        <td class="fw-bold text-primary"><?= htmlspecialchars($apt['appointment_code']) ?></td>
                                        <td>
                                            <div class="fw-bold"><?= htmlspecialchars($apt['patient_name']) ?></div>
                                            <small class="text-muted"><?= htmlspecialchars($apt['patient_code']) ?></small>
                                        </td>
                                        <td>
                                            <div><?= htmlspecialchars($apt['doctor_name']) ?></div>
                                            <small class="text-muted"><?= htmlspecialchars($apt['dept_name']) ?></small>
                                        </td>
                                        <td class="fw-semibold"><?= htmlspecialchars($apt['time_slot']) ?></td>
                                        <td><?= renderStatusBadge($apt['status']) ?></td>
                                        <td class="text-end">
                                            <?php if (in_array($apt['status'], ['Pending', 'Confirmed'])): ?>
                                                <a href="checkin.php?action=checkin&id=<?= $apt['id'] ?>" class="btn btn-sm btn-warning rounded-pill px-3 shadow-sm">
                                                    <i class="bi bi-box-arrow-in-right me-1"></i> Check In
                                                </a>
                                            <?php else: ?>
                                                <span class="text-muted fs-7">Processed</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
