<?php
// MediCareX - Receptionist Walk-in Appointment Desk
// Developed by Romit Kumar

$pageTitle = 'Reception Appointment Desk';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

requireRole(['Receptionist', 'Admin']);

$user = getCurrentUser();
$pdo = getDBConnection();

$patients = $pdo->query("SELECT p.id, p.patient_code, p.blood_group, u.name, u.phone FROM patients p JOIN users u ON p.user_id = u.id ORDER BY u.name ASC")->fetchAll();
$departments = $pdo->query("SELECT * FROM departments WHERE status = 'Active' ORDER BY id ASC")->fetchAll();
$doctors = $pdo->query("
    SELECT d.*, u.name, u.phone, dep.dept_name, dep.icon as dept_icon 
    FROM doctors d 
    JOIN users u ON d.user_id = u.id 
    JOIN departments dep ON d.department_id = dep.id 
    ORDER BY dep.dept_name ASC, u.name ASC
")->fetchAll();

$errorMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validateCSRFOrDie();

    $patient_id = intval($_POST['patient_id'] ?? 0);
    $department_id = intval($_POST['department_id'] ?? 0);
    $doctor_id = intval($_POST['doctor_id'] ?? 0);
    $appointment_date = cleanInput($_POST['appointment_date'] ?? date('Y-m-d'));
    $time_slot = cleanInput($_POST['time_slot'] ?? '09:30 AM');
    $reason = cleanInput($_POST['reason'] ?? 'Walk-in OPD Consultation');

    if (!$patient_id || !$doctor_id) {
        $errorMsg = "Please select both a registered patient and an attending doctor.";
    } else {
        if (!$department_id) {
            $dStmt = $pdo->prepare("SELECT department_id FROM doctors WHERE id = ?");
            $dStmt->execute([$doctor_id]);
            $department_id = intval($dStmt->fetchColumn() ?: 1);
        }

        // Double booking validation
        $chk = $pdo->prepare("SELECT COUNT(*) FROM appointments WHERE doctor_id = ? AND appointment_date = ? AND time_slot = ? AND status != 'Cancelled'");
        $chk->execute([$doctor_id, $appointment_date, $time_slot]);

        if ($chk->fetchColumn() > 0) {
            $errorMsg = "This doctor already has a confirmed booking for {$appointment_date} at {$time_slot}. Please select another time slot.";
        } else {
            $tokStmt = $pdo->prepare("SELECT COUNT(*) FROM appointments WHERE doctor_id = ? AND appointment_date = ?");
            $tokStmt->execute([$doctor_id, $appointment_date]);
            $tokNum = $tokStmt->fetchColumn() + 1;
            $token_number = 'A-' . str_pad($tokNum, 3, '0', STR_PAD_LEFT);

            $apt_code = generateCode('APT', 'appointments', 'appointment_code');

            $ins = $pdo->prepare("
                INSERT INTO appointments (appointment_code, patient_id, doctor_id, department_id, appointment_date, time_slot, token_number, reason, status) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Confirmed')
            ");
            $ins->execute([$apt_code, $patient_id, $doctor_id, $department_id, $appointment_date, $time_slot, $token_number, $reason]);

            logAudit($user['id'], $user['name'], $user['role_name'], 'PATIENT_APPOINTMENT_WALKIN', "Booked walk-in appointment {$apt_code} (Token {$token_number}).");
            setFlash('success', "Walk-in appointment issued! Queue Token: <strong>{$token_number}</strong> (Code: <strong>{$apt_code}</strong>).");
            header("Location: checkin.php");
            exit();
        }
    }
}

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-3 p-md-4">
            <?php displayFlash(); ?>

            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-2 mb-4">
                <div>
                    <h3 class="fw-bold mb-1"><i class="bi bi-calendar-plus-fill text-primary me-2"></i>Book Walk-In Appointment</h3>
                    <p class="text-muted mb-0 fs-7">Receptionist walk-in desk for scheduling appointments and generating instant OPD queue tokens.</p>
                </div>
                <a href="checkin.php" class="btn btn-outline-secondary rounded-pill px-3 shadow-sm fs-7">
                    <i class="bi bi-person-check me-1"></i> OPD Queue Desk
                </a>
            </div>

            <div class="card card-custom p-4 p-md-5 border-0 shadow-sm" style="max-width: 950px;">
                <?php if ($errorMsg): ?>
                    <div class="alert alert-danger border-0 shadow-sm mb-4">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= htmlspecialchars($errorMsg) ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <?= renderCSRFField() ?>
                    
                    <div class="row g-3 mb-4">
                        <!-- Patient Select -->
                        <div class="col-md-12">
                            <label class="form-label fw-semibold">1. Select Patient <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-body-tertiary"><i class="bi bi-person text-muted"></i></span>
                                <select name="patient_id" class="form-select" required>
                                    <option value="">-- Choose Registered Patient (<?= count($patients) ?> Registered) --</option>
                                    <?php foreach ($patients as $pat): ?>
                                        <option value="<?= $pat['id'] ?>">
                                            <?= htmlspecialchars($pat['name']) ?> (Code: <?= htmlspecialchars($pat['patient_code']) ?> • Blood: <?= htmlspecialchars($pat['blood_group'] ?? 'O+') ?> • Phone: <?= htmlspecialchars($pat['phone'] ?? 'N/A') ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <!-- Department Select -->
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">2. Medical Department</label>
                            <div class="input-group">
                                <span class="input-group-text bg-body-tertiary"><i class="bi bi-hospital text-muted"></i></span>
                                <select name="department_id" id="recDeptSelect" class="form-select">
                                    <option value="">-- All Departments (<?= count($departments) ?> Available) --</option>
                                    <?php foreach ($departments as $dept): ?>
                                        <option value="<?= $dept['id'] ?>"><?= htmlspecialchars($dept['dept_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <!-- Doctor Select -->
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">3. Attending Specialist Doctor <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text bg-body-tertiary"><i class="bi bi-heart-pulse text-muted"></i></span>
                                <select name="doctor_id" id="recDocSelect" class="form-select" required>
                                    <option value="">-- Choose Specialist Doctor --</option>
                                </select>
                            </div>
                        </div>

                        <!-- Date -->
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">4. Appointment Date <span class="text-danger">*</span></label>
                            <input type="date" name="appointment_date" class="form-control" value="<?= date('Y-m-d') ?>" min="<?= date('Y-m-d') ?>" required>
                        </div>

                        <!-- Time Slot -->
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">5. Time Slot <span class="text-danger">*</span></label>
                            <select name="time_slot" class="form-select" required>
                                <optgroup label="Morning OPD">
                                    <option value="09:00 AM">09:00 AM - 09:30 AM</option>
                                    <option value="09:30 AM" selected>09:30 AM - 10:00 AM</option>
                                    <option value="10:00 AM">10:00 AM - 10:30 AM</option>
                                    <option value="10:30 AM">10:30 AM - 11:00 AM</option>
                                    <option value="11:00 AM">11:00 AM - 11:30 AM</option>
                                    <option value="11:30 AM">11:30 AM - 12:00 PM</option>
                                </optgroup>
                                <optgroup label="Afternoon OPD">
                                    <option value="01:00 PM">01:00 PM - 01:30 PM</option>
                                    <option value="01:30 PM">01:30 PM - 02:00 PM</option>
                                    <option value="02:00 PM">02:00 PM - 02:30 PM</option>
                                    <option value="02:30 PM">02:30 PM - 03:00 PM</option>
                                    <option value="03:00 PM">03:00 PM - 03:30 PM</option>
                                    <option value="04:00 PM">04:00 PM - 04:30 PM</option>
                                </optgroup>
                            </select>
                        </div>

                        <!-- Reason -->
                        <div class="col-12">
                            <label class="form-label fw-semibold">6. Visit Complaint / Symptoms</label>
                            <textarea name="reason" class="form-control" rows="2" placeholder="Brief notes on patient symptoms or reason for OPD visit..."></textarea>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center pt-3 border-top">
                        <small class="text-muted"><i class="bi bi-info-circle me-1"></i> Automatically assigns the next sequential token number for today.</small>
                        <button type="submit" class="btn btn-primary rounded-pill px-5 shadow-sm fw-bold">
                            <i class="bi bi-check-circle-fill me-1"></i> Issue Token & Schedule
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>

<script>
const recDoctors = <?= json_encode($doctors) ?>;
const recDeptSelect = document.getElementById('recDeptSelect');
const recDocSelect = document.getElementById('recDocSelect');

function populateRecDoctors(deptId) {
    recDocSelect.innerHTML = '';
    let filtered = recDoctors;
    if (deptId) {
        filtered = recDoctors.filter(d => parseInt(d.department_id) === parseInt(deptId));
    }

    if (filtered.length === 0) {
        const opt = document.createElement('option');
        opt.value = '';
        opt.textContent = '-- No Doctor in this Department --';
        recDocSelect.appendChild(opt);
        return;
    }

    filtered.forEach(doc => {
        const opt = document.createElement('option');
        opt.value = doc.id;
        opt.textContent = `${doc.name} (${doc.dept_name} • ${doc.specialization} - ₹${parseFloat(doc.consultation_fee).toFixed(2)})`;
        recDocSelect.appendChild(opt);
    });
}

recDeptSelect.addEventListener('change', function() {
    populateRecDoctors(this.value);
});

recDocSelect.addEventListener('change', function() {
    const docId = this.value;
    const doc = recDoctors.find(d => parseInt(d.id) === parseInt(docId));
    if (doc && (!recDeptSelect.value || parseInt(recDeptSelect.value) !== parseInt(doc.department_id))) {
        recDeptSelect.value = doc.department_id;
    }
});

document.addEventListener('DOMContentLoaded', () => {
    populateRecDoctors('');
});
</script>
