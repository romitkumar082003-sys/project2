<?php
// MediCareX - Inpatient Admission Management
// Developed by Romit Kumar

$pageTitle = 'Admit Inpatient';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

requireRole(['Receptionist', 'Admin']);

$user = getCurrentUser();
$pdo = getDBConnection();

$patients = $pdo->query("SELECT p.id, p.patient_code, u.name FROM patients p JOIN users u ON p.user_id = u.id ORDER BY u.name ASC")->fetchAll();
$doctors = $pdo->query("SELECT d.id, u.name, dep.dept_name, d.department_id FROM doctors d JOIN users u ON d.user_id = u.id JOIN departments dep ON d.department_id = dep.id ORDER BY u.name ASC")->fetchAll();
$rooms = $pdo->query("SELECT * FROM rooms ORDER BY room_number ASC")->fetchAll();

// Available beds
$availableBeds = $pdo->query("
    SELECT b.*, r.room_number, r.room_type, r.daily_rate 
    FROM beds b 
    JOIN rooms r ON b.room_id = r.id 
    WHERE b.status = 'Available' 
    ORDER BY r.room_number ASC, b.bed_number ASC
")->fetchAll();

$errorMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validateCSRFOrDie();

    $patient_id = intval($_POST['patient_id'] ?? 0);
    $doctor_id = intval($_POST['doctor_id'] ?? 0);
    $bed_id = intval($_POST['bed_id'] ?? 0);
    $diagnosis = cleanInput($_POST['diagnosis'] ?? '');

    if (!$patient_id || !$doctor_id || !$bed_id) {
        $errorMsg = "Please select patient, doctor, and bed.";
    } else {
        // Verify Bed is still available
        $bedCheck = $pdo->prepare("SELECT b.*, r.id as room_id, r.department_id FROM beds b JOIN rooms r ON b.room_id = r.id WHERE b.id = ? AND b.status = 'Available'");
        $bedCheck->execute([$bed_id]);
        $bed = $bedCheck->fetch();

        if (!$bed) {
            $errorMsg = "The selected bed is no longer available. Please select another bed.";
        } else {
            try {
                $pdo->beginTransaction();

                $admCode = generateCode('ADM', 'admissions', 'admission_code');
                
                // Get doctor department
                $docDept = $pdo->prepare("SELECT department_id FROM doctors WHERE id = ?");
                $docDept->execute([$doctor_id]);
                $department_id = $docDept->fetchColumn();

                $insAdm = $pdo->prepare("
                    INSERT INTO admissions (admission_code, patient_id, doctor_id, department_id, room_id, bed_id, admission_date, diagnosis, status) 
                    VALUES (?, ?, ?, ?, ?, ?, NOW(), ?, 'Admitted')
                ");
                $insAdm->execute([$admCode, $patient_id, $doctor_id, $department_id, $bed['room_id'], $bed_id, $diagnosis]);

                // Update Bed status to Occupied
                $updBed = $pdo->prepare("UPDATE beds SET status = 'Occupied' WHERE id = ?");
                $updBed->execute([$bed_id]);

                $pdo->commit();

                logAudit($user['id'], $user['name'], $user['role_name'], 'PATIENT_ADMIT', "Admitted patient ID {$patient_id} to Bed {$bed['bed_number']} (Admission: {$admCode}).");
                setFlash('success', "Patient admitted successfully! Admission Code: {$admCode}.");
                header("Location: admit_patient.php");
                exit();
            } catch (Exception $e) {
                $pdo->rollBack();
                $errorMsg = "Database error: " . $e->getMessage();
            }
        }
    }
}

// Active Admissions List
$activeAdmissions = $pdo->query("
    SELECT adm.*, p.patient_code, u_p.name as patient_name, u_d.name as doctor_name, r.room_number, r.room_type, b.bed_number
    FROM admissions adm
    JOIN patients p ON adm.patient_id = p.id
    JOIN users u_p ON p.user_id = u_p.id
    JOIN doctors d ON adm.doctor_id = d.id
    JOIN users u_d ON d.user_id = u_d.id
    JOIN rooms r ON adm.room_id = r.id
    JOIN beds b ON adm.bed_id = b.id
    WHERE adm.status IN ('Admitted', 'Under Treatment')
    ORDER BY adm.id DESC
")->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <?php displayFlash(); ?>

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1">Inpatient Admission Desk</h3>
                    <p class="text-muted mb-0">Assign rooms, beds, and admitting physicians</p>
                </div>
                <button type="button" class="btn btn-primary rounded-pill px-4 shadow-sm" data-bs-toggle="modal" data-bs-target="#admitModal">
                    <i class="bi bi-hospital me-2"></i> Admit New Inpatient
                </button>
            </div>

            <!-- Active Admissions List -->
            <div class="card card-custom border-0 shadow-sm mb-4">
                <div class="card-header bg-body border-0 py-3">
                    <h5 class="fw-bold mb-0"><i class="bi bi-door-open-fill me-2 text-primary"></i> Currently Admitted Patients</h5>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light fs-7 text-uppercase">
                            <tr>
                                <th>Admission Code</th>
                                <th>Patient Name</th>
                                <th>Attending Doctor</th>
                                <th>Room & Type</th>
                                <th>Bed Number</th>
                                <th>Admission Date</th>
                                <th>Status</th>
                                <th class="text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($activeAdmissions)): ?>
                                <tr>
                                    <td colspan="8" class="text-center py-5 text-muted">
                                        <i class="bi bi-hospital fs-1 d-block mb-2"></i>
                                        No active inpatients admitted currently.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($activeAdmissions as $adm): ?>
                                    <tr>
                                        <td class="fw-bold text-primary"><?= htmlspecialchars($adm['admission_code']) ?></td>
                                        <td>
                                            <div class="fw-bold"><?= htmlspecialchars($adm['patient_name']) ?></div>
                                            <small class="text-muted"><?= htmlspecialchars($adm['patient_code']) ?></small>
                                        </td>
                                        <td><?= htmlspecialchars($adm['doctor_name']) ?></td>
                                        <td>
                                            <div class="fw-semibold"><?= htmlspecialchars($adm['room_number']) ?></div>
                                            <small class="text-muted"><?= htmlspecialchars($adm['room_type']) ?></small>
                                        </td>
                                        <td><span class="badge bg-dark px-2 py-1 fs-7"><?= htmlspecialchars($adm['bed_number']) ?></span></td>
                                        <td><?= formatDate($adm['admission_date']) ?></td>
                                        <td><?= renderStatusBadge($adm['status']) ?></td>
                                        <td class="text-end">
                                            <a href="<?= get_base_url() ?>/print_discharge.php?id=<?= $adm['id'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary rounded-pill">
                                                <i class="bi bi-file-earmark-text me-1"></i> Summary
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Admit Modal -->
        <div class="modal fade" id="admitModal" tabindex="-1">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title fw-bold"><i class="bi bi-hospital me-2"></i> Inpatient Admission Form</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <form method="POST" action="">
                        <?= renderCSRFField() ?>
                        <div class="modal-body p-4">
                            <?php if ($errorMsg): ?>
                                <div class="alert alert-danger border-0 shadow-sm mb-3"><?= htmlspecialchars($errorMsg) ?></div>
                            <?php endif; ?>

                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Select Patient *</label>
                                    <select name="patient_id" class="form-select" required>
                                        <option value="">-- Choose Patient --</option>
                                        <?php foreach ($patients as $pat): ?>
                                            <option value="<?= $pat['id'] ?>"><?= htmlspecialchars($pat['name']) ?> (<?= htmlspecialchars($pat['patient_code']) ?>)</option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Attending Doctor *</label>
                                    <select name="doctor_id" class="form-select" required>
                                        <option value="">-- Choose Doctor --</option>
                                        <?php foreach ($doctors as $doc): ?>
                                            <option value="<?= $doc['id'] ?>"><?= htmlspecialchars($doc['name']) ?> (<?= htmlspecialchars($doc['dept_name']) ?>)</option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <label class="form-label fw-semibold">Assign Available Bed *</label>
                                    <select name="bed_id" class="form-select" required>
                                        <option value="">-- Select Available Ward / Room Bed --</option>
                                        <?php foreach ($availableBeds as $bed): ?>
                                            <option value="<?= $bed['id'] ?>">
                                                Room <?= htmlspecialchars($bed['room_number']) ?> (<?= htmlspecialchars($bed['room_type']) ?>) - Bed <?= htmlspecialchars($bed['bed_number']) ?> - ₹<?= $bed['daily_rate'] ?>/day
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <label class="form-label fw-semibold">Admission Diagnosis & Clinical Reason</label>
                                    <textarea name="diagnosis" class="form-control" rows="3" placeholder="Enter admission diagnosis..." required></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer border-top-0 pt-0">
                            <button type="button" class="btn btn-light rounded-pill" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary rounded-pill px-4 shadow">Confirm Admission</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
