<?php
// MediCareX - Public Landing Page
// Developed by Romit Kumar
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MediCareX – Smart Hospital Management System</title>
    <meta name="description" content="MediCareX is an enterprise-grade hospital management system featuring multi-role authentication, OPD queuing, electronic prescriptions, pharmacy inventory, lab diagnostics, blood bank, and billing. Developed by Romit Kumar.">
    <meta name="author" content="Developed by Romit Kumar">

    <!-- Bootstrap 5 & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- Google Fonts (Outfit & Inter) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Outfit:wght@500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #0d6efd;
            --primary-dark: #0a58ca;
            --secondary: #0d9488;
            --success: #10b981;
            --dark: #0f172a;
            --card-bg: #ffffff;
            --body-bg: #f8fafc;
            --border-color: #e2e8f0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--body-bg);
            color: #1e293b;
            overflow-x: hidden;
        }

        h1, h2, h3, h4, .brand-font {
            font-family: 'Outfit', sans-serif;
        }

        .hero-banner {
            background: radial-gradient(circle at 80% 20%, rgba(13, 110, 253, 0.15) 0%, transparent 50%),
                        radial-gradient(circle at 20% 80%, rgba(13, 148, 136, 0.12) 0%, transparent 45%),
                        #ffffff;
            padding: 90px 0 70px 0;
            border-bottom: 1px solid var(--border-color);
        }

        .card-custom {
            border: 1px solid var(--border-color);
            border-radius: 16px;
            background: #ffffff;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .card-custom:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.08);
        }

        .badge-soft-primary {
            background-color: rgba(13, 110, 253, 0.1);
            color: #0d6efd;
        }

        .badge-soft-success {
            background-color: rgba(16, 185, 129, 0.12);
            color: #059669;
        }

        .stat-circle {
            width: 56px;
            height: 56px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .nav-link {
            font-weight: 500;
            color: #475569;
        }

        .nav-link:hover {
            color: var(--primary);
        }
    </style>
</head>
<body>

    <!-- Header Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom sticky-top py-3">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center gap-2" href="#">
                <span class="bg-primary text-white p-2 rounded-3 d-inline-flex"><i class="bi bi-hospital-fill fs-5"></i></span>
                <div>
                    <span class="fw-bold fs-4 text-primary brand-font mb-0 d-block lh-1">MediCareX</span>
                    <small class="text-muted fs-8">Smart Hospital System</small>
                </div>
            </a>
            <button class="navbar-toggler border-0 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#navContent">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navContent">
                <ul class="navbar-nav mx-auto mb-2 mb-lg-0 gap-lg-3">
                    <li class="nav-item"><a class="nav-link" href="#features">Features</a></li>
                    <li class="nav-item"><a class="nav-link" href="#portals">Role Portals</a></li>
                    <li class="nav-item"><a class="nav-link" href="#specialties">Specialties</a></li>
                    <li class="nav-item"><a class="nav-link" href="#credentials">Demo Accounts</a></li>
                </ul>
                <div class="d-flex align-items-center gap-2">
                    <a href="portal.html?role=admin" class="btn btn-outline-primary rounded-pill px-4" id="btnPhpPortal">
                        <i class="bi bi-box-arrow-in-right me-1"></i> Open Portal
                    </a>
                    <a href="tel:+919876543210" class="btn btn-danger rounded-pill px-3">
                        <i class="bi bi-telephone-fill me-1"></i> Emergency
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-banner text-center position-relative">
        <div class="container">
            <span class="badge badge-soft-primary px-3 py-2 rounded-pill fs-7 fw-semibold mb-3">
                <i class="bi bi-shield-check me-1"></i> Developed by Romit Kumar &bull; Production-Grade Hospital ERP
            </span>
            <h1 class="display-4 fw-extrabold mb-3 text-dark">
                Smart Healthcare. <span class="text-primary">Better Care.</span>
            </h1>
            <p class="lead text-muted mx-auto mb-4" style="max-width: 720px;">
                Complete digital management platform for modern hospitals. Streamlining appointments, clinical consultations, inpatient wards, lab diagnostics, pharmacy inventory, blood bank, and instant payments.
            </p>

            <div class="d-flex flex-wrap justify-content-center gap-3 mb-5">
                <a href="portal.html?role=admin" class="btn btn-primary btn-lg rounded-pill px-5 shadow">
                    <i class="bi bi-play-circle-fill me-2"></i> Launch Live System
                </a>
                <a href="#portals" class="btn btn-outline-secondary btn-lg rounded-pill px-4">
                    <i class="bi bi-person-badge me-2"></i> Explore Roles
                </a>
            </div>

            <!-- Highlights Bar -->
            <div class="row g-3 justify-content-center" style="max-width: 950px; margin: 0 auto;">
                <div class="col-6 col-md-3">
                    <div class="p-3 bg-white border rounded-4 shadow-sm">
                        <h3 class="fw-bold text-primary mb-0">7 Roles</h3>
                        <small class="text-muted fs-8">Admin to Patient</small>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="p-3 bg-white border rounded-4 shadow-sm">
                        <h3 class="fw-bold text-success mb-0">11+ Doctors</h3>
                        <small class="text-muted fs-8">9 Specialties</small>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="p-3 bg-white border rounded-4 shadow-sm">
                        <h3 class="fw-bold text-warning mb-0">Zero-Config</h3>
                        <small class="text-muted fs-8">SQLite Persistence</small>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="p-3 bg-white border rounded-4 shadow-sm">
                        <h3 class="fw-bold text-danger mb-0">100% Live</h3>
                        <small class="text-muted fs-8">Demo Gateway</small>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Role Portals Grid -->
    <section class="py-5" id="portals">
        <div class="container">
            <div class="text-center mb-5">
                <h6 class="text-primary text-uppercase fw-bold fs-7">Role-Based Access Control</h6>
                <h2 class="fw-bold">Designed for Every Hospital Stakeholder</h2>
                <p class="text-muted">Single unified platform with tailored workflows for all 7 hospital user roles.</p>
            </div>

            <div class="row g-4">
                <!-- Admin -->
                <div class="col-md-6 col-lg-4">
                    <div class="card card-custom p-4 h-100">
                        <div class="stat-circle bg-primary bg-opacity-10 text-primary mb-3">
                            <i class="bi bi-speedometer2 fs-3"></i>
                        </div>
                        <h5 class="fw-bold mb-2">Hospital Administrator</h5>
                        <p class="text-muted fs-7 mb-3">Manage rooms, bed allocation, department status, doctor rosters, blood bank stock, billing invoices, and interactive analytics graphs.</p>
                        <a href="portal.html?role=admin" class="btn btn-sm btn-outline-primary rounded-pill mt-auto">Open Admin Portal &rarr;</a>
                    </div>
                </div>

                <!-- Doctor -->
                <div class="col-md-6 col-lg-4">
                    <div class="card card-custom p-4 h-100">
                        <div class="stat-circle bg-success bg-opacity-10 text-success mb-3">
                            <i class="bi bi-heart-pulse-fill fs-3"></i>
                        </div>
                        <h5 class="fw-bold mb-2">Consultant Doctor</h5>
                        <p class="text-muted fs-7 mb-3">Live OPD Queue management, patient medical history timeline, clinical diagnosis room, digital prescription generator, and lab order requisitions.</p>
                        <a href="portal.html?role=doctor" class="btn btn-sm btn-outline-success rounded-pill mt-auto">Open Doctor Desk &rarr;</a>
                    </div>
                </div>

                <!-- Patient -->
                <div class="col-md-6 col-lg-4">
                    <div class="card card-custom p-4 h-100">
                        <div class="stat-circle bg-info bg-opacity-10 text-info mb-3">
                            <i class="bi bi-person-heart fs-3"></i>
                        </div>
                        <h5 class="fw-bold mb-2">Patient Portal</h5>
                        <p class="text-muted fs-7 mb-3">Book appointments, download digital prescriptions, review lab reports, and pay hospital bills online with Demo UPI / Card Gateway.</p>
                        <a href="portal.html?role=patient" class="btn btn-sm btn-outline-info rounded-pill mt-auto">Open Patient Portal &rarr;</a>
                    </div>
                </div>

                <!-- Receptionist -->
                <div class="col-md-6 col-lg-4">
                    <div class="card card-custom p-4 h-100">
                        <div class="stat-circle bg-warning bg-opacity-10 text-warning mb-3">
                            <i class="bi bi-calendar-check-fill fs-3"></i>
                        </div>
                        <h5 class="fw-bold mb-2">Reception Desk</h5>
                        <p class="text-muted fs-7 mb-3">Patient registration, walk-in appointment scheduling, token generation, check-in dispatching, and inpatient admissions.</p>
                        <a href="portal.html?role=reception" class="btn btn-sm btn-outline-warning rounded-pill mt-auto">Open Reception &rarr;</a>
                    </div>
                </div>

                <!-- Pharmacist -->
                <div class="col-md-6 col-lg-4">
                    <div class="card card-custom p-4 h-100">
                        <div class="stat-circle bg-danger bg-opacity-10 text-danger mb-3">
                            <i class="bi bi-capsule-pill fs-3"></i>
                        </div>
                        <h5 class="fw-bold mb-2">Pharmacy Dispensary</h5>
                        <p class="text-muted fs-7 mb-3">Track medicine batches, real-time stock adjustments, low-stock warnings, expired drug management, and prescription dispensing.</p>
                        <a href="portal.html?role=pharmacy" class="btn btn-sm btn-outline-danger rounded-pill mt-auto">Open Pharmacy &rarr;</a>
                    </div>
                </div>

                <!-- Lab Technician -->
                <div class="col-md-6 col-lg-4">
                    <div class="card card-custom p-4 h-100">
                        <div class="stat-circle bg-secondary bg-opacity-10 text-secondary mb-3">
                            <i class="bi bi-eyedropper fs-3"></i>
                        </div>
                        <h5 class="fw-bold mb-2">Diagnostic Laboratory</h5>
                        <p class="text-muted fs-7 mb-3">Process blood, urine, pathology, and radiology test requests, enter clinical findings, and publish digital lab reports.</p>
                        <a href="portal.html?role=lab" class="btn btn-sm btn-outline-secondary rounded-pill mt-auto">Open Lab Portal &rarr;</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Demo Credentials Section -->
    <section class="py-5 bg-white border-top border-bottom" id="credentials">
        <div class="container" style="max-width: 900px;">
            <div class="text-center mb-4">
                <h6 class="text-primary text-uppercase fw-bold fs-7">Quick Testing Matrix</h6>
                <h2 class="fw-bold">1-Click Demo Login Accounts</h2>
                <p class="text-muted">Use these pre-configured credentials to evaluate any module immediately (All passwords: <code>password123</code>):</p>
            </div>

            <div class="table-responsive bg-white rounded-3 border">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light fs-7 text-uppercase">
                        <tr>
                            <th>Role</th>
                            <th>Email Address</th>
                            <th>User Code</th>
                            <th>Password</th>
                            <th class="text-end">Direct Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="fw-bold text-primary"><i class="bi bi-shield-lock-fill me-1"></i> Admin</td>
                            <td><code>admin@medicarex.local</code></td>
                            <td><span class="badge bg-primary">ADM-1001</span></td>
                            <td><code>password123</code></td>
                            <td class="text-end"><a href="portal.html?role=admin" class="btn btn-sm btn-primary rounded-pill px-3">Open Portal</a></td>
                        </tr>
                        <tr>
                            <td class="fw-bold text-success"><i class="bi bi-heart-pulse-fill me-1"></i> Doctor</td>
                            <td><code>doctor@medicarex.local</code></td>
                            <td><span class="badge bg-success">DOC-2001</span></td>
                            <td><code>password123</code></td>
                            <td class="text-end"><a href="portal.html?role=doctor" class="btn btn-sm btn-success rounded-pill px-3">Open Portal</a></td>
                        </tr>
                        <tr>
                            <td class="fw-bold text-warning"><i class="bi bi-calendar-check-fill me-1"></i> Reception</td>
                            <td><code>reception@medicarex.local</code></td>
                            <td><span class="badge bg-warning text-dark">REC-4001</span></td>
                            <td><code>password123</code></td>
                            <td class="text-end"><a href="portal.html?role=reception" class="btn btn-sm btn-warning rounded-pill px-3">Open Portal</a></td>
                        </tr>
                        <tr>
                            <td class="fw-bold text-danger"><i class="bi bi-capsule-pill me-1"></i> Pharmacy</td>
                            <td><code>pharmacy@medicarex.local</code></td>
                            <td><span class="badge bg-danger">PHA-5001</span></td>
                            <td><code>password123</code></td>
                            <td class="text-end"><a href="portal.html?role=pharmacy" class="btn btn-sm btn-danger rounded-pill px-3">Open Portal</a></td>
                        </tr>
                        <tr>
                            <td class="fw-bold text-info"><i class="bi bi-person-fill me-1"></i> Patient</td>
                            <td><code>patient@medicarex.local</code></td>
                            <td><span class="badge bg-info text-white">PAT-7001</span></td>
                            <td><code>password123</code></td>
                            <td class="text-end"><a href="portal.html?role=patient" class="btn btn-sm btn-info rounded-pill px-3 text-white">Open Portal</a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container d-flex flex-column flex-md-row justify-content-between align-items-center gap-3">
            <div>
                <h5 class="fw-bold brand-font mb-0 text-primary"><i class="bi bi-hospital-fill me-2"></i>MediCareX</h5>
                <small class="text-secondary">&copy; 2026 MediCareX Hospital Management System. All rights reserved.</small>
            </div>
            <div class="text-center text-md-end">
                <span class="badge bg-primary px-3 py-2 rounded-pill fs-7">
                    <i class="bi bi-code-slash me-1"></i> Developed by Romit Kumar
                </span>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
