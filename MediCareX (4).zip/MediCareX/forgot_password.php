<?php
// MediCareX - Password Reset Request
// Developed by Romit Kumar

$pageTitle = 'Reset Password';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

$baseUrl = get_base_url();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = cleanInput($_POST['email'] ?? '');
    $msg = "Password reset instructions have been dispatched to " . htmlspecialchars($email) . " (Demo Simulation).";
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - MediCareX</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>/assets/css/style.css">
</head>
<body class="bg-body-tertiary d-flex align-items-center justify-content-center min-vh-100 py-4">
    <div class="container" style="max-width: 480px;">
        <div class="card card-custom p-4 p-md-5 border-0 shadow-lg">
            <h4 class="fw-bold mb-2">Reset Password</h4>
            <p class="text-muted fs-7 mb-4">Enter your registered email address to receive password recovery instructions.</p>

            <?php if ($msg): ?>
                <div class="alert alert-success border-0 shadow-sm mb-4">
                    <i class="bi bi-check-circle-fill me-2"></i> <?= $msg ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="mb-3">
                    <label class="form-label fw-semibold">Email Address</label>
                    <input type="email" name="email" class="form-control" placeholder="e.g. user@medicarex.local" required>
                </div>
                <button type="submit" class="btn btn-primary w-100 rounded-pill shadow-sm mb-3">
                    Send Reset Link
                </button>
            </form>
            <div class="text-center fs-7">
                <a href="<?= $baseUrl ?>/login.php" class="text-decoration-none"><i class="bi bi-arrow-left me-1"></i> Back to Login</a>
            </div>
        </div>
    </div>
</body>
</html>
