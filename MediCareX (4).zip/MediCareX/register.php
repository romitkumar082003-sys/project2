<?php
// MediCareX - Patient Registration
// Developed by Romit Kumar

$pageTitle = 'Patient Self-Registration';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/csrf.php';

$baseUrl = get_base_url();

if (isLoggedIn()) {
    $user = getCurrentUser();
    redirectByRole($user['role_name']);
}

$errorMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validateCSRFOrDie();
    
    $name = cleanInput($_POST['name'] ?? '');
    $email = cleanInput($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $phone = cleanInput($_POST['phone'] ?? '');
    $dob = cleanInput($_POST['dob'] ?? '');
    $gender = cleanInput($_POST['gender'] ?? 'Male');
    $blood_group = cleanInput($_POST['blood_group'] ?? 'O+');
    $address = cleanInput($_POST['address'] ?? '');
    $emergency_contact = cleanInput($_POST['emergency_contact'] ?? '');

    if ($password !== $confirm_password) {
        $errorMsg = "Passwords do not match.";
    } elseif (strlen($password) < 6) {
        $errorMsg = "Password must be at least 6 characters long.";
    } else {
        $pdo = getDBConnection();
        // Check duplicate email
        $chk = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
        $chk->execute([$email]);
        if ($chk->fetchColumn() > 0) {
            $errorMsg = "An account with this email address already exists.";
        } else {
            try {
                $pdo->beginTransaction();
                
                $user_code = generateCode('PAT', 'users', 'user_code');
                $hash = password_hash($password, PASSWORD_DEFAULT);
                
                $stmt = $pdo->prepare("
                    INSERT INTO users (user_code, name, email, password, role_id, phone, status) 
                    VALUES (?, ?, ?, ?, 7, ?, 'Active')
                ");
                $stmt->execute([$user_code, $name, $email, $hash, $phone]);
                $user_id = $pdo->lastInsertId();

                $stmtPat = $pdo->prepare("
                    INSERT INTO patients (user_id, patient_code, dob, gender, blood_group, address, emergency_contact) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $stmtPat->execute([$user_id, $user_code, $dob, $gender, $blood_group, $address, $emergency_contact]);

                $pdo->commit();
                
                logAudit($user_id, $name, 'Patient', 'PATIENT_REGISTER', "Self-registered new patient account {$user_code}.");
                addNotification($user_id, 'Welcome to MediCareX', 'Your patient profile has been created successfully.', 'patient/index.php');

                setFlash('success', "Account created successfully! Your Patient ID is {$user_code}. Please log in.");
                header("Location: {$baseUrl}/login.php");
                exit();
            } catch (Exception $e) {
                $pdo->rollBack();
                $errorMsg = "Registration failed due to a database error: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Registration - MediCareX</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="<?= $baseUrl ?>/assets/css/style.css">
</head>
<body class="bg-body-tertiary py-5">

    <div class="container" style="max-width: 800px;">
        <div class="card card-custom p-4 p-md-5 border-0 shadow-lg">
            <div class="d-flex justify-content-between align-items-center mb-4 border-bottom pb-3">
                <div class="d-flex align-items-center">
                    <div class="rounded-circle bg-primary text-white p-2 me-3 d-flex align-items-center justify-content-center" style="width: 42px; height: 42px;">
                        <i class="bi bi-person-plus-fill fs-4"></i>
                    </div>
                    <div>
                        <h4 class="fw-bold mb-0">Patient Account Registration</h4>
                        <small class="text-muted">Create your digital medical record profile</small>
                    </div>
                </div>
                <a href="<?= $baseUrl ?>/login.php" class="btn btn-outline-secondary btn-sm rounded-pill">Sign In Instead</a>
            </div>

            <?php if ($errorMsg): ?>
                <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= htmlspecialchars($errorMsg) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <?= renderCSRFField() ?>
                
                <h6 class="fw-bold text-primary text-uppercase fs-7 mb-3">1. Personal & Contact Details</h6>
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Full Name *</label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. Ramesh Gupta" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Email Address *</label>
                        <input type="email" name="email" class="form-control" placeholder="e.g. ramesh@example.com" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Password *</label>
                        <input type="password" name="password" class="form-control" placeholder="Minimum 6 characters" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Confirm Password *</label>
                        <input type="password" name="confirm_password" class="form-control" placeholder="Re-enter password" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Mobile Number *</label>
                        <input type="text" name="phone" class="form-control" placeholder="+91 9876543210" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Emergency Contact Phone</label>
                        <input type="text" name="emergency_contact" class="form-control" placeholder="Family / Kin Phone">
                    </div>
                </div>

                <h6 class="fw-bold text-primary text-uppercase fs-7 mb-3">2. Health Profile</h6>
                <div class="row g-3 mb-4">
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Date of Birth</label>
                        <input type="date" name="dob" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Gender</label>
                        <select name="gender" class="form-select">
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Blood Group</label>
                        <select name="blood_group" class="form-select">
                            <option value="A+">A+</option>
                            <option value="A-">A-</option>
                            <option value="B+">B+</option>
                            <option value="B-">B-</option>
                            <option value="AB+">AB+</option>
                            <option value="AB-">AB-</option>
                            <option value="O+">O+</option>
                            <option value="O-">O-</option>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label fw-semibold">Residential Address</label>
                        <textarea name="address" class="form-control" rows="2" placeholder="Street address, City, Pincode"></textarea>
                    </div>
                </div>

                <div class="d-flex justify-content-between align-items-center pt-3 border-top">
                    <a href="<?= $baseUrl ?>/index.php" class="text-muted text-decoration-none fs-7"><i class="bi bi-arrow-left me-1"></i> Cancel</a>
                    <button type="submit" class="btn btn-primary btn-lg rounded-pill px-5 shadow-sm">
                        <i class="bi bi-check-circle me-2"></i> Register Account
                    </button>
                </div>
            </form>
        </div>

        <div class="text-center mt-4 text-muted fs-8">
            MediCareX Hospital Management Platform &bull; Developed by Romit Kumar
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
