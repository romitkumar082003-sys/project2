<?php
// MediCareX - Enter Lab Test Results & Release Report
// Developed by Romit Kumar

$pageTitle = 'Enter Test Findings';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

requireRole(['Lab Technician', 'Admin']);

$user = getCurrentUser();
$pdo = getDBConnection();

$request_id = intval($_GET['request_id'] ?? 0);

$reqStmt = $pdo->prepare("
    SELECT req.*, lt.test_name, lt.category, p.patient_code, u_p.name as patient_name, p.id as patient_id
    FROM lab_requests req
    JOIN lab_tests lt ON req.test_id = lt.id
    JOIN patients p ON req.patient_id = p.id
    JOIN users u_p ON p.user_id = u_p.id
    WHERE req.id = ?
");
$reqStmt->execute([$request_id]);
$req = $reqStmt->fetch();

if (!$req) {
    setFlash('error', "Invalid laboratory request ID.");
    header("Location: index.php");
    exit();
}

// Get Lab Tech ID
$techStmt = $pdo->prepare("SELECT id FROM lab_technicians WHERE user_id = ?");
$techStmt->execute([$user['id']]);
$technician_id = $techStmt->fetchColumn() ?: 1;

$errorMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validateCSRFOrDie();

    $result_summary = cleanInput($_POST['result_summary'] ?? '');

    if (empty($result_summary)) {
        $errorMsg = "Please enter test findings summary.";
    } else {
        try {
            $pdo->beginTransaction();

            $insRep = $pdo->prepare("
                INSERT INTO lab_reports (request_id, patient_id, technician_id, result_summary, completed_at) 
                VALUES (?, ?, ?, ?, NOW())
            ");
            $insRep->execute([$request_id, $req['patient_id'], $technician_id, $result_summary]);

            $updReq = $pdo->prepare("UPDATE lab_requests SET status = 'Completed' WHERE id = ?");
            $updReq->execute([$request_id]);

            $pdo->commit();

            logAudit($user['id'], $user['name'], 'Lab Technician', 'LAB_REPORT_RELEASED', "Released lab report for Request {$req['request_code']}.");

            // Notify patient
            $pUserStmt = $pdo->prepare("SELECT user_id FROM patients WHERE id = ?");
            $pUserStmt->execute([$req['patient_id']]);
            $pUserId = $pUserStmt->fetchColumn();
            if ($pUserId) {
                addNotification($pUserId, 'Lab Report Ready', "Your lab report for {$req['test_name']} is now ready to view.", 'patient/lab_reports.php');
            }

            setFlash('success', "Lab test report released successfully for Request {$req['request_code']}!");
            header("Location: index.php");
            exit();
        } catch (Exception $e) {
            $pdo->rollBack();
            $errorMsg = "Database error: " . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1">Enter Laboratory Test Results</h3>
                    <p class="text-muted mb-0">Request: <span class="badge bg-primary fs-7"><?= htmlspecialchars($req['request_code']) ?></span> | Test: <strong><?= htmlspecialchars($req['test_name']) ?></strong></p>
                </div>
                <a href="index.php" class="btn btn-outline-secondary rounded-pill">Back to Workbench</a>
            </div>

            <div class="card card-custom p-4 border-0 shadow-sm" style="max-width: 800px;">
                <?php if ($errorMsg): ?>
                    <div class="alert alert-danger border-0 shadow-sm mb-3"><?= htmlspecialchars($errorMsg) ?></div>
                <?php endif; ?>

                <div class="p-3 bg-light rounded border mb-4 fs-7">
                    <div><strong>Patient:</strong> <?= htmlspecialchars($req['patient_name']) ?> (<?= htmlspecialchars($req['patient_code']) ?>)</div>
                    <div><strong>Category:</strong> <?= htmlspecialchars($req['category']) ?></div>
                    <div><strong>Notes / Priority:</strong> <?= htmlspecialchars($req['notes'] ?? 'None') ?> (<?= htmlspecialchars($req['priority']) ?>)</div>
                </div>

                <form method="POST" action="">
                    <?= renderCSRFField() ?>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Lab Test Result Summary & Findings *</label>
                        <textarea name="result_summary" class="form-control" rows="5" placeholder="e.g. Hemoglobin: 14.2 g/dL (Normal). WBC: 7,500 /mcL (Normal). Platelets: 250,000 /mcL." required></textarea>
                    </div>

                    <div class="pt-3 border-top text-end">
                        <button type="submit" class="btn btn-primary rounded-pill px-5 shadow">
                            <i class="bi bi-check-circle me-1"></i> Submit & Release Digital Report
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
