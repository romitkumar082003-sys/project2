<?php
// MediCareX - Lab Test Requests List
// Developed by Romit Kumar

$pageTitle = 'Test Requests';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole(['Lab Technician', 'Admin']);

$user = getCurrentUser();
$pdo = getDBConnection();

$requests = $pdo->query("
    SELECT req.*, lt.test_name, lt.category, p.patient_code, u_p.name as patient_name, u_d.name as doctor_name
    FROM lab_requests req
    JOIN lab_tests lt ON req.test_id = lt.id
    JOIN patients p ON req.patient_id = p.id
    JOIN users u_p ON p.user_id = u_p.id
    JOIN doctors d ON req.doctor_id = d.id
    JOIN users u_d ON d.user_id = u_d.id
    ORDER BY req.id DESC
")->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold mb-0">Lab Test Request Workload</h3>
            </div>

            <div class="card card-custom border-0 shadow-sm">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0 fs-7">
                            <thead class="table-light text-uppercase">
                                <tr>
                                    <th>Code</th>
                                    <th>Patient</th>
                                    <th>Test Requested</th>
                                    <th>Category</th>
                                    <th>Ordering Doctor</th>
                                    <th>Status</th>
                                    <th class="text-end">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($requests as $req): ?>
                                    <tr>
                                        <td class="fw-bold text-primary"><?= htmlspecialchars($req['request_code']) ?></td>
                                        <td class="fw-bold"><?= htmlspecialchars($req['patient_name']) ?> (<?= htmlspecialchars($req['patient_code']) ?>)</td>
                                        <td class="fw-bold"><?= htmlspecialchars($req['test_name']) ?></td>
                                        <td><span class="badge bg-secondary"><?= htmlspecialchars($req['category']) ?></span></td>
                                        <td><?= htmlspecialchars($req['doctor_name']) ?></td>
                                        <td><?= renderStatusBadge($req['status']) ?></td>
                                        <td class="text-end">
                                            <?php if ($req['status'] !== 'Completed'): ?>
                                                <a href="upload_report.php?request_id=<?= $req['id'] ?>" class="btn btn-sm btn-primary rounded-pill px-3">
                                                    Enter Results
                                                </a>
                                            <?php else: ?>
                                                <span class="text-muted fs-7">Report Released</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
