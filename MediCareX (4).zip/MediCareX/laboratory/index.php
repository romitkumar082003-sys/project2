<?php
// MediCareX - Laboratory Workbench Dashboard
// Developed by Romit Kumar

$pageTitle = 'Laboratory Workbench';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole(['Lab Technician', 'Admin']);

$user = getCurrentUser();
$pdo = getDBConnection();

$cntPending = $pdo->query("SELECT COUNT(*) FROM lab_requests WHERE status IN ('Pending', 'In Progress')")->fetchColumn();
$cntCompleted = $pdo->query("SELECT COUNT(*) FROM lab_reports")->fetchColumn();

$requests = $pdo->query("
    SELECT req.*, lt.test_name, lt.category, p.patient_code, u_p.name as patient_name, u_d.name as doctor_name
    FROM lab_requests req
    JOIN lab_tests lt ON req.test_id = lt.id
    JOIN patients p ON req.patient_id = p.id
    JOIN users u_p ON p.user_id = u_p.id
    JOIN doctors d ON req.doctor_id = d.id
    JOIN users u_d ON d.user_id = u_d.id
    WHERE req.status IN ('Pending', 'In Progress')
    ORDER BY req.id DESC
")->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <?php displayFlash(); ?>

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1">Laboratory Diagnostics Workbench</h3>
                    <p class="text-muted mb-0">Process doctor lab test orders, input test findings, and release digital reports</p>
                </div>
                <a href="test_requests.php" class="btn btn-primary rounded-pill px-4 shadow-sm"><i class="bi bi-hourglass-split me-1"></i> Pending Requests</a>
            </div>

            <!-- KPIs -->
            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <div class="card card-custom card-kpi card-kpi-warning p-3">
                        <small class="text-muted fw-bold text-uppercase fs-8">Pending Test Orders</small>
                        <h2 class="fw-bold mb-0 text-warning"><?= $cntPending ?></h2>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card card-custom card-kpi card-kpi-success p-3">
                        <small class="text-muted fw-bold text-uppercase fs-8">Completed Reports</small>
                        <h2 class="fw-bold mb-0 text-success"><?= $cntCompleted ?></h2>
                    </div>
                </div>
            </div>

            <!-- Pending Requests Table -->
            <div class="card card-custom border-0 shadow-sm">
                <div class="card-header bg-body border-0 py-3">
                    <h5 class="fw-bold mb-0"><i class="bi bi-journal-medical me-2 text-primary"></i> Pending Diagnostic Test Workload</h5>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0 fs-7">
                        <thead class="table-light text-uppercase">
                            <tr>
                                <th>Code</th>
                                <th>Patient Name</th>
                                <th>Test Requested</th>
                                <th>Category</th>
                                <th>Ordering Doctor</th>
                                <th>Priority</th>
                                <th class="text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($requests)): ?>
                                <tr><td colspan="7" class="text-center py-5 text-muted"><i class="bi bi-check-circle-fill text-success fs-1 d-block mb-2"></i> All diagnostic test orders have been processed!</td></tr>
                            <?php else: ?>
                                <?php foreach ($requests as $req): ?>
                                    <tr>
                                        <td class="fw-bold text-primary"><?= htmlspecialchars($req['request_code']) ?></td>
                                        <td class="fw-bold"><?= htmlspecialchars($req['patient_name']) ?> (<?= htmlspecialchars($req['patient_code']) ?>)</td>
                                        <td class="fw-bold"><?= htmlspecialchars($req['test_name']) ?></td>
                                        <td><span class="badge bg-secondary"><?= htmlspecialchars($req['category']) ?></span></td>
                                        <td><?= htmlspecialchars($req['doctor_name']) ?></td>
                                        <td><span class="badge bg-warning text-dark"><?= htmlspecialchars($req['priority']) ?></span></td>
                                        <td class="text-end">
                                            <a href="upload_report.php?request_id=<?= $req['id'] ?>" class="btn btn-sm btn-primary rounded-pill px-3 shadow-sm">
                                                <i class="bi bi-pencil-square me-1"></i> Enter Results
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
