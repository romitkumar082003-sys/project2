<?php
// MediCareX - Patient Prescriptions Archive
// Developed by Romit Kumar

$pageTitle = 'My Prescriptions';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole('Patient');

$user = getCurrentUser();
$pdo = getDBConnection();

$patStmt = $pdo->prepare("SELECT id FROM patients WHERE user_id = ?");
$patStmt->execute([$user['id']]);
$patient_id = $patStmt->fetchColumn();

$rxs = $pdo->prepare("
    SELECT rx.*, c.diagnosis, u_d.name as doctor_name, dep.dept_name
    FROM prescriptions rx
    LEFT JOIN consultations c ON rx.consultation_id = c.id
    JOIN doctors d ON rx.doctor_id = d.id
    JOIN users u_d ON d.user_id = u_d.id
    JOIN departments dep ON d.department_id = dep.id
    WHERE rx.patient_id = ?
    ORDER BY rx.created_at DESC
");
$rxs->execute([$patient_id]);
$prescriptionList = $rxs->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1">Digital Prescriptions</h3>
                    <p class="text-muted mb-0">View and print official electronic prescriptions issued by your attending physicians</p>
                </div>
            </div>

            <div class="row g-4">
                <?php if (empty($prescriptionList)): ?>
                    <div class="col-12">
                        <div class="card card-custom p-5 text-center text-muted">
                            <i class="bi bi-capsule-pill fs-1 mb-2"></i>
                            <h5>No Prescriptions Found</h5>
                            <p class="fs-7 mb-0">Prescriptions issued during consultations will appear here.</p>
                        </div>
                    </div>
                <?php else: ?>
                    <?php foreach ($prescriptionList as $rx): ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="card card-custom p-4 h-100 d-flex flex-column justify-content-between">
                                <div>
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <span class="badge bg-primary bg-opacity-10 text-primary">Rx #<?= $rx['id'] ?></span>
                                        <small class="text-muted"><?= formatDate($rx['created_at'], 'd M Y') ?></small>
                                    </div>
                                    <h5 class="fw-bold mb-1"><?= htmlspecialchars($rx['doctor_name']) ?></h5>
                                    <span class="badge bg-secondary mb-3 fs-8"><?= htmlspecialchars($rx['dept_name']) ?></span>
                                    
                                    <div class="fs-7 mb-3">
                                        <strong>Diagnosis:</strong><br>
                                        <span class="text-dark fw-semibold"><?= htmlspecialchars($rx['diagnosis'] ?? 'Clinical Evaluation') ?></span>
                                    </div>
                                </div>
                                <div class="pt-3 border-top">
                                    <a href="<?= get_base_url() ?>/print_prescription.php?id=<?= $rx['id'] ?>" target="_blank" class="btn btn-outline-primary btn-sm rounded-pill w-100">
                                        <i class="bi bi-printer me-1"></i> Print / Download PDF
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
