<?php
// MediCareX - Patient Profile Settings
// Developed by Romit Kumar

$pageTitle = 'Patient Profile';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

requireRole('Patient');

$user = getCurrentUser();
$pdo = getDBConnection();

$patStmt = $pdo->prepare("SELECT * FROM patients WHERE user_id = ?");
$patStmt->execute([$user['id']]);
$patient = $patStmt->fetch();

$errorMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validateCSRFOrDie();
    
    $name = cleanInput($_POST['name'] ?? '');
    $phone = cleanInput($_POST['phone'] ?? '');
    $dob = cleanInput($_POST['dob'] ?? '');
    $gender = cleanInput($_POST['gender'] ?? 'Male');
    $blood_group = cleanInput($_POST['blood_group'] ?? 'O+');
    $address = cleanInput($_POST['address'] ?? '');
    $emergency_contact = cleanInput($_POST['emergency_contact'] ?? '');

    $updU = $pdo->prepare("UPDATE users SET name = ?, phone = ? WHERE id = ?");
    $updU->execute([$name, $phone, $user['id']]);

    $updP = $pdo->prepare("UPDATE patients SET dob = ?, gender = ?, blood_group = ?, address = ?, emergency_contact = ? WHERE id = ?");
    $updP->execute([$dob, $gender, $blood_group, $address, $emergency_contact, $patient['id']]);

    logAudit($user['id'], $name, 'Patient', 'PROFILE_UPDATE', "Updated patient profile details.");
    setFlash('success', "Profile updated successfully.");
    header("Location: profile.php");
    exit();
}

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <?php displayFlash(); ?>

            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold mb-0">My Patient Profile</h3>
            </div>

            <div class="card card-custom p-4 border-0 shadow-sm" style="max-width: 800px;">
                <form method="POST" action="">
                    <?= renderCSRFField() ?>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Patient Code</label>
                            <input type="text" class="form-control bg-light" value="<?= htmlspecialchars($patient['patient_code']) ?>" readonly>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Email Address</label>
                            <input type="text" class="form-control bg-light" value="<?= htmlspecialchars($user['email']) ?>" readonly>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Full Name *</label>
                            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($user['name']) ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Mobile Phone *</label>
                            <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($user['phone']) ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Date of Birth</label>
                            <input type="date" name="dob" class="form-control" value="<?= htmlspecialchars($patient['dob']) ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Gender</label>
                            <select name="gender" class="form-select">
                                <option value="Male" <?= ($patient['gender'] === 'Male') ? 'selected' : '' ?>>Male</option>
                                <option value="Female" <?= ($patient['gender'] === 'Female') ? 'selected' : '' ?>>Female</option>
                                <option value="Other" <?= ($patient['gender'] === 'Other') ? 'selected' : '' ?>>Other</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Blood Group</label>
                            <select name="blood_group" class="form-select">
                                <?php foreach (['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] as $bg): ?>
                                    <option value="<?= $bg ?>" <?= ($patient['blood_group'] === $bg) ? 'selected' : '' ?>><?= $bg ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Emergency Contact</label>
                            <input type="text" name="emergency_contact" class="form-control" value="<?= htmlspecialchars($patient['emergency_contact'] ?? '') ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">Residential Address</label>
                            <textarea name="address" class="form-control" rows="2"><?= htmlspecialchars($patient['address'] ?? '') ?></textarea>
                        </div>
                    </div>
                    <div class="mt-4 pt-3 border-top text-end">
                        <button type="submit" class="btn btn-primary rounded-pill px-4 shadow-sm">
                            <i class="bi bi-save me-1"></i> Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
