<?php
// MediCareX - Patient Appointment Booking Wizard
// Developed by Romit Kumar

$pageTitle = 'Book Appointment';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

requireRole('Patient');

$user = getCurrentUser();
$pdo = getDBConnection();

$patStmt = $pdo->prepare("SELECT * FROM patients WHERE user_id = ?");
$patStmt->execute([$user['id']]);
$patient = $patStmt->fetch();

// If patient record is missing, auto-create a default patient profile for this user
if (!$patient) {
    $patCode = generateCode('PAT', 'patients', 'patient_code');
    $insPat = $pdo->prepare("INSERT INTO patients (user_id, patient_code, gender, blood_group) VALUES (?, ?, 'Not Specified', 'O+')");
    $insPat->execute([$user['id'], $patCode]);
    $patient_id = $pdo->lastInsertId();
    $patient = ['id' => $patient_id, 'patient_code' => $patCode, 'blood_group' => 'O+', 'gender' => 'Not Specified'];
} else {
    $patient_id = $patient['id'];
}

$departments = $pdo->query("SELECT * FROM departments WHERE status = 'Active' ORDER BY id ASC")->fetchAll();
$doctors = $pdo->query("
    SELECT d.*, u.name, u.phone, u.email, dep.dept_name, dep.icon as dept_icon
    FROM doctors d 
    JOIN users u ON d.user_id = u.id 
    JOIN departments dep ON d.department_id = dep.id 
    WHERE u.status = 'Active'
    ORDER BY dep.dept_name ASC, u.name ASC
")->fetchAll();

$errorMsg = '';
$successMsg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validateCSRFOrDie();

    $department_id = intval($_POST['department_id'] ?? 0);
    $doctor_id = intval($_POST['doctor_id'] ?? 0);
    $appointment_date = cleanInput($_POST['appointment_date'] ?? '');
    $time_slot = cleanInput($_POST['time_slot'] ?? '');
    $reason = cleanInput($_POST['reason'] ?? '');

    if (!$doctor_id || !$appointment_date || !$time_slot) {
        $errorMsg = "Please select a doctor, appointment date, and time slot.";
    } elseif (strtotime($appointment_date) < strtotime(date('Y-m-d'))) {
        $errorMsg = "Appointment date cannot be in the past.";
    } else {
        // Auto resolve department if not provided
        if (!$department_id) {
            $dStmt = $pdo->prepare("SELECT department_id FROM doctors WHERE id = ?");
            $dStmt->execute([$doctor_id]);
            $department_id = intval($dStmt->fetchColumn() ?: 1);
        }

        // Double-Booking Check
        $chk = $pdo->prepare("
            SELECT COUNT(*) FROM appointments 
            WHERE doctor_id = ? AND appointment_date = ? AND time_slot = ? AND status != 'Cancelled'
        ");
        $chk->execute([$doctor_id, $appointment_date, $time_slot]);
        
        if ($chk->fetchColumn() > 0) {
            $errorMsg = "Selected Doctor already has a booked appointment on {$appointment_date} at {$time_slot}. Please choose another time slot or date.";
        } else {
            // Generate sequential daily token number e.g. A-001
            $tokStmt = $pdo->prepare("SELECT COUNT(*) FROM appointments WHERE doctor_id = ? AND appointment_date = ?");
            $tokStmt->execute([$doctor_id, $appointment_date]);
            $tokNum = $tokStmt->fetchColumn() + 1;
            $token_number = 'A-' . str_pad($tokNum, 3, '0', STR_PAD_LEFT);
            
            $apt_code = generateCode('APT', 'appointments', 'appointment_code');

            $ins = $pdo->prepare("
                INSERT INTO appointments (appointment_code, patient_id, doctor_id, department_id, appointment_date, time_slot, token_number, reason, status) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Confirmed')
            ");
            $ins->execute([$apt_code, $patient_id, $doctor_id, $department_id, $appointment_date, $time_slot, $token_number, $reason]);

            // Notify patient & doctor
            addNotification($user['id'], 'Appointment Confirmed', "Your appointment {$apt_code} has been booked for {$appointment_date} ({$time_slot}). Queue Token: {$token_number}.", 'patient/my_appointments.php');
            
            $docUserStmt = $pdo->prepare("SELECT user_id FROM doctors WHERE id = ?");
            $docUserStmt->execute([$doctor_id]);
            $docUserId = $docUserStmt->fetchColumn();
            if ($docUserId) {
                addNotification($docUserId, 'New Appointment Booked', "Patient {$user['name']} booked for {$appointment_date} ({$time_slot}). Token: {$token_number}.", 'doctor/appointments.php');
            }

            logAudit($user['id'], $user['name'], 'Patient', 'APPOINTMENT_BOOK', "Booked appointment {$apt_code} with Token {$token_number}.");

            setFlash('success', "Appointment booked successfully! Your Token Number is <strong>{$token_number}</strong> (Code: <strong>{$apt_code}</strong>).");
            header("Location: " . get_base_url() . "/patient/my_appointments.php");
            exit();
        }
    }
}

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-3 p-md-4">
            
            <!-- Page Header -->
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-2 mb-4">
                <div>
                    <h3 class="fw-bold mb-1"><i class="bi bi-calendar-plus text-primary me-2"></i>Book Doctor Appointment</h3>
                    <p class="text-muted mb-0 fs-7">Select department, specialist doctor, preferred date & time slot for instant token generation.</p>
                </div>
                <a href="my_appointments.php" class="btn btn-outline-secondary rounded-pill px-3 shadow-sm fs-7">
                    <i class="bi bi-journal-text me-1"></i> My Appointments
                </a>
            </div>

            <?php if ($errorMsg): ?>
                <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm mb-4" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2 fs-5"></i> <?= htmlspecialchars($errorMsg) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <form method="POST" action="" id="appointmentForm">
                <?= renderCSRFField() ?>

                <div class="row g-4">
                    
                    <!-- Left Main Form (7 cols on desktop) -->
                    <div class="col-lg-7 col-xl-8">
                        
                        <!-- Step 1: Specialty & Doctor Selection -->
                        <div class="card card-custom p-4 border-0 shadow-sm mb-4">
                            <div class="d-flex align-items-center mb-3">
                                <span class="badge bg-primary rounded-circle p-2 me-2 d-inline-flex align-items-center justify-content-center" style="width: 28px; height: 28px;">1</span>
                                <h5 class="fw-bold mb-0">Select Department & Doctor</h5>
                            </div>

                            <div class="row g-3">
                                <!-- Department Dropdown -->
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Medical Department <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-body-tertiary"><i class="bi bi-hospital text-muted"></i></span>
                                        <select name="department_id" id="deptSelect" class="form-select">
                                            <option value="">-- All Departments (<?= count($departments) ?> Available) --</option>
                                            <?php foreach ($departments as $dept): ?>
                                                <option value="<?= $dept['id'] ?>">
                                                    <?= htmlspecialchars($dept['dept_name']) ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <small class="text-muted fs-8">Filter doctors by medical specialty</small>
                                </div>

                                <!-- Doctor Dropdown -->
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Specialist Doctor <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-body-tertiary"><i class="bi bi-heart-pulse text-muted"></i></span>
                                        <select name="doctor_id" id="docSelect" class="form-select" required>
                                            <option value="">-- Choose Specialist Doctor --</option>
                                        </select>
                                    </div>
                                    <small class="text-muted fs-8" id="docCountHint">Showing all available specialists</small>
                                </div>
                            </div>

                            <!-- Doctor Live Detail Preview Card -->
                            <div id="doctorPreviewCard" class="mt-4 p-3 rounded-3 border bg-body-tertiary shadow-sm d-none">
                                <div class="d-flex flex-column flex-sm-row align-items-start align-items-sm-center gap-3">
                                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center fw-bold fs-4 flex-shrink-0" style="width: 58px; height: 58px;" id="prevAvatar">
                                        DR
                                    </div>
                                    <div class="flex-grow-1">
                                        <div class="d-flex flex-wrap align-items-center gap-2 mb-1">
                                            <h5 class="fw-bold mb-0 text-body" id="prevName">Doctor Name</h5>
                                            <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25 rounded-pill fs-8">
                                                <i class="bi bi-patch-check-fill me-1"></i> Verified Specialist
                                            </span>
                                            <span class="badge bg-primary rounded-pill fs-8" id="prevDeptBadge">Cardiology</span>
                                        </div>
                                        <p class="fs-7 text-muted mb-1" id="prevSpec">Interventional Cardiology • MBBS, MD, DM</p>
                                        <div class="d-flex flex-wrap gap-3 fs-8 text-muted">
                                            <span><i class="bi bi-award text-warning me-1"></i><strong id="prevExp">10</strong> yrs exp</span>
                                            <span><i class="bi bi-clock-history text-info me-1"></i><span id="prevTime">09:00 AM - 02:00 PM</span></span>
                                            <span><i class="bi bi-calendar3 text-secondary me-1"></i><span id="prevDays">Mon-Fri</span></span>
                                        </div>
                                    </div>
                                    <div class="text-sm-end align-self-sm-center mt-2 mt-sm-0 flex-shrink-0">
                                        <small class="text-muted d-block fs-8">Consultation Fee</small>
                                        <h4 class="fw-bold text-success mb-0" id="prevFee">₹500.00</h4>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Step 2: Date & Slot Selection -->
                        <div class="card card-custom p-4 border-0 shadow-sm mb-4">
                            <div class="d-flex align-items-center mb-3">
                                <span class="badge bg-primary rounded-circle p-2 me-2 d-inline-flex align-items-center justify-content-center" style="width: 28px; height: 28px;">2</span>
                                <h5 class="fw-bold mb-0">Choose Date & Time Slot</h5>
                            </div>

                            <div class="row g-3 mb-3">
                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Appointment Date <span class="text-danger">*</span></label>
                                    <input type="date" name="appointment_date" id="aptDate" class="form-control" min="<?= date('Y-m-d') ?>" value="<?= date('Y-m-d') ?>" required>
                                    <small class="text-muted fs-8">Same-day or future consultations available</small>
                                </div>

                                <div class="col-md-6">
                                    <label class="form-label fw-semibold">Selected Time Slot <span class="text-danger">*</span></label>
                                    <input type="text" name="time_slot" id="timeSlotInput" class="form-control bg-body-tertiary fw-bold text-primary" value="09:30 AM" readonly required>
                                    <small class="text-muted fs-8">Tap on any slot pill below</small>
                                </div>
                            </div>

                            <!-- Interactive Visual Time Slot Pills -->
                            <div class="mb-2">
                                <label class="form-label fw-semibold fs-7 text-muted text-uppercase mb-2">
                                    <i class="bi bi-sun text-warning me-1"></i> Morning OPD Slots (09:00 AM - 12:00 PM)
                                </label>
                                <div class="d-flex flex-wrap gap-2 mb-3" id="morningSlots">
                                    <button type="button" class="btn btn-outline-primary btn-sm slot-btn active" data-slot="09:00 AM">09:00 AM</button>
                                    <button type="button" class="btn btn-outline-primary btn-sm slot-btn" data-slot="09:30 AM">09:30 AM</button>
                                    <button type="button" class="btn btn-outline-primary btn-sm slot-btn" data-slot="10:00 AM">10:00 AM</button>
                                    <button type="button" class="btn btn-outline-primary btn-sm slot-btn" data-slot="10:30 AM">10:30 AM</button>
                                    <button type="button" class="btn btn-outline-primary btn-sm slot-btn" data-slot="11:00 AM">11:00 AM</button>
                                    <button type="button" class="btn btn-outline-primary btn-sm slot-btn" data-slot="11:30 AM">11:30 AM</button>
                                </div>

                                <label class="form-label fw-semibold fs-7 text-muted text-uppercase mb-2">
                                    <i class="bi bi-sunset text-danger me-1"></i> Afternoon OPD Slots (01:00 PM - 05:00 PM)
                                </label>
                                <div class="d-flex flex-wrap gap-2" id="afternoonSlots">
                                    <button type="button" class="btn btn-outline-primary btn-sm slot-btn" data-slot="01:00 PM">01:00 PM</button>
                                    <button type="button" class="btn btn-outline-primary btn-sm slot-btn" data-slot="01:30 PM">01:30 PM</button>
                                    <button type="button" class="btn btn-outline-primary btn-sm slot-btn" data-slot="02:00 PM">02:00 PM</button>
                                    <button type="button" class="btn btn-outline-primary btn-sm slot-btn" data-slot="02:30 PM">02:30 PM</button>
                                    <button type="button" class="btn btn-outline-primary btn-sm slot-btn" data-slot="03:00 PM">03:00 PM</button>
                                    <button type="button" class="btn btn-outline-primary btn-sm slot-btn" data-slot="03:30 PM">03:30 PM</button>
                                    <button type="button" class="btn btn-outline-primary btn-sm slot-btn" data-slot="04:00 PM">04:00 PM</button>
                                </div>
                            </div>
                        </div>

                        <!-- Step 3: Symptoms / Reason -->
                        <div class="card card-custom p-4 border-0 shadow-sm mb-4">
                            <div class="d-flex align-items-center mb-3">
                                <span class="badge bg-primary rounded-circle p-2 me-2 d-inline-flex align-items-center justify-content-center" style="width: 28px; height: 28px;">3</span>
                                <h5 class="fw-bold mb-0">Reason for Visit / Symptoms</h5>
                            </div>

                            <div>
                                <textarea name="reason" id="reasonInput" class="form-control" rows="3" placeholder="Please describe your health issue or main symptoms (e.g. chest discomfort, headache, joint pain, cough for 3 days)..."></textarea>
                                <small class="text-muted fs-8">This helps your doctor prepare relevant diagnostics prior to your consultation.</small>
                            </div>
                        </div>

                    </div>

                    <!-- Right Sticky Summary Card (5 cols on desktop) -->
                    <div class="col-lg-5 col-xl-4">
                        <div class="card card-custom p-4 border-0 shadow-lg sticky-top" style="top: 85px;">
                            <h5 class="fw-bold mb-3 pb-2 border-bottom">
                                <i class="bi bi-ticket-perforated text-primary me-2"></i>Booking Summary
                            </h5>

                            <!-- Patient Info Widget -->
                            <div class="d-flex align-items-center p-3 rounded-3 bg-body-tertiary mb-3 border">
                                <div class="rounded-circle bg-success text-white d-flex align-items-center justify-content-center fw-bold me-3" style="width: 42px; height: 42px;">
                                    <?= strtoupper(substr($user['name'], 0, 1)) ?>
                                </div>
                                <div>
                                    <div class="fw-bold text-body"><?= htmlspecialchars($user['name']) ?></div>
                                    <div class="fs-8 text-muted">ID: <span class="text-primary fw-semibold"><?= htmlspecialchars($patient['patient_code'] ?? 'PAT-7001') ?></span> • Blood: <?= htmlspecialchars($patient['blood_group'] ?? 'O+') ?></div>
                                </div>
                            </div>

                            <!-- Live Summary Line Items -->
                            <ul class="list-unstyled fs-7 mb-4">
                                <li class="d-flex justify-content-between py-2 border-bottom">
                                    <span class="text-muted"><i class="bi bi-hospital me-1"></i> Department:</span>
                                    <strong class="text-body text-end" id="sumDept">Cardiology</strong>
                                </li>
                                <li class="d-flex justify-content-between py-2 border-bottom">
                                    <span class="text-muted"><i class="bi bi-heart-pulse me-1"></i> Doctor:</span>
                                    <strong class="text-primary text-end" id="sumDoc">Dr. Ankit Sharma</strong>
                                </li>
                                <li class="d-flex justify-content-between py-2 border-bottom">
                                    <span class="text-muted"><i class="bi bi-calendar3 me-1"></i> Date:</span>
                                    <strong class="text-body text-end" id="sumDate"><?= date('d M, Y') ?></strong>
                                </li>
                                <li class="d-flex justify-content-between py-2 border-bottom">
                                    <span class="text-muted"><i class="bi bi-clock me-1"></i> Time Slot:</span>
                                    <strong class="text-body text-end" id="sumSlot">09:00 AM</strong>
                                </li>
                                <li class="d-flex justify-content-between py-2 border-bottom align-items-center">
                                    <span class="text-muted"><i class="bi bi-tag me-1"></i> Consultation Fee:</span>
                                    <span class="badge bg-success fs-6 fw-bold" id="sumFee">₹800.00</span>
                                </li>
                            </ul>

                            <div class="alert alert-info border-0 rounded-3 p-3 fs-8 mb-4">
                                <div class="d-flex align-items-start">
                                    <i class="bi bi-info-circle-fill fs-5 text-info me-2 mt-n1"></i>
                                    <div>
                                        <strong>Token Assurance:</strong> An OPD Queue Token (e.g. <code>A-001</code>) will be generated automatically. You can track your queue status live!
                                    </div>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary btn-lg rounded-pill w-100 shadow fw-bold py-3">
                                <i class="bi bi-check-circle-fill me-2"></i> Confirm Appointment
                            </button>

                            <div class="text-center mt-3 fs-8 text-muted">
                                <i class="bi bi-shield-check text-success me-1"></i> MediCareX Double-Booking Prevention Active
                            </div>
                        </div>
                    </div>

                </div>
            </form>

        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>

<script>
// Complete doctors roster from PHP
const doctorsList = <?= json_encode($doctors) ?>;

const deptSelect = document.getElementById('deptSelect');
const docSelect = document.getElementById('docSelect');
const docCountHint = document.getElementById('docCountHint');

const doctorPreviewCard = document.getElementById('doctorPreviewCard');
const prevAvatar = document.getElementById('prevAvatar');
const prevName = document.getElementById('prevName');
const prevDeptBadge = document.getElementById('prevDeptBadge');
const prevSpec = document.getElementById('prevSpec');
const prevExp = document.getElementById('prevExp');
const prevTime = document.getElementById('prevTime');
const prevDays = document.getElementById('prevDays');
const prevFee = document.getElementById('prevFee');

const aptDate = document.getElementById('aptDate');
const timeSlotInput = document.getElementById('timeSlotInput');
const slotBtns = document.querySelectorAll('.slot-btn');

const sumDept = document.getElementById('sumDept');
const sumDoc = document.getElementById('sumDoc');
const sumDate = document.getElementById('sumDate');
const sumSlot = document.getElementById('sumSlot');
const sumFee = document.getElementById('sumFee');

// Populate Doctor Select options based on department
function populateDoctors(selectedDeptId, preferredDocId = null) {
    docSelect.innerHTML = '';
    
    let filtered = doctorsList;
    if (selectedDeptId) {
        filtered = doctorsList.filter(d => parseInt(d.department_id) === parseInt(selectedDeptId));
    }

    if (filtered.length === 0) {
        const opt = document.createElement('option');
        opt.value = '';
        opt.textContent = '-- No Doctor Available in this Department --';
        docSelect.appendChild(opt);
        docCountHint.textContent = '0 doctors in this department';
        hidePreview();
        return;
    }

    const defaultOpt = document.createElement('option');
    defaultOpt.value = '';
    defaultOpt.textContent = `-- Choose Doctor (${filtered.length} Available) --`;
    docSelect.appendChild(defaultOpt);

    filtered.forEach(doc => {
        const opt = document.createElement('option');
        opt.value = doc.id;
        opt.textContent = `${doc.name} (${doc.dept_name} • ${doc.specialization} - ₹${parseFloat(doc.consultation_fee).toFixed(2)})`;
        opt.dataset.deptId = doc.department_id;
        opt.dataset.docId = doc.id;
        if (preferredDocId && parseInt(doc.id) === parseInt(preferredDocId)) {
            opt.selected = true;
        }
        docSelect.appendChild(opt);
    });

    docCountHint.textContent = `${filtered.length} specialist doctor${filtered.length > 1 ? 's' : ''} available`;

    // If preferredDocId was given or if there's only 1 doctor, auto select
    if (preferredDocId) {
        docSelect.value = preferredDocId;
        updatePreview(preferredDocId);
    } else if (filtered.length === 1) {
        docSelect.value = filtered[0].id;
        updatePreview(filtered[0].id);
    } else {
        // Auto select first doctor for quick convenient demo
        docSelect.value = filtered[0].id;
        updatePreview(filtered[0].id);
    }
}

function updatePreview(doctorId) {
    const doc = doctorsList.find(d => parseInt(d.id) === parseInt(doctorId));
    if (!doc) {
        hidePreview();
        return;
    }

    doctorPreviewCard.classList.remove('d-none');
    prevAvatar.textContent = doc.name.replace('Dr. ', '').substring(0, 2).toUpperCase();
    prevName.textContent = doc.name;
    prevDeptBadge.textContent = doc.dept_name;
    prevSpec.textContent = `${doc.specialization} • ${doc.qualification}`;
    prevExp.textContent = doc.experience_years || 8;
    prevTime.textContent = doc.availability_time || '09:00 AM - 02:00 PM';
    prevDays.textContent = doc.availability_days || 'Mon - Fri';
    prevFee.textContent = '₹' + parseFloat(doc.consultation_fee).toFixed(2);

    // Sync summary
    sumDept.textContent = doc.dept_name;
    sumDoc.textContent = doc.name;
    sumFee.textContent = '₹' + parseFloat(doc.consultation_fee).toFixed(2);
    
    // Also sync department dropdown if not set
    if (!deptSelect.value || parseInt(deptSelect.value) !== parseInt(doc.department_id)) {
        deptSelect.value = doc.department_id;
    }
}

function hidePreview() {
    doctorPreviewCard.classList.add('d-none');
    sumDoc.textContent = 'None Selected';
    sumFee.textContent = '₹0.00';
}

// Department dropdown change handler
deptSelect.addEventListener('change', function() {
    populateDoctors(this.value);
});

// Doctor dropdown change handler
docSelect.addEventListener('change', function() {
    const docId = this.value;
    if (docId) {
        updatePreview(docId);
    } else {
        hidePreview();
    }
});

// Slot pill button handlers
slotBtns.forEach(btn => {
    btn.addEventListener('click', function() {
        slotBtns.forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        const slot = this.getAttribute('data-slot');
        timeSlotInput.value = slot;
        sumSlot.textContent = slot;
    });
});

// Date change handler
aptDate.addEventListener('change', function() {
    if (this.value) {
        const d = new Date(this.value);
        const options = { day: 'numeric', month: 'short', year: 'numeric' };
        sumDate.textContent = d.toLocaleDateString('en-GB', options);
    }
});

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    // Populate with all doctors initially
    populateDoctors('');
    // Set initial slot
    if (slotBtns.length > 0) {
        slotBtns[0].click();
    }
});
</script>
