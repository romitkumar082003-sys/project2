<?php
// MediCareX - Patient Appointment Management
// Developed by Romit Kumar

$pageTitle = 'My Appointments';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole('Patient');

$user = getCurrentUser();
$pdo = getDBConnection();

$patStmt = $pdo->prepare("SELECT id FROM patients WHERE user_id = ?");
$patStmt->execute([$user['id']]);
$patient_id = $patStmt->fetchColumn();

// Cancel action
if (isset($_GET['action']) && $_GET['action'] === 'cancel') {
    $apt_id = intval($_GET['id'] ?? 0);
    $upd = $pdo->prepare("UPDATE appointments SET status = 'Cancelled' WHERE id = ? AND patient_id = ?");
    $upd->execute([$apt_id, $patient_id]);
    logAudit($user['id'], $user['name'], 'Patient', 'APPOINTMENT_CANCEL', "Cancelled appointment ID {$apt_id}.");
    setFlash('warning', "Appointment cancelled successfully.");
    header("Location: my_appointments.php");
    exit();
}

$statusFilter = cleanInput($_GET['status'] ?? 'All');
$query = "
    SELECT a.*, d.specialization, d.consultation_fee, u_d.name as doctor_name, dep.dept_name 
    FROM appointments a
    JOIN doctors d ON a.doctor_id = d.id
    JOIN users u_d ON d.user_id = u_d.id
    JOIN departments dep ON a.department_id = dep.id
    WHERE a.patient_id = ?
";
$params = [$patient_id];

if ($statusFilter !== 'All') {
    $query .= " AND a.status = ?";
    $params[] = $statusFilter;
}

$query .= " ORDER BY a.appointment_date DESC, a.id DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$appointments = $stmt->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <?php displayFlash(); ?>

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1">My Appointments</h3>
                    <p class="text-muted mb-0">Track your consultation schedule and OPD tokens</p>
                </div>
                <a href="book_appointment.php" class="btn btn-primary rounded-pill px-4 shadow-sm">
                    <i class="bi bi-plus-lg me-2"></i> New Booking
                </a>
            </div>

            <!-- Filter Tabs -->
            <div class="d-flex gap-2 mb-4 overflow-auto pb-2">
                <a href="my_appointments.php?status=All" class="btn btn-sm <?= ($statusFilter === 'All') ? 'btn-primary' : 'btn-outline-secondary' ?> rounded-pill">All</a>
                <a href="my_appointments.php?status=Confirmed" class="btn btn-sm <?= ($statusFilter === 'Confirmed') ? 'btn-primary' : 'btn-outline-secondary' ?> rounded-pill">Confirmed</a>
                <a href="my_appointments.php?status=Checked In" class="btn btn-sm <?= ($statusFilter === 'Checked In') ? 'btn-primary' : 'btn-outline-secondary' ?> rounded-pill">Checked In</a>
                <a href="my_appointments.php?status=Completed" class="btn btn-sm <?= ($statusFilter === 'Completed') ? 'btn-primary' : 'btn-outline-secondary' ?> rounded-pill">Completed</a>
                <a href="my_appointments.php?status=Cancelled" class="btn btn-sm <?= ($statusFilter === 'Cancelled') ? 'btn-primary' : 'btn-outline-secondary' ?> rounded-pill">Cancelled</a>
            </div>

            <div class="card card-custom border-0 shadow-sm">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light fs-7 text-uppercase">
                                <tr>
                                    <th>Appointment Code</th>
                                    <th>Doctor</th>
                                    <th>Department</th>
                                    <th>Date & Slot</th>
                                    <th>OPD Token</th>
                                    <th>Fee</th>
                                    <th>Status</th>
                                    <th class="text-end">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($appointments)): ?>
                                    <tr>
                                        <td colspan="8" class="text-center py-5 text-muted">
                                            <i class="bi bi-journal-x fs-1 d-block mb-2"></i>
                                            No appointments match the selected status filter.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($appointments as $apt): ?>
                                        <tr>
                                            <td class="fw-bold text-primary"><?= htmlspecialchars($apt['appointment_code']) ?></td>
                                            <td>
                                                <div class="fw-bold"><?= htmlspecialchars($apt['doctor_name']) ?></div>
                                                <small class="text-muted"><?= htmlspecialchars($apt['specialization']) ?></small>
                                            </td>
                                            <td><?= htmlspecialchars($apt['dept_name']) ?></td>
                                            <td>
                                                <div class="fw-semibold"><?= formatDate($apt['appointment_date'], 'd M Y') ?></div>
                                                <small class="text-muted"><?= htmlspecialchars($apt['time_slot']) ?></small>
                                            </td>
                                            <td><span class="badge bg-primary px-3 py-2 fs-7"><?= htmlspecialchars($apt['token_number']) ?></span></td>
                                            <td><?= formatCurrency($apt['consultation_fee']) ?></td>
                                            <td><?= renderStatusBadge($apt['status']) ?></td>
                                            <td class="text-end">
                                                <?php if (in_array($apt['status'], ['Pending', 'Confirmed'])): ?>
                                                    <a href="my_appointments.php?action=cancel&id=<?= $apt['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Cancel this appointment?')">Cancel</a>
                                                <?php else: ?>
                                                    <span class="text-muted fs-7">Completed</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
