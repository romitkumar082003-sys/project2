<?php
// MediCareX - Centralized Medical History Timeline
// Developed by Romit Kumar

$pageTitle = 'Medical Records Timeline';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole('Patient');

$user = getCurrentUser();
$pdo = getDBConnection();

$patStmt = $pdo->prepare("SELECT * FROM patients WHERE user_id = ?");
$patStmt->execute([$user['id']]);
$patient = $patStmt->fetch();
$patient_id = $patient['id'];

// Consultations
$consultations = $pdo->prepare("
    SELECT c.*, u_d.name as doctor_name, dep.dept_name, rx.id as rx_id
    FROM consultations c
    JOIN doctors d ON c.doctor_id = d.id
    JOIN users u_d ON d.user_id = u_d.id
    JOIN departments dep ON d.department_id = dep.id
    LEFT JOIN prescriptions rx ON c.id = rx.consultation_id
    WHERE c.patient_id = ?
    ORDER BY c.created_at DESC
");
$consultations->execute([$patient_id]);
$consultList = $consultations->fetchAll();

// Vitals
$vitals = $pdo->prepare("SELECT * FROM vitals WHERE patient_id = ? ORDER BY recorded_at DESC");
$vitals->execute([$patient_id]);
$vitalsList = $vitals->fetchAll();

// Lab Reports
$labs = $pdo->prepare("
    SELECT lr.*, lt.test_name 
    FROM lab_reports lr
    JOIN lab_requests req ON lr.request_id = req.id
    JOIN lab_tests lt ON req.test_id = lt.id
    WHERE lr.patient_id = ?
    ORDER BY lr.completed_at DESC
");
$labs->execute([$patient_id]);
$labList = $labs->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1">Centralized Medical Records</h3>
                    <p class="text-muted mb-0">Timeline view of consultations, diagnoses, vitals, and lab test results</p>
                </div>
            </div>

            <div class="row g-4">
                <!-- Timeline Stream -->
                <div class="col-lg-8">
                    <h5 class="fw-bold mb-3"><i class="bi bi-clock-history me-2 text-primary"></i> Medical Event Timeline</h5>
                    
                    <?php if (empty($consultList) && empty($labList) && empty($vitalsList)): ?>
                        <div class="card card-custom p-5 text-center text-muted">
                            <i class="bi bi-folder2-open fs-1 mb-3"></i>
                            <h5>No Medical Records Found</h5>
                            <p class="fs-7 mb-0">Your consultations, prescriptions, and lab reports will appear here once recorded by doctors.</p>
                        </div>
                    <?php else: ?>
                        <div class="timeline">
                            <!-- Consultations -->
                            <?php foreach ($consultList as $c): ?>
                                <div class="timeline-item">
                                    <div class="timeline-date"><?= formatDate($c['created_at']) ?></div>
                                    <div class="card card-custom p-3 mt-1 border-start border-4 border-primary">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <h6 class="fw-bold text-primary mb-0"><i class="bi bi-stethoscope me-1"></i> OPD Consultation: <?= htmlspecialchars($c['doctor_name']) ?></h6>
                                            <span class="badge bg-primary bg-opacity-10 text-primary fs-8"><?= htmlspecialchars($c['dept_name']) ?></span>
                                        </div>
                                        <div class="fs-7 text-dark mb-1"><strong>Symptoms:</strong> <?= htmlspecialchars($c['symptoms']) ?></div>
                                        <div class="fs-7 text-dark mb-2"><strong>Diagnosis:</strong> <span class="fw-bold text-success"><?= htmlspecialchars($c['diagnosis']) ?></span></div>
                                        
                                        <div class="d-flex gap-3 fs-8 text-muted bg-light p-2 rounded mb-2">
                                            <span>BP: <strong><?= htmlspecialchars($c['bp']) ?></strong></span>
                                            <span>Temp: <strong><?= htmlspecialchars($c['temp']) ?></strong></span>
                                            <span>Pulse: <strong><?= htmlspecialchars($c['pulse']) ?></strong></span>
                                            <span>Weight: <strong><?= htmlspecialchars($c['weight']) ?></strong></span>
                                        </div>

                                        <?php if ($c['rx_id']): ?>
                                            <div class="mt-2 text-end">
                                                <a href="<?= get_base_url() ?>/print_prescription.php?id=<?= $c['rx_id'] ?>" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill">
                                                    <i class="bi bi-printer me-1"></i> View Prescription
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>

                            <!-- Lab Reports -->
                            <?php foreach ($labList as $l): ?>
                                <div class="timeline-item">
                                    <div class="timeline-date"><?= formatDate($l['completed_at']) ?></div>
                                    <div class="card card-custom p-3 mt-1 border-start border-4 border-info">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <h6 class="fw-bold text-info mb-0"><i class="bi bi-journal-medical me-1"></i> Lab Test Report: <?= htmlspecialchars($l['test_name']) ?></h6>
                                            <span class="badge bg-info text-dark">Completed</span>
                                        </div>
                                        <p class="fs-7 text-muted mb-0"><?= htmlspecialchars($l['result_summary']) ?></p>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Patient Profile Card & Health Summary -->
                <div class="col-lg-4">
                    <div class="card card-custom p-4 mb-4">
                        <h5 class="fw-bold mb-3 border-bottom pb-2">Patient Profile</h5>
                        <div class="fs-7 mb-2"><strong>Patient ID:</strong> <span class="badge bg-primary fs-7"><?= htmlspecialchars($patient['patient_code']) ?></span></div>
                        <div class="fs-7 mb-2"><strong>DOB:</strong> <?= formatDate($patient['dob'], 'd M Y') ?></div>
                        <div class="fs-7 mb-2"><strong>Gender:</strong> <?= htmlspecialchars($patient['gender']) ?></div>
                        <div class="fs-7 mb-2"><strong>Blood Group:</strong> <span class="badge bg-danger fs-7"><?= htmlspecialchars($patient['blood_group']) ?></span></div>
                        <div class="fs-7 mb-2"><strong>Emergency Contact:</strong> <?= htmlspecialchars($patient['emergency_contact'] ?? 'N/A') ?></div>
                        <div class="fs-7"><strong>Medical History Notes:</strong><br><span class="text-muted"><?= htmlspecialchars($patient['medical_history'] ?? 'None recorded') ?></span></div>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
