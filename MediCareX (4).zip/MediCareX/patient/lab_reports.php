<?php
// MediCareX - Patient Lab Reports
// Developed by Romit Kumar

$pageTitle = 'Lab Reports';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole('Patient');

$user = getCurrentUser();
$pdo = getDBConnection();

$patStmt = $pdo->prepare("SELECT id FROM patients WHERE user_id = ?");
$patStmt->execute([$user['id']]);
$patient_id = $patStmt->fetchColumn();

$reports = $pdo->prepare("
    SELECT lr.*, lt.test_name, lt.category, req.request_code, u_d.name as doctor_name
    FROM lab_reports lr
    JOIN lab_requests req ON lr.request_id = req.id
    JOIN lab_tests lt ON req.test_id = lt.id
    JOIN doctors d ON req.doctor_id = d.id
    JOIN users u_d ON d.user_id = u_d.id
    WHERE lr.patient_id = ?
    ORDER BY lr.completed_at DESC
");
$reports->execute([$patient_id]);
$reportList = $reports->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1">Laboratory Reports</h3>
                    <p class="text-muted mb-0">Access diagnostic laboratory test findings and parameters</p>
                </div>
            </div>

            <div class="card card-custom border-0 shadow-sm">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light fs-7 text-uppercase">
                                <tr>
                                    <th>Request Code</th>
                                    <th>Test Name</th>
                                    <th>Category</th>
                                    <th>Ordered By</th>
                                    <th>Completed On</th>
                                    <th>Result Summary</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($reportList)): ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-5 text-muted">
                                            <i class="bi bi-journal-medical fs-1 d-block mb-2"></i>
                                            No completed laboratory reports found.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($reportList as $rep): ?>
                                        <tr>
                                            <td class="fw-bold text-primary"><?= htmlspecialchars($rep['request_code']) ?></td>
                                            <td class="fw-bold"><?= htmlspecialchars($rep['test_name']) ?></td>
                                            <td><span class="badge bg-secondary"><?= htmlspecialchars($rep['category']) ?></span></td>
                                            <td><?= htmlspecialchars($rep['doctor_name']) ?></td>
                                            <td><?= formatDate($rep['completed_at']) ?></td>
                                            <td class="fs-7 text-dark"><?= htmlspecialchars($rep['result_summary']) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
