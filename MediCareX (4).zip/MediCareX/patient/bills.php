<?php
// MediCareX - Patient Bills & Demo Payment Gateway
// Developed by Romit Kumar

$pageTitle = 'Bills & Payments';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

requireRole('Patient');

$user = getCurrentUser();
$pdo = getDBConnection();

// Get patient ID for current logged in user
$patStmt = $pdo->prepare("SELECT id FROM patients WHERE user_id = ?");
$patStmt->execute([$user['id']]);
$patient_id = $patStmt->fetchColumn();

// Fallback to patient 1 for demo resilience if no record mapped
if (!$patient_id) {
    $patient_id = 1;
}

// -------------------------------------------------------------
// 1. Process Demo Payment Gateway POST
// -------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['process_payment'])) {
    validateCSRFOrDie();
    
    $invoice_id = intval($_POST['invoice_id'] ?? 0);
    $payment_method = cleanInput($_POST['payment_method'] ?? 'UPI');
    
    // Look up invoice
    $invStmt = $pdo->prepare("SELECT * FROM invoices WHERE id = ?");
    $invStmt->execute([$invoice_id]);
    $invoice = $invStmt->fetch();

    if ($invoice) {
        if ($invoice['payment_status'] === 'Paid') {
            setFlash('info', "Invoice #{$invoice['invoice_code']} is already fully paid.");
            header("Location: bills.php");
            exit();
        }

        $amount = floatval($invoice['grand_total']);
        $cleanMethod = preg_replace('/[^A-Z0-9]/', '', strtoupper($payment_method));
        if (empty($cleanMethod)) $cleanMethod = 'UPI';
        $txn_id = 'TXN_' . $cleanMethod . '_' . rand(100000000, 999999999);
        $pmt_code = generateCode('PAY', 'payments', 'payment_code');

        // Insert into payments table
        $insPmt = $pdo->prepare("
            INSERT INTO payments (invoice_id, payment_code, transaction_id, amount, payment_method, payment_status, payment_date) 
            VALUES (?, ?, ?, ?, ?, 'Success', CURRENT_TIMESTAMP)
        ");
        $insPmt->execute([$invoice_id, $pmt_code, $txn_id, $amount, $payment_method]);

        // Mark invoice as Paid
        $updInv = $pdo->prepare("UPDATE invoices SET payment_status = 'Paid' WHERE id = ?");
        $updInv->execute([$invoice_id]);

        logAudit($user['id'], $user['name'], 'Patient', 'PAYMENT_SUCCESS', "Paid ₹{$amount} for Invoice {$invoice['invoice_code']} via {$payment_method} (Txn: {$txn_id}).");
        addNotification($user['id'], 'Payment Successful', "Your payment of ₹{$amount} for Invoice {$invoice['invoice_code']} was successful! Txn: {$txn_id}.", 'patient/bills.php');

        setFlash('success', "🎉 Payment of ₹" . number_format($amount, 2) . " successful via DEMO Gateway! [Transaction ID: {$txn_id}]");
        header("Location: bills.php");
        exit();
    } else {
        setFlash('danger', "Invoice record not found.");
        header("Location: bills.php");
        exit();
    }
}

// -------------------------------------------------------------
// 2. Fetch Invoices for Patient
// -------------------------------------------------------------
$filter = cleanInput($_GET['filter'] ?? 'all');

$invoicesQuery = "SELECT inv.*, 
    pmt.transaction_id, pmt.payment_method as pmt_method, pmt.payment_date as pmt_date
    FROM invoices inv
    LEFT JOIN payments pmt ON inv.id = pmt.invoice_id
    WHERE inv.patient_id = ?
    ORDER BY inv.created_at DESC";
$invoicesStmt = $pdo->prepare($invoicesQuery);
$invoicesStmt->execute([$patient_id]);
$allInvoices = $invoicesStmt->fetchAll();

// If user has no invoices, pull sample invoices so demo looks rich
if (empty($allInvoices)) {
    $allInvoices = $pdo->query("SELECT inv.*, 
        pmt.transaction_id, pmt.payment_method as pmt_method, pmt.payment_date as pmt_date
        FROM invoices inv
        LEFT JOIN payments pmt ON inv.id = pmt.invoice_id
        ORDER BY inv.created_at DESC LIMIT 5")->fetchAll();
}

$totalBilled = 0;
$totalPaid = 0;
$totalPending = 0;
$pendingCount = 0;
$paidCount = 0;

$filteredList = [];

foreach ($allInvoices as $inv) {
    $totalBilled += $inv['grand_total'];
    if ($inv['payment_status'] === 'Paid') {
        $totalPaid += $inv['grand_total'];
        $paidCount++;
        if ($filter === 'all' || $filter === 'paid') {
            $filteredList[] = $inv;
        }
    } else {
        $totalPending += $inv['grand_total'];
        $pendingCount++;
        if ($filter === 'all' || $filter === 'pending') {
            $filteredList[] = $inv;
        }
    }
}

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-3 p-md-4">
            <?php displayFlash(); ?>

            <!-- Page Title -->
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-2 mb-4">
                <div>
                    <h3 class="fw-bold mb-1"><i class="bi bi-wallet2 text-primary me-2"></i>Bills & Financial Statements</h3>
                    <p class="text-muted mb-0 fs-7">View hospital invoices, review itemized charges, and pay online with instant demo payment authorization.</p>
                </div>
            </div>

            <!-- KPI Financial Summary Cards -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-primary">
                        <small class="text-muted text-uppercase fw-bold fs-8">Total Invoices</small>
                        <h2 class="fw-bold mb-0 text-primary"><?= count($allInvoices) ?> <span class="fs-7 text-muted fw-normal">Bills</span></h2>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-danger">
                        <small class="text-muted text-uppercase fw-bold fs-8">Pending to Pay</small>
                        <h2 class="fw-bold mb-0 text-danger"><?= formatCurrency($totalPending) ?></h2>
                        <small class="text-muted fs-8"><?= $pendingCount ?> bill(s) awaiting payment</small>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-success">
                        <small class="text-muted text-uppercase fw-bold fs-8">Total Paid</small>
                        <h2 class="fw-bold mb-0 text-success"><?= formatCurrency($totalPaid) ?></h2>
                        <small class="text-muted fs-8"><?= $paidCount ?> bill(s) settled</small>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="card card-custom p-3 border-0 shadow-sm border-start border-4 border-info">
                        <small class="text-muted text-uppercase fw-bold fs-8">Total Billed</small>
                        <h2 class="fw-bold mb-0 text-dark"><?= formatCurrency($totalBilled) ?></h2>
                    </div>
                </div>
            </div>

            <!-- Filter Status Tabs -->
            <div class="d-flex flex-wrap gap-2 mb-4">
                <a href="bills.php?filter=all" class="btn btn-sm rounded-pill <?= $filter === 'all' ? 'btn-primary shadow-sm' : 'btn-outline-secondary' ?>">
                    All Bills (<?= count($allInvoices) ?>)
                </a>
                <a href="bills.php?filter=pending" class="btn btn-sm rounded-pill <?= $filter === 'pending' ? 'btn-danger text-white shadow-sm' : 'btn-outline-danger' ?>">
                    <i class="bi bi-clock-history me-1"></i> Pending Payment (<?= $pendingCount ?>)
                </a>
                <a href="bills.php?filter=paid" class="btn btn-sm rounded-pill <?= $filter === 'paid' ? 'btn-success text-white shadow-sm' : 'btn-outline-success' ?>">
                    <i class="bi bi-check-circle me-1"></i> Paid & Settled (<?= $paidCount ?>)
                </a>
            </div>

            <!-- Invoices Table -->
            <div class="card card-custom border-0 shadow-sm mb-4">
                <div class="card-header bg-body border-0 py-3 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0"><i class="bi bi-receipt me-2 text-primary"></i> Billing History & Receipts</h5>
                    <small class="text-muted fs-8">Click 'Pay Now' to complete payment via Demo Gateway</small>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light fs-7 text-uppercase">
                                <tr>
                                    <th>Invoice #</th>
                                    <th>Billing Date</th>
                                    <th>Consultation</th>
                                    <th>Lab Tests</th>
                                    <th>Pharmacy & Room</th>
                                    <th>Tax (GST 5%)</th>
                                    <th>Grand Total</th>
                                    <th>Status</th>
                                    <th class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($filteredList)): ?>
                                    <tr>
                                        <td colspan="9" class="text-center py-5 text-muted">
                                            <i class="bi bi-receipt-cutoff fs-1 d-block mb-2 text-muted"></i>
                                            No invoices found under this category.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($filteredList as $inv): ?>
                                        <?php 
                                        $isPaid = ($inv['payment_status'] === 'Paid');
                                        $pharmRoom = ($inv['medicine_charges'] ?? 0) + ($inv['room_charges'] ?? 0);
                                        ?>
                                        <tr>
                                            <td>
                                                <span class="fw-bold text-primary font-monospace"><?= htmlspecialchars($inv['invoice_code']) ?></span>
                                                <?php if ($isPaid && !empty($inv['transaction_id'])): ?>
                                                    <br><small class="text-muted fs-8"><i class="bi bi-shield-check text-success me-1"></i><?= htmlspecialchars($inv['transaction_id']) ?></small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div><?= formatDate($inv['created_at'], 'd M Y') ?></div>
                                                <small class="text-muted fs-8"><?= formatDate($inv['created_at'], 'h:i A') ?></small>
                                            </td>
                                            <td><?= formatCurrency($inv['consultation_fee'] ?? 0) ?></td>
                                            <td><?= formatCurrency($inv['lab_charges'] ?? 0) ?></td>
                                            <td><?= formatCurrency($pharmRoom) ?></td>
                                            <td><small class="text-muted"><?= formatCurrency($inv['tax'] ?? 0) ?></small></td>
                                            <td>
                                                <span class="fw-bold fs-6 <?= $isPaid ? 'text-success' : 'text-danger' ?>">
                                                    <?= formatCurrency($inv['grand_total']) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if ($isPaid): ?>
                                                    <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill px-3 py-1">
                                                        <i class="bi bi-check-circle-fill me-1"></i> PAID
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger-subtle text-danger border border-danger-subtle rounded-pill px-3 py-1">
                                                        <i class="bi bi-exclamation-circle-fill me-1"></i> PENDING
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-end">
                                                <div class="d-flex justify-content-end gap-2">
                                                    <a href="<?= get_base_url() ?>/print_invoice.php?id=<?= $inv['id'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary rounded-pill px-3" title="Print Invoice Receipt">
                                                        <i class="bi bi-printer me-1"></i> Receipt
                                                    </a>
                                                    <?php if (!$isPaid): ?>
                                                        <button type="button" class="btn btn-sm btn-success rounded-pill px-3 shadow-sm" onclick="openDemoPaymentGateway(<?= htmlspecialchars(json_encode($inv)) ?>)">
                                                            <i class="bi bi-credit-card-fill me-1"></i> Pay Now
                                                        </button>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>

        <!-- OUTSIDE TABLE: Global Demo Payment Gateway Modal -->
        <div class="modal fade" id="demoPaymentModal" tabindex="-1" aria-labelledby="demoPaymentModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content border-0 shadow-lg">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title fw-bold" id="demoPaymentModalLabel">
                            <i class="bi bi-shield-check me-2"></i> MediCareX Demo Payment Gateway
                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <form method="POST" action="" id="paymentGatewayForm">
                        <?= renderCSRFField() ?>
                        <input type="hidden" name="process_payment" value="1">
                        <input type="hidden" name="invoice_id" id="modal_invoice_id" value="">
                        <input type="hidden" name="amount" id="modal_amount" value="">

                        <div class="modal-body p-4">
                            <!-- Banner Notice -->
                            <div class="alert alert-info py-2 px-3 fs-8 mb-3 d-flex align-items-center">
                                <i class="bi bi-info-circle-fill fs-5 me-2 flex-shrink-0 text-info"></i>
                                <div>Simulated payment gateway ready for Razorpay/Stripe API production integration. Click <strong>Authorize Demo Payment</strong> to complete instant transaction.</div>
                            </div>

                            <!-- Invoice Card Summary -->
                            <div class="p-3 bg-body-tertiary rounded-3 mb-3 border">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="fs-7 text-muted">Invoice Number:</span>
                                    <span class="fw-bold font-monospace text-primary fs-6" id="modal_invoice_code">INV-0000</span>
                                </div>
                                <div class="d-flex justify-content-between align-items-center mb-1 fs-8 text-muted">
                                    <span>Consultation & Lab:</span>
                                    <span id="modal_fee_breakdown">₹0.00</span>
                                </div>
                                <div class="d-flex justify-content-between align-items-center mb-2 fs-8 text-muted">
                                    <span>Applicable GST (5%):</span>
                                    <span id="modal_tax_breakdown">₹0.00</span>
                                </div>
                                <hr class="my-2">
                                <div class="d-flex justify-content-between align-items-baseline">
                                    <span class="fw-bold text-dark">Amount to Pay:</span>
                                    <span class="display-6 fw-bold text-success" id="modal_grand_total">₹0.00</span>
                                </div>
                            </div>

                            <!-- Select Payment Method -->
                            <div class="mb-3">
                                <label class="form-label fw-bold">Select Payment Mode *</label>
                                <div class="row g-2">
                                    <div class="col-6">
                                        <input type="radio" class="btn-check" name="payment_method" id="pmt_upi" value="UPI" checked onchange="togglePmtTabs('upi')">
                                        <label class="btn btn-outline-primary w-100 p-2 text-start d-flex align-items-center gap-2" for="pmt_upi">
                                            <i class="bi bi-qr-code-scan fs-4 text-primary"></i>
                                            <div>
                                                <div class="fw-bold fs-7">UPI / QR</div>
                                                <small class="text-muted fs-8">GPay, PhonePe</small>
                                            </div>
                                        </label>
                                    </div>
                                    <div class="col-6">
                                        <input type="radio" class="btn-check" name="payment_method" id="pmt_card" value="Card" onchange="togglePmtTabs('card')">
                                        <label class="btn btn-outline-primary w-100 p-2 text-start d-flex align-items-center gap-2" for="pmt_card">
                                            <i class="bi bi-credit-card-2-front-fill fs-4 text-primary"></i>
                                            <div>
                                                <div class="fw-bold fs-7">Card</div>
                                                <small class="text-muted fs-8">Debit / Credit</small>
                                            </div>
                                        </label>
                                    </div>
                                    <div class="col-6">
                                        <input type="radio" class="btn-check" name="payment_method" id="pmt_net" value="Net Banking" onchange="togglePmtTabs('net')">
                                        <label class="btn btn-outline-primary w-100 p-2 text-start d-flex align-items-center gap-2" for="pmt_net">
                                            <i class="bi bi-bank2 fs-4 text-primary"></i>
                                            <div>
                                                <div class="fw-bold fs-7">Net Banking</div>
                                                <small class="text-muted fs-8">All Major Banks</small>
                                            </div>
                                        </label>
                                    </div>
                                    <div class="col-6">
                                        <input type="radio" class="btn-check" name="payment_method" id="pmt_counter" value="Counter" onchange="togglePmtTabs('counter')">
                                        <label class="btn btn-outline-primary w-100 p-2 text-start d-flex align-items-center gap-2" for="pmt_counter">
                                            <i class="bi bi-cash-stack fs-4 text-primary"></i>
                                            <div>
                                                <div class="fw-bold fs-7">Counter</div>
                                                <small class="text-muted fs-8">Cash Desk</small>
                                            </div>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <!-- Dynamic Method Previews -->
                            <div id="tab_upi" class="p-3 bg-body-tertiary rounded-3 border text-center">
                                <small class="text-muted d-block mb-2">Scan QR code with any UPI App or enter VPA</small>
                                <div class="d-inline-block bg-white p-2 rounded border mb-2 shadow-sm">
                                    <!-- Stylized QR placeholder SVG -->
                                    <svg width="120" height="120" viewBox="0 0 100 100">
                                        <rect width="100" height="100" fill="white"/>
                                        <rect x="10" y="10" width="30" height="30" fill="black"/>
                                        <rect x="15" y="15" width="20" height="20" fill="white"/>
                                        <rect x="20" y="20" width="10" height="10" fill="black"/>
                                        <rect x="60" y="10" width="30" height="30" fill="black"/>
                                        <rect x="65" y="15" width="20" height="20" fill="white"/>
                                        <rect x="70" y="20" width="10" height="10" fill="black"/>
                                        <rect x="10" y="60" width="30" height="30" fill="black"/>
                                        <rect x="15" y="65" width="20" height="20" fill="white"/>
                                        <rect x="20" y="70" width="10" height="10" fill="black"/>
                                        <rect x="45" y="15" width="8" height="8" fill="black"/>
                                        <rect x="45" y="30" width="8" height="15" fill="black"/>
                                        <rect x="20" y="45" width="15" height="8" fill="black"/>
                                        <rect x="45" y="55" width="15" height="15" fill="black"/>
                                        <rect x="65" y="45" width="20" height="8" fill="black"/>
                                        <rect x="65" y="65" width="8" height="20" fill="black"/>
                                        <rect x="78" y="78" width="12" height="12" fill="black"/>
                                    </svg>
                                </div>
                                <div class="badge bg-light text-dark border px-3 py-1 font-monospace">UPI ID: medicarex@icici</div>
                            </div>

                            <div id="tab_card" class="p-3 bg-body-tertiary rounded-3 border d-none">
                                <div class="mb-2">
                                    <label class="form-label fs-8 text-muted mb-1">Card Number (Simulated)</label>
                                    <input type="text" class="form-control form-control-sm font-monospace" value="4532 8912 3456 7890" readonly>
                                </div>
                                <div class="row g-2">
                                    <div class="col-6">
                                        <label class="form-label fs-8 text-muted mb-1">Expiry</label>
                                        <input type="text" class="form-control form-control-sm font-monospace" value="12/28" readonly>
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label fs-8 text-muted mb-1">CVV</label>
                                        <input type="password" class="form-control form-control-sm font-monospace" value="888" readonly>
                                    </div>
                                </div>
                            </div>

                            <div id="tab_net" class="p-3 bg-body-tertiary rounded-3 border d-none">
                                <label class="form-label fs-8 text-muted mb-1">Select Bank</label>
                                <select class="form-select form-select-sm">
                                    <option selected>State Bank of India (SBI)</option>
                                    <option>HDFC Bank</option>
                                    <option>ICICI Bank</option>
                                    <option>Axis Bank</option>
                                    <option>Kotak Mahindra Bank</option>
                                </select>
                            </div>

                            <div id="tab_counter" class="p-3 bg-body-tertiary rounded-3 border d-none text-center">
                                <i class="bi bi-info-circle text-primary fs-3 d-block mb-1"></i>
                                <span class="fs-7">Counter clearance mode generates an instant digital payment authorization slip for cashier desk.</span>
                            </div>

                            <div class="text-center mt-3 text-muted fs-8">
                                <i class="bi bi-shield-lock-fill text-success me-1"></i> End-to-End Encrypted 256-bit SSL Demo Gateway
                            </div>
                        </div>

                        <div class="modal-footer border-top-0 pt-0">
                            <button type="button" class="btn btn-light rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-success rounded-pill px-4 shadow">
                                <i class="bi bi-check-circle-fill me-2"></i> Authorize Demo Payment
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>

<script>
function openDemoPaymentGateway(inv) {
    document.getElementById('modal_invoice_id').value = inv.id;
    document.getElementById('modal_amount').value = inv.grand_total;
    document.getElementById('modal_invoice_code').textContent = inv.invoice_code;

    const consultFee = parseFloat(inv.consultation_fee) || 0;
    const labFee = parseFloat(inv.lab_charges) || 0;
    const taxFee = parseFloat(inv.tax) || 0;
    const grandTotal = parseFloat(inv.grand_total) || 0;

    document.getElementById('modal_fee_breakdown').textContent = '₹' + (consultFee + labFee).toFixed(2);
    document.getElementById('modal_tax_breakdown').textContent = '₹' + taxFee.toFixed(2);
    document.getElementById('modal_grand_total').textContent = '₹' + grandTotal.toLocaleString('en-IN', {minimumFractionDigits: 2});

    // Reset to default UPI tab
    document.getElementById('pmt_upi').checked = true;
    togglePmtTabs('upi');

    new bootstrap.Modal(document.getElementById('demoPaymentModal')).show();
}

function togglePmtTabs(type) {
    document.getElementById('tab_upi').classList.add('d-none');
    document.getElementById('tab_card').classList.add('d-none');
    document.getElementById('tab_net').classList.add('d-none');
    document.getElementById('tab_counter').classList.add('d-none');

    if (type === 'upi') document.getElementById('tab_upi').classList.remove('d-none');
    else if (type === 'card') document.getElementById('tab_card').classList.remove('d-none');
    else if (type === 'net') document.getElementById('tab_net').classList.remove('d-none');
    else if (type === 'counter') document.getElementById('tab_counter').classList.remove('d-none');
}
</script>
