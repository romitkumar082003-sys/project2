<?php
// MediCareX - Patient Dashboard
// Developed by Romit Kumar

$pageTitle = 'Patient Dashboard';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole('Patient');

$user = getCurrentUser();
$pdo = getDBConnection();

// Fetch patient ID
$patStmt = $pdo->prepare("SELECT * FROM patients WHERE user_id = ?");
$patStmt->execute([$user['id']]);
$patient = $patStmt->fetch();

if (!$patient) {
    die("Patient profile record missing.");
}

$patient_id = $patient['id'];

// Stats
$cntApts = $pdo->prepare("SELECT COUNT(*) FROM appointments WHERE patient_id = ? AND status IN ('Pending', 'Confirmed', 'Checked In')");
$cntApts->execute([$patient_id]);
$upcomingCount = $cntApts->fetchColumn();

$cntRx = $pdo->prepare("SELECT COUNT(*) FROM prescriptions WHERE patient_id = ?");
$cntRx->execute([$patient_id]);
$rxCount = $cntRx->fetchColumn();

$cntLab = $pdo->prepare("SELECT COUNT(*) FROM lab_requests WHERE patient_id = ? AND status = 'Completed'");
$cntLab->execute([$patient_id]);
$labCount = $cntLab->fetchColumn();

$cntBills = $pdo->prepare("SELECT COUNT(*) FROM invoices WHERE patient_id = ? AND payment_status = 'Pending'");
$cntBills->execute([$patient_id]);
$pendingBillsCount = $cntBills->fetchColumn();

// Fetch upcoming appointments
$aptsStmt = $pdo->prepare("
    SELECT a.*, d.specialization, u_d.name as doctor_name, dep.dept_name 
    FROM appointments a
    JOIN doctors d ON a.doctor_id = d.id
    JOIN users u_d ON d.user_id = u_d.id
    JOIN departments dep ON a.department_id = dep.id
    WHERE a.patient_id = ?
    ORDER BY a.appointment_date DESC, a.id DESC LIMIT 5
");
$aptsStmt->execute([$patient_id]);
$recentAppointments = $aptsStmt->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <?php displayFlash(); ?>

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1">Welcome back, <?= htmlspecialchars($user['name']) ?> 👋</h3>
                    <p class="text-muted mb-0">Patient Code: <span class="badge bg-primary fs-7"><?= htmlspecialchars($patient['patient_code']) ?></span> | Blood Group: <strong><?= htmlspecialchars($patient['blood_group']) ?></strong></p>
                </div>
                <a href="<?= get_base_url() ?>/patient/book_appointment.php" class="btn btn-primary rounded-pill px-4 shadow-sm">
                    <i class="bi bi-calendar-plus-fill me-2"></i> Book Appointment
                </a>
            </div>

            <!-- KPI Cards -->
            <div class="row g-3 mb-4">
                <div class="col-md-3">
                    <div class="card card-custom card-kpi p-3">
                        <div class="d-flex align-items-center justify-content-between">
                            <div>
                                <small class="text-muted fw-bold text-uppercase fs-8">Upcoming Visits</small>
                                <h2 class="fw-bold mb-0 text-primary"><?= $upcomingCount ?></h2>
                            </div>
                            <div class="rounded-circle bg-primary bg-opacity-10 text-primary p-3 fs-3">
                                <i class="bi bi-calendar-event"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="card card-custom card-kpi card-kpi-success p-3">
                        <div class="d-flex align-items-center justify-content-between">
                            <div>
                                <small class="text-muted fw-bold text-uppercase fs-8">Prescriptions</small>
                                <h2 class="fw-bold mb-0 text-success"><?= $rxCount ?></h2>
                            </div>
                            <div class="rounded-circle bg-success bg-opacity-10 text-success p-3 fs-3">
                                <i class="bi bi-capsule-pill"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="card card-custom card-kpi card-kpi-info p-3">
                        <div class="d-flex align-items-center justify-content-between">
                            <div>
                                <small class="text-muted fw-bold text-uppercase fs-8">Lab Reports</small>
                                <h2 class="fw-bold mb-0 text-info"><?= $labCount ?></h2>
                            </div>
                            <div class="rounded-circle bg-info bg-opacity-10 text-info p-3 fs-3">
                                <i class="bi bi-file-earmark-medical"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="card card-custom card-kpi card-kpi-danger p-3">
                        <div class="d-flex align-items-center justify-content-between">
                            <div>
                                <small class="text-muted fw-bold text-uppercase fs-8">Pending Bills</small>
                                <h2 class="fw-bold mb-0 text-danger"><?= $pendingBillsCount ?></h2>
                            </div>
                            <div class="rounded-circle bg-danger bg-opacity-10 text-danger p-3 fs-3">
                                <i class="bi bi-credit-card"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Appointments Table -->
            <div class="card card-custom border-0 shadow-sm mb-4">
                <div class="card-header bg-body border-0 py-3 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0"><i class="bi bi-clock-history me-2 text-primary"></i> My Recent Appointments</h5>
                    <a href="<?= get_base_url() ?>/patient/my_appointments.php" class="btn btn-sm btn-outline-primary rounded-pill">View All</a>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light fs-7 text-uppercase">
                            <tr>
                                <th>Code</th>
                                <th>Doctor</th>
                                <th>Department</th>
                                <th>Date & Slot</th>
                                <th>Token</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recentAppointments)): ?>
                                <tr>
                                    <td colspan="7" class="text-center py-4 text-muted">
                                        <i class="bi bi-calendar-x fs-1 d-block mb-2"></i>
                                        No appointments recorded yet.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($recentAppointments as $apt): ?>
                                    <tr>
                                        <td class="fw-bold text-primary"><?= htmlspecialchars($apt['appointment_code']) ?></td>
                                        <td>
                                            <div class="fw-semibold"><?= htmlspecialchars($apt['doctor_name']) ?></div>
                                            <small class="text-muted"><?= htmlspecialchars($apt['specialization']) ?></small>
                                        </td>
                                        <td><?= htmlspecialchars($apt['dept_name']) ?></td>
                                        <td>
                                            <div><?= formatDate($apt['appointment_date'], 'd M Y') ?></div>
                                            <small class="text-muted"><?= htmlspecialchars($apt['time_slot']) ?></small>
                                        </td>
                                        <td><span class="badge bg-dark px-2 py-1 fs-7"><?= htmlspecialchars($apt['token_number']) ?></span></td>
                                        <td><?= renderStatusBadge($apt['status']) ?></td>
                                        <td>
                                            <?php if ($apt['status'] === 'Pending' || $apt['status'] === 'Confirmed'): ?>
                                                <a href="my_appointments.php?action=cancel&id=<?= $apt['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Cancel this appointment?')">Cancel</a>
                                            <?php else: ?>
                                                <span class="text-muted fs-7">None</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
