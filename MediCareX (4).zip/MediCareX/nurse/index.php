<?php
// MediCareX - Nurse Station Dashboard
// Developed by Romit Kumar

$pageTitle = 'Nursing Station';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole('Nurse');

$user = getCurrentUser();
$pdo = getDBConnection();

$cntAdmitted = $pdo->query("SELECT COUNT(*) FROM admissions WHERE status IN ('Admitted', 'Under Treatment')")->fetchColumn();
$cntVitalsToday = $pdo->query("SELECT COUNT(*) FROM vitals WHERE DATE(recorded_at) = CURDATE()")->fetchColumn();

$admittedPatients = $pdo->query("
    SELECT adm.*, p.patient_code, u_p.name as patient_name, u_d.name as doctor_name, r.room_number, r.room_type, b.bed_number
    FROM admissions adm
    JOIN patients p ON adm.patient_id = p.id
    JOIN users u_p ON p.user_id = u_p.id
    JOIN doctors d ON adm.doctor_id = d.id
    JOIN users u_d ON d.user_id = u_d.id
    JOIN rooms r ON adm.room_id = r.id
    JOIN beds b ON adm.bed_id = b.id
    WHERE adm.status IN ('Admitted', 'Under Treatment')
    ORDER BY adm.id DESC
")->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <?php displayFlash(); ?>

            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold mb-1">Nursing Desk & Ward Monitoring</h3>
                    <p class="text-muted mb-0">Record vital signs, track bed occupancy, and monitor inpatient care</p>
                </div>
                <a href="vitals.php" class="btn btn-primary rounded-pill px-4 shadow-sm"><i class="bi bi-activity me-1"></i> Log Patient Vitals</a>
            </div>

            <!-- KPI Cards -->
            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <div class="card card-custom card-kpi p-3">
                        <small class="text-muted fw-bold text-uppercase fs-8">Active Ward Inpatients</small>
                        <h2 class="fw-bold mb-0 text-primary"><?= $cntAdmitted ?></h2>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card card-custom card-kpi card-kpi-success p-3">
                        <small class="text-muted fw-bold text-uppercase fs-8">Vitals Logged Today</small>
                        <h2 class="fw-bold mb-0 text-success"><?= $cntVitalsToday ?></h2>
                    </div>
                </div>
            </div>

            <!-- Inpatient Ward Monitoring -->
            <div class="card card-custom border-0 shadow-sm mb-4">
                <div class="card-header bg-body border-0 py-3 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0"><i class="bi bi-door-open-fill me-2 text-primary"></i> Ward Patients & Vitals Log</h5>
                    <a href="vitals.php" class="btn btn-sm btn-outline-primary rounded-pill">Log Vitals</a>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light fs-7 text-uppercase">
                            <tr>
                                <th>Admission Code</th>
                                <th>Patient Name</th>
                                <th>Room / Ward</th>
                                <th>Bed Number</th>
                                <th>Attending Doctor</th>
                                <th>Status</th>
                                <th class="text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($admittedPatients)): ?>
                                <tr>
                                    <td colspan="7" class="text-center py-5 text-muted">
                                        <i class="bi bi-hospital fs-1 d-block mb-2"></i>
                                        No active inpatients in wards right now.
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($admittedPatients as $adm): ?>
                                    <tr>
                                        <td class="fw-bold text-primary"><?= htmlspecialchars($adm['admission_code']) ?></td>
                                        <td>
                                            <div class="fw-bold"><?= htmlspecialchars($adm['patient_name']) ?></div>
                                            <small class="text-muted"><?= htmlspecialchars($adm['patient_code']) ?></small>
                                        </td>
                                        <td>
                                            <div class="fw-semibold"><?= htmlspecialchars($adm['room_number']) ?></div>
                                            <small class="text-muted"><?= htmlspecialchars($adm['room_type']) ?></small>
                                        </td>
                                        <td><span class="badge bg-dark px-2 py-1 fs-7"><?= htmlspecialchars($adm['bed_number']) ?></span></td>
                                        <td><?= htmlspecialchars($adm['doctor_name']) ?></td>
                                        <td><?= renderStatusBadge($adm['status']) ?></td>
                                        <td class="text-end">
                                            <a href="vitals.php?patient_id=<?= $adm['patient_id'] ?>" class="btn btn-sm btn-primary rounded-pill px-3 shadow-sm">
                                                <i class="bi bi-activity me-1"></i> Log Vitals
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
