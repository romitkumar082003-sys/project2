<?php
// MediCareX - Ward & Bed Occupancy Board
// Developed by Romit Kumar

$pageTitle = 'Ward & Bed Board';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole(['Nurse', 'Receptionist', 'Admin']);

$user = getCurrentUser();
$pdo = getDBConnection();

$beds = $pdo->query("
    SELECT b.*, r.room_number, r.room_type, r.floor, r.daily_rate 
    FROM beds b 
    JOIN rooms r ON b.room_id = r.id 
    ORDER BY r.room_number ASC, b.bed_number ASC
")->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold mb-0">Ward & Bed Occupancy Matrix</h3>
            </div>

            <div class="row g-3">
                <?php foreach ($beds as $bed): ?>
                    <div class="col-md-4 col-lg-3">
                        <div class="card card-custom p-3 border-start border-4 <?= ($bed['status'] === 'Available') ? 'border-success' : (($bed['status'] === 'Occupied') ? 'border-danger' : 'border-warning') ?>">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h6 class="fw-bold mb-0 text-primary">Room <?= htmlspecialchars($bed['room_number']) ?></h6>
                                <?= renderStatusBadge($bed['status']) ?>
                            </div>
                            <div class="fs-7 text-dark fw-bold mb-1">Bed: <?= htmlspecialchars($bed['bed_number']) ?></div>
                            <div class="fs-8 text-muted"><?= htmlspecialchars($bed['room_type']) ?> (<?= htmlspecialchars($bed['floor']) ?>)</div>
                            <div class="fs-8 fw-semibold text-primary mt-2">Rate: <?= formatCurrency($bed['daily_rate']) ?>/day</div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
