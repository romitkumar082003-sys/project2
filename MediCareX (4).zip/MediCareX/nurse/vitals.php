<?php
// MediCareX - Vital Signs Logger
// Developed by Romit Kumar

$pageTitle = 'Log Vital Signs';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

requireRole(['Nurse', 'Doctor', 'Admin']);

$user = getCurrentUser();
$pdo = getDBConnection();

$selected_patient_id = intval($_GET['patient_id'] ?? 0);

$patients = $pdo->query("SELECT p.id, p.patient_code, u.name FROM patients p JOIN users u ON p.user_id = u.id ORDER BY u.name ASC")->fetchAll();

$errorMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validateCSRFOrDie();

    $patient_id = intval($_POST['patient_id'] ?? 0);
    $bp = cleanInput($_POST['bp'] ?? '');
    $temperature = cleanInput($_POST['temperature'] ?? '');
    $pulse = cleanInput($_POST['pulse'] ?? '');
    $spo2 = cleanInput($_POST['spo2'] ?? '');
    $weight = cleanInput($_POST['weight'] ?? '');
    $notes = cleanInput($_POST['notes'] ?? '');

    if (!$patient_id || !$bp || !$temperature || !$pulse) {
        $errorMsg = "Please fill in patient, blood pressure, temperature, and pulse rate.";
    } else {
        $ins = $pdo->prepare("
            INSERT INTO vitals (patient_id, recorded_by_user_id, bp, temperature, pulse, spo2, weight, notes, recorded_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        $ins->execute([$patient_id, $user['id'], $bp, $temperature, $pulse, $spo2, $weight, $notes]);

        logAudit($user['id'], $user['name'], $user['role_name'], 'VITALS_RECORDED', "Recorded vital signs for Patient ID {$patient_id}.");
        setFlash('success', "Vital signs recorded successfully.");
        header("Location: vitals.php?patient_id={$patient_id}");
        exit();
    }
}

// Fetch vitals log history
$recentVitals = $pdo->query("
    SELECT v.*, p.patient_code, u_p.name as patient_name, u_r.name as recorded_by_name
    FROM vitals v
    JOIN patients p ON v.patient_id = p.id
    JOIN users u_p ON p.user_id = u_p.id
    JOIN users u_r ON v.recorded_by_user_id = u_r.id
    ORDER BY v.recorded_at DESC LIMIT 15
")->fetchAll();

require_once __DIR__ . '/../layout/header.php';
?>

<div id="wrapper">
    <?php require_once __DIR__ . '/../layout/sidebar.php'; ?>

    <div id="content">
        <?php require_once __DIR__ . '/../layout/navbar.php'; ?>

        <div class="container-fluid p-4">
            <?php displayFlash(); ?>

            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold mb-0">Record Vital Signs</h3>
            </div>

            <div class="row g-4">
                <!-- Vitals Entry Form -->
                <div class="col-lg-5">
                    <div class="card card-custom p-4 border-0 shadow-sm">
                        <?php if ($errorMsg): ?>
                            <div class="alert alert-danger border-0 shadow-sm mb-3"><?= htmlspecialchars($errorMsg) ?></div>
                        <?php endif; ?>

                        <form method="POST" action="">
                            <?= renderCSRFField() ?>
                            <div class="mb-3">
                                <label class="form-label fw-semibold">Select Patient *</label>
                                <select name="patient_id" class="form-select" required>
                                    <option value="">-- Choose Patient --</option>
                                    <?php foreach ($patients as $pat): ?>
                                        <option value="<?= $pat['id'] ?>" <?= ($selected_patient_id === $pat['id']) ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($pat['name']) ?> (<?= htmlspecialchars($pat['patient_code']) ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="row g-2 mb-3">
                                <div class="col-6">
                                    <label class="form-label fw-semibold">Blood Pressure (BP) *</label>
                                    <input type="text" name="bp" class="form-control" placeholder="120/80" required>
                                </div>
                                <div class="col-6">
                                    <label class="form-label fw-semibold">Temperature *</label>
                                    <input type="text" name="temperature" class="form-control" placeholder="98.6 F" required>
                                </div>
                                <div class="col-6">
                                    <label class="form-label fw-semibold">Pulse Rate *</label>
                                    <input type="text" name="pulse" class="form-control" placeholder="72 bpm" required>
                                </div>
                                <div class="col-6">
                                    <label class="form-label fw-semibold">SpO2 Oxygen %</label>
                                    <input type="text" name="spo2" class="form-control" placeholder="99%">
                                </div>
                                <div class="col-12">
                                    <label class="form-label fw-semibold">Weight</label>
                                    <input type="text" name="weight" class="form-control" placeholder="70 kg">
                                </div>
                                <div class="col-12">
                                    <label class="form-label fw-semibold">Nurse Notes / Observations</label>
                                    <input type="text" name="notes" class="form-control" placeholder="Patient calm, no distress...">
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary w-100 rounded-pill shadow-sm">
                                <i class="bi bi-activity me-1"></i> Save Vital Signs
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Recent Vitals Stream -->
                <div class="col-lg-7">
                    <div class="card card-custom border-0 shadow-sm">
                        <div class="card-header bg-body border-0 py-3">
                            <h5 class="fw-bold mb-0"><i class="bi bi-clock-history me-2 text-primary"></i> Timestamped Vitals History</h5>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0 fs-7">
                                <thead class="table-light text-uppercase">
                                    <tr>
                                        <th>Recorded At</th>
                                        <th>Patient</th>
                                        <th>BP</th>
                                        <th>Temp</th>
                                        <th>Pulse</th>
                                        <th>SpO2</th>
                                        <th>Recorded By</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($recentVitals)): ?>
                                        <tr><td colspan="7" class="text-center py-4 text-muted">No vitals logged yet.</td></tr>
                                    <?php else: ?>
                                        <?php foreach ($recentVitals as $v): ?>
                                            <tr>
                                                <td class="fw-semibold text-primary"><?= formatDate($v['recorded_at']) ?></td>
                                                <td class="fw-bold"><?= htmlspecialchars($v['patient_name']) ?></td>
                                                <td><span class="badge bg-primary bg-opacity-10 text-primary"><?= htmlspecialchars($v['bp']) ?></span></td>
                                                <td><span class="badge bg-danger bg-opacity-10 text-danger"><?= htmlspecialchars($v['temperature']) ?></span></td>
                                                <td><span class="badge bg-success bg-opacity-10 text-success"><?= htmlspecialchars($v['pulse']) ?></span></td>
                                                <td><?= htmlspecialchars($v['spo2'] ?? 'N/A') ?></td>
                                                <td class="text-muted"><?= htmlspecialchars($v['recorded_by_name']) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once __DIR__ . '/../layout/footer.php'; ?>
    </div>
</div>
